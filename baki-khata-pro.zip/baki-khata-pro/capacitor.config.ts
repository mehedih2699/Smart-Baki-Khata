import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smartbakikhata.app',
  appName: 'Baki Khata Pro',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
