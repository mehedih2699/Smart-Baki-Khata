export interface UserProfile {
  uid: string;
  ownerName: string;
  shopName: string;
  shopAddress: string;
  email: string;
  pin?: string;
  pinEnabled?: boolean;
  shopLogo?: string;
  cashCategories?: string[];
  quickButtons?: number[];
  debtLimits?: {
    green: number;
    orange: number;
    red: number;
  };
  blocked?: boolean;
  createdAt?: string;
}

export interface AppConfig {
  report: boolean;
  settings: boolean;
  notes: boolean;
  privacy: boolean;
  feedback: boolean;
  cash: boolean;
  savings: boolean;
  loan: boolean;
}

export interface AppUpdate {
  version: string;
  message: string;
  link: string;
  enabled: boolean;
}

export interface AppNotice {
  id: string;
  message: string;
  enabled: boolean;
  date: string;
}

export interface AdminContact {
  link: string;
  message: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  tag: 'New' | 'VIP' | 'Regular' | 'Risky';
  totalBalance: number;
  ownerUid: string;
  createdAt?: string;
}

export interface Transaction {
  id: string;
  customerId: string;
  amount: number;
  type: 'baki' | 'joma';
  note: string;
  date: string;
  ownerUid: string;
}

export interface CashEntry {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  note: string;
  date: string;
  ownerUid: string;
}

export interface Savings {
  id: string;
  amount: number;
  note: string;
  date: string;
  ownerUid: string;
}

export interface Loaner {
  id: string;
  name: string;
  phone: string;
  address: string;
  totalTaken: number;
  totalPaid: number;
  ownerUid: string;
}

export interface LoanTransaction {
  id: string;
  loanerId: string;
  amount: number;
  type: 'loan' | 'payment';
  note: string;
  date: string;
  ownerUid: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  ownerUid: string;
}

export interface Feedback {
  id: string;
  content: string;
  date: string;
  userEmail: string;
  ownerUid: string;
}
