import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  Store, 
  User, 
  MapPin, 
  ArrowRight,
  Loader2
} from 'lucide-react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  AuthError
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { useAuth } from '../AuthContext';
import { cn } from '../lib/utils';

const getBengaliError = (code: string) => {
  switch (code) {
    case 'auth/email-already-in-use':
      return 'এই ইমেইলটি ইতিপূর্বে ব্যবহার করা হয়েছে। অনুগ্রহ করে লগইন করুন।';
    case 'auth/invalid-email':
      return 'ইমেইলটি সঠিক নয়।';
    case 'auth/operation-not-allowed':
      return 'ইমেইল/পাসওয়ার্ড লগইন সক্রিয় নয়। অনুগ্রহ করে ফায়ারবেজ কনসোলে এটি সক্রিয় করুন।';
    case 'auth/weak-password':
      return 'পাসওয়ার্ডটি অন্তত ৬ অক্ষরের হতে হবে।';
    case 'auth/user-not-found':
      return 'এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি।';
    case 'auth/wrong-password':
      return 'পাসওয়ার্ডটি সঠিক নয়।';
    case 'auth/network-request-failed':
      return 'ইন্টারনেট সংযোগ নেই। অনুগ্রহ করে চেক করুন।';
    case 'auth/too-many-requests':
      return 'অতিরিক্ত চেষ্টার কারণে আপনার অ্যাকাউন্টটি সাময়িকভাবে ব্লক করা হয়েছে। পরে চেষ্টা করুন।';
    case 'auth/invalid-credential':
      return 'ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।';
    case 'permission-denied':
      return 'সার্ভার পারমিশন ইরোর। আপনার এই কাজটি করার অনুমতি নেই।';
    case 'resource-exhausted':
      return 'সার্ভার কোটা শেষ হয়ে গেছে। অনুগ্রহ করে আগামীকাল চেষ্টা করুন।';
    case 'unavailable':
      return 'সার্ভার সাময়িকভাবে ডাউন আছে। পরে চেষ্টা করুন।';
    default:
      return 'কিছু একটা সমস্যা হয়েছে। আবার চেষ্টা করুন।';
  }
};



export const AuthScreen: React.FC = () => {
  const { user, firebaseUser, logout } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const isCompletingProfile = !!firebaseUser && !user;

  const [formData, setFormData] = useState({
    email: firebaseUser?.email || '',
    password: '',
    ownerName: '',
    shopName: '',
    shopAddress: '',
  });

  React.useEffect(() => {
    if (isCompletingProfile) {
      setIsLogin(false);
    }
  }, [isCompletingProfile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, formData.email, formData.password);
      } else {
        let uid = firebaseUser?.uid;
        if (!uid) {
          if (formData.password.length < 6) {
            setError('পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে');
            setLoading(false);
            return;
          }
          const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
          uid = userCredential.user.uid;
        }

        try {
          await setDoc(doc(db, 'users', uid), {
            ownerName: formData.ownerName,
            shopName: formData.shopName,
            shopAddress: formData.shopAddress,
            email: formData.email || firebaseUser?.email,
            pinEnabled: false,
            cashCategories: ['পণ্য ক্রয়', 'ভাড়া', 'বিদ্যুৎ বিল', 'বেতন', 'অন্যান্য'],
            quickButtons: [10, 20, 50, 100, 500],
            debtLimits: { green: 1000, orange: 5000, red: 10000 },
            createdAt: new Date().toISOString()
          });
        } catch (fsErr: any) {
          handleFirestoreError(fsErr, OperationType.WRITE, `users/${uid}`);
        }
      }
    } catch (err: any) {
      console.error('Auth Error:', err);
      if (err.code) {
        setError(getBengaliError(err.code));
      } else {
        setError(err.message || 'একটি অজানা সমস্যা হয়েছে');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!formData.email) {
      setError('অনুগ্রহ করে আপনার ইমেইলটি দিন');
      return;
    }
    try {
      await sendPasswordResetEmail(auth, formData.email);
      setMessage('পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md bg-white rounded-3xl shadow-2xl shadow-slate-200 overflow-hidden"
      >
        <div className="bg-emerald-600 p-8 text-white text-center">
          <h1 className="text-3xl font-bold mb-2">বাকি খাতা প্রো</h1>
          <p className="text-emerald-100 opacity-80">আপনার ব্যবসার স্মার্ট ডিজিটাল লেজার</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-4">
          {!isCompletingProfile ? (
            <div className="flex bg-slate-100 p-1 rounded-xl mb-6">
              <button
                type="button"
                onClick={() => setIsLogin(true)}
                className={cn(
                  "flex-1 py-2 rounded-lg font-medium transition-all",
                  isLogin ? "bg-white shadow-sm text-emerald-600" : "text-slate-500"
                )}
              >
                লগইন
              </button>
              <button
                type="button"
                onClick={() => setIsLogin(false)}
                className={cn(
                  "flex-1 py-2 rounded-lg font-medium transition-all",
                  !isLogin ? "bg-white shadow-sm text-emerald-600" : "text-slate-500"
                )}
              >
                রেজিস্ট্রেশন
              </button>
            </div>
          ) : (
            <div className="p-4 bg-amber-50 text-amber-700 text-sm rounded-xl mb-6 border border-amber-100">
              আপনার প্রোফাইল তথ্য সম্পূর্ণ করুন।
            </div>
          )}

          {error && <div className="p-3 bg-rose-50 text-rose-600 text-sm rounded-lg border border-rose-100">{error}</div>}
          {message && <div className="p-3 bg-emerald-50 text-emerald-600 text-sm rounded-lg border border-emerald-100">{message}</div>}

          {!isLogin && (
            <>
              <div className="relative">
                <User className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="মালিকের নাম"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  value={formData.ownerName}
                  onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                />
              </div>
              <div className="relative">
                <Store className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="দোকানের নাম"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  value={formData.shopName}
                  onChange={(e) => setFormData({ ...formData, shopName: e.target.value })}
                />
              </div>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="দোকানের ঠিকানা"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  value={formData.shopAddress}
                  onChange={(e) => setFormData({ ...formData, shopAddress: e.target.value })}
                />
              </div>
            </>
          )}

          {!isLogin && !isCompletingProfile && (
            <div className="relative">
              <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <input
                type="email"
                placeholder="ইমেইল"
                required
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
          )}

          {!isLogin && !isCompletingProfile && (
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <input
                type={showPassword ? "text" : "password"}
                placeholder="পাসওয়ার্ড"
                required
                className="w-full pl-10 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          )}

          {isLogin && (
            <>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="email"
                  placeholder="ইমেইল"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="পাসওয়ার্ড"
                  required
                  className="w-full pl-10 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-sm text-emerald-600 hover:underline font-medium"
              >
                পাসওয়ার্ড ভুলে গেছেন?
              </button>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-200 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-70"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
              <>
                {isLogin ? 'লগইন করুন' : (isCompletingProfile ? 'প্রোফাইল তৈরি করুন' : 'রেজিস্ট্রেশন করুন')}
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>

          {isCompletingProfile && (
            <button
              type="button"
              onClick={() => logout()}
              className="w-full text-slate-500 text-sm font-medium hover:underline"
            >
              অন্য অ্যাকাউন্ট দিয়ে লগইন করুন
            </button>
          )}
        </form>
      </motion.div>
    </div>
  );
};
