import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calculator, 
  X, 
  Delete, 
  Plus, 
  Minus, 
  Divide, 
  Equal,
  Save,
  Check,
  PlusCircle,
  List,
  Trash2,
  ChevronDown,
  Percent,
  History,
  ArrowLeft
} from 'lucide-react';
import { cn } from '../lib/utils';

interface CalculationItem {
  id: string;
  name: string;
  amount: number;
  selected: boolean;
  equation: string;
}

interface SmartCalculatorProps {
  onSave?: (result: number) => void;
  onClose: () => void;
}

export const SmartCalculator: React.FC<SmartCalculatorProps> = ({ onSave, onClose }) => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [items, setItems] = useState<CalculationItem[]>([]);
  const [showList, setShowList] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [itemName, setItemName] = useState('');

  const handleNumber = (num: string) => {
    if (display === '0') {
      setDisplay(num);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (op: string) => {
    if (display === 'Error') return;
    setEquation(display + ' ' + op + ' ');
    setDisplay('0');
  };

  const handlePercent = () => {
    try {
      const val = parseFloat(display);
      if (isNaN(val)) return;
      const result = val / 100;
      setDisplay(result.toString());
    } catch (e) {
      setDisplay('Error');
    }
  };

  const calculate = () => {
    try {
      const fullEq = equation + display;
      // Simple eval-like logic for basic operators
      const result = eval(fullEq.replace('×', '*').replace('÷', '/'));
      setDisplay(result.toString());
      setEquation('');
      setHistory([...history, display + ' = ' + result]);
      return result;
    } catch (e) {
      setDisplay('Error');
      return null;
    }
  };

  const addItem = () => {
    let finalAmount = Number(display);
    let finalEq = equation + display;
    
    // If there's an ongoing equation, calculate it first
    if (equation) {
      const res = calculate();
      if (res !== null) {
        finalAmount = res;
      } else {
        return;
      }
    }

    if (finalAmount <= 0) return;

    const newItem: CalculationItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: itemName || `আইটেম ${items.length + 1}`,
      amount: finalAmount,
      selected: true,
      equation: finalEq
    };

    setItems([...items, newItem]);
    setItemName('');
    setDisplay('0');
    setEquation('');
    setShowList(true);
  };

  const toggleItem = (id: string) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, selected: !item.selected } : item
    ));
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const clear = () => {
    setDisplay('0');
    setEquation('');
    setHistory([]);
  };

  const totalSelected = items
    .filter(item => item.selected)
    .reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
      />
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative w-full max-w-md bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-800 flex flex-col max-h-[90vh]"
      >
        <div className="p-6 bg-slate-800/50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-emerald-500">
            <Calculator className="w-5 h-5" />
            <span className="font-bold">স্মার্ট ক্যালকুলেটর</span>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className="p-2 hover:bg-slate-700 rounded-xl text-slate-400"
              title="History"
            >
              <History className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setShowList(!showList)}
              className="p-2 hover:bg-slate-700 rounded-xl text-slate-400 flex items-center gap-2"
            >
              <List className="w-5 h-5" />
              <span className="text-xs font-bold bg-emerald-500 text-white px-2 py-0.5 rounded-full">
                {items.length}
              </span>
            </button>
            <button onClick={onClose} className="p-2 hover:bg-slate-700 rounded-full text-slate-400">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {showHistory ? (
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <button onClick={() => setShowHistory(false)} className="p-2 hover:bg-slate-800 rounded-full text-slate-400">
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h3 className="text-white font-bold">হিসাবের ইতিহাস</h3>
              </div>
              {history.length === 0 ? (
                <p className="text-slate-500 text-center py-12">কোনো ইতিহাস নেই</p>
              ) : (
                <div className="space-y-3">
                  {history.map((h, i) => (
                    <div key={i} className="p-3 bg-slate-800/50 rounded-xl border border-slate-700 text-right">
                      <p className="text-slate-400 text-xs">{h.split('=')[0]}</p>
                      <p className="text-emerald-500 font-bold text-lg">{h.split('=')[1] || h}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : !showList ? (
            <div className="p-6 space-y-6">
              <div className="text-right space-y-2">
                <div className="text-slate-500 text-sm font-medium h-6 overflow-hidden whitespace-nowrap">
                  {equation}
                </div>
                <div className="text-5xl font-black text-white overflow-hidden whitespace-nowrap">
                  {display}
                </div>
              </div>

              <div className="space-y-4">
                <input 
                  type="text"
                  placeholder="আইটেমের নাম (ঐচ্ছিক)"
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  className="w-full bg-slate-800 border-none rounded-2xl px-4 py-3 text-white placeholder:text-slate-500 focus:ring-2 focus:ring-emerald-500 transition-all"
                />

                <div className="grid grid-cols-4 gap-3">
                  <button onClick={clear} className="py-4 rounded-2xl bg-slate-800 text-rose-400 font-bold hover:bg-slate-700 transition-all">AC</button>
                  <button onClick={() => setDisplay(display.slice(0, -1) || '0')} className="py-4 rounded-2xl bg-slate-800 text-slate-400 font-bold hover:bg-slate-700 transition-all flex items-center justify-center">
                    <Delete className="w-5 h-5" />
                  </button>
                  <button onClick={handlePercent} className="py-4 rounded-2xl bg-slate-800 text-emerald-500 font-bold hover:bg-slate-700 transition-all flex items-center justify-center">
                    <Percent className="w-5 h-5" />
                  </button>
                  <button onClick={() => handleOperator('÷')} className="py-4 rounded-2xl bg-emerald-600/20 text-emerald-500 font-bold hover:bg-emerald-600/30 transition-all flex items-center justify-center">
                    <Divide className="w-5 h-5" />
                  </button>

                  {['7', '8', '9'].map(n => (
                    <button key={n} onClick={() => handleNumber(n)} className="py-4 rounded-2xl bg-slate-800 text-white font-bold hover:bg-slate-700 transition-all">{n}</button>
                  ))}
                  <button onClick={() => handleOperator('×')} className="py-4 rounded-2xl bg-emerald-600/20 text-emerald-500 font-bold hover:bg-emerald-600/30 transition-all flex items-center justify-center">
                    <X className="w-5 h-5" />
                  </button>

                  {['4', '5', '6'].map(n => (
                    <button key={n} onClick={() => handleNumber(n)} className="py-4 rounded-2xl bg-slate-800 text-white font-bold hover:bg-slate-700 transition-all">{n}</button>
                  ))}
                  <button onClick={() => handleOperator('-')} className="py-4 rounded-2xl bg-emerald-600/20 text-emerald-500 font-bold hover:bg-emerald-600/30 transition-all flex items-center justify-center">
                    <Minus className="w-5 h-5" />
                  </button>

                  {['1', '2', '3'].map(n => (
                    <button key={n} onClick={() => handleNumber(n)} className="py-4 rounded-2xl bg-slate-800 text-white font-bold hover:bg-slate-700 transition-all">{n}</button>
                  ))}
                  <button onClick={() => handleOperator('+')} className="py-4 rounded-2xl bg-emerald-600/20 text-emerald-500 font-bold hover:bg-emerald-600/30 transition-all flex items-center justify-center">
                    <Plus className="w-5 h-5" />
                  </button>

                  <button onClick={() => handleNumber('0')} className="col-span-2 py-4 rounded-2xl bg-slate-800 text-white font-bold hover:bg-slate-700 transition-all">0</button>
                  <button onClick={() => handleNumber('.')} className="py-4 rounded-2xl bg-slate-800 text-white font-bold hover:bg-slate-700 transition-all">.</button>
                  <button onClick={calculate} className="py-4 rounded-2xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition-all flex items-center justify-center shadow-lg shadow-emerald-900/20">
                    <Equal className="w-6 h-6" />
                  </button>
                </div>

                <button 
                  onClick={addItem}
                  className="w-full py-4 bg-slate-800 text-emerald-500 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-700 transition-all border border-emerald-500/20"
                >
                  <PlusCircle className="w-5 h-5" />
                  লিস্টে যোগ করুন
                </button>
              </div>
            </div>
          ) : (
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-bold">হিসাবের লিস্ট</h3>
                <button 
                  onClick={() => setItems([])}
                  className="text-rose-400 text-xs font-bold flex items-center gap-1 hover:bg-rose-400/10 px-2 py-1 rounded-lg transition-all"
                >
                  <Trash2 className="w-3 h-3" />
                  সব মুছুন
                </button>
              </div>

              {items.length === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto text-slate-600">
                    <List className="w-8 h-8" />
                  </div>
                  <p className="text-slate-500 text-sm">লিস্টে কোনো আইটেম নেই</p>
                  <button 
                    onClick={() => setShowList(false)}
                    className="text-emerald-500 text-xs font-bold"
                  >
                    ক্যালকুলেটর ফিরে যান
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {items.map((item) => (
                    <div 
                      key={item.id}
                      className={cn(
                        "p-4 rounded-2xl border transition-all flex items-center gap-4",
                        item.selected ? "bg-emerald-500/10 border-emerald-500/30" : "bg-slate-800/50 border-slate-700"
                      )}
                    >
                      <button 
                        onClick={() => toggleItem(item.id)}
                        className={cn(
                          "w-6 h-6 rounded-lg flex items-center justify-center transition-all",
                          item.selected ? "bg-emerald-500 text-white" : "bg-slate-700 text-transparent"
                        )}
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-bold truncate">{item.name}</p>
                        <p className="text-slate-500 text-[10px] font-medium">{item.equation}</p>
                      </div>

                      <div className="text-right">
                        <p className="text-emerald-500 font-black">{item.amount} ৳</p>
                        <button 
                          onClick={() => removeItem(item.id)}
                          className="text-rose-400 p-1 hover:bg-rose-400/10 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <button 
                onClick={() => setShowList(false)}
                className="w-full py-3 bg-slate-800 text-slate-400 rounded-2xl font-bold text-sm hover:bg-slate-700 transition-all"
              >
                আরো আইটেম যোগ করুন
              </button>
            </div>
          )}
        </div>

        <div className="p-6 bg-slate-800/50 border-t border-slate-700 shrink-0">
          <div className="flex items-center justify-between mb-4">
            <div className="text-slate-400 text-sm font-medium">মোট সিলেক্টেড:</div>
            <div className="text-2xl font-black text-white">{totalSelected} ৳</div>
          </div>

          {onSave && (
            <button 
              onClick={() => onSave(totalSelected || Number(display))}
              disabled={totalSelected === 0 && display === '0'}
              className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="w-5 h-5" />
              এন্ট্রি হিসেবে সেভ করুন
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
