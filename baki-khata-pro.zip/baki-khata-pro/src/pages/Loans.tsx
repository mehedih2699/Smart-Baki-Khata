import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  HandCoins, 
  Phone, 
  MapPin, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  ChevronRight,
  UserPlus,
  ArrowLeft,
  Edit2,
  Calculator
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  getDocs,
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  increment
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Loaner, LoanTransaction } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';

export const LoansPage: React.FC = () => {
  const { user } = useAuth();
  const [loaners, setLoaners] = useState<Loaner[]>([]);
  const [selectedLoanerId, setSelectedLoanerId] = useState<string | null>(null);
  const [showAddLoanerModal, setShowAddLoanerModal] = useState(false);
  const [editingLoaner, setEditingLoaner] = useState<Loaner | null>(null);
  const [loading, setLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'loaner', id: string } | null>(null);

  // Form states for new loaner
  const [newLoaner, setNewLoaner] = useState({ name: '', phone: '', address: '' });

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'loaners'), where('ownerUid', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setLoaners(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Loaner)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'loaners'));
    return () => unsubscribe();
  }, [user]);

  const handleAddLoaner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLoaner.name || !user) return;

    setLoading(true);
    try {
      if (editingLoaner) {
        await updateDoc(doc(db, 'loaners', editingLoaner.id), newLoaner);
        toast.success('আপডেট করা হয়েছে');
      } else {
        await addDoc(collection(db, 'loaners'), {
          ...newLoaner,
          totalTaken: 0,
          totalPaid: 0,
          ownerUid: user.uid
        });
        toast.success('লোন গ্রহীতা যোগ করা হয়েছে');
      }
      setShowAddLoanerModal(false);
      setEditingLoaner(null);
      setNewLoaner({ name: '', phone: '', address: '' });
    } catch (error) {
      handleFirestoreError(error, editingLoaner ? OperationType.UPDATE : OperationType.CREATE, editingLoaner ? `loaners/${editingLoaner.id}` : 'loaners');
    } finally {
      setLoading(false);
    }
  };

  const handleEditLoaner = (e: React.MouseEvent, loaner: Loaner) => {
    e.stopPropagation();
    setEditingLoaner(loaner);
    setNewLoaner({ name: loaner.name, phone: loaner.phone, address: loaner.address });
    setShowAddLoanerModal(true);
  };

  const handleDeleteLoaner = (e: React.MouseEvent, loanerId: string) => {
    e.stopPropagation();
    setConfirmDelete({ type: 'loaner', id: loanerId });
  };

  const executeDeleteLoaner = async () => {
    if (!confirmDelete || !confirmDelete.id) return;
    const loanerId = confirmDelete.id;
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'loaners', loanerId));
      const q = query(collection(db, 'loanTransactions'), where('loanerId', '==', loanerId));
      const snapshot = await getDocs(q);
      snapshot.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
      toast.success('লোন গ্রহীতা মুছে ফেলা হয়েছে');
      if (selectedLoanerId === loanerId) {
        setSelectedLoanerId(null);
      }
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    } finally {
      setConfirmDelete(null);
    }
  };

  if (selectedLoanerId) {
    return <LoanerDetail loanerId={selectedLoanerId} onBack={() => setSelectedLoanerId(null)} />;
  }

  const totalLoanGiven = loaners.reduce((acc, curr) => acc + (curr.totalTaken - curr.totalPaid), 0);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800 px-1">লোন হিসাব</h2>

      {/* Summary Card */}
      <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-8 rounded-[2.5rem] text-white shadow-xl shadow-amber-100 flex items-center justify-between overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl" />
        <div className="relative z-10">
          <p className="text-amber-100 text-xs font-bold uppercase tracking-widest mb-1">মোট পাওনা লোন</p>
          <h3 className="text-4xl font-black">{formatCurrency(totalLoanGiven)}</h3>
        </div>
        <div className="relative z-10 w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
          <HandCoins className="w-10 h-10" />
        </div>
      </div>

      <button 
        onClick={() => setShowAddLoanerModal(true)}
        className="w-full flex items-center justify-center gap-2 py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold shadow-sm hover:border-amber-500 hover:text-amber-600 transition-all active:scale-95"
      >
        <UserPlus className="w-5 h-5" />
        নতুন লোন গ্রহীতা যোগ করুন
      </button>

      {/* Loaners List */}
      <div className="space-y-4">
        <h4 className="font-bold text-slate-700 px-1">লোন গ্রহীতা তালিকা</h4>
        {loaners.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">এখনো কোন লোন গ্রহীতা নেই</p>
          </div>
        ) : (
          loaners.map((loaner) => (
            <motion.div
              key={loaner.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedLoanerId(loaner.id)}
              className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center font-bold text-lg">
                  {loaner.name[0]}
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">{loaner.name}</h5>
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Phone className="w-3 h-3" />
                    {loaner.phone}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <p className="font-bold text-amber-600">{formatCurrency(loaner.totalTaken - loaner.totalPaid)}</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">পাওনা</p>
                </div>
                <div className="flex items-center gap-1 transition-all">
                  <button 
                    onClick={(e) => handleEditLoaner(e, loaner)}
                    className="p-2 text-slate-400 hover:text-amber-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={(e) => handleDeleteLoaner(e, loaner.id)}
                    className="p-2 text-slate-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300" />
              </div>
            </motion.div>
          ))
        )}
      </div>

      <ConfirmModal
        isOpen={confirmDelete?.type === 'loaner'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteLoaner}
        title="লোন গ্রহীতা মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই লোন গ্রহীতাকে মুছতে চান? তার সকল লেনদেনও মুছে যাবে।"
      />

      <AnimatePresence>
        {showAddLoanerModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddLoanerModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingLoaner ? 'লোন গ্রহীতা এডিট' : 'নতুন লোন গ্রহীতা'}
                </h3>
                <button onClick={() => {
                  setShowAddLoanerModal(false);
                  setEditingLoaner(null);
                  setNewLoaner({ name: '', phone: '', address: '' });
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddLoaner} className="space-y-4">
                <input
                  type="text"
                  placeholder="নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={newLoaner.name}
                  onChange={(e) => setNewLoaner({ ...newLoaner, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন নম্বর"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={newLoaner.phone}
                  onChange={(e) => setNewLoaner({ ...newLoaner, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={newLoaner.address}
                  onChange={(e) => setNewLoaner({ ...newLoaner, address: e.target.value })}
                />

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-amber-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-amber-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      যোগ করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const LoanerDetail: React.FC<{ loanerId: string; onBack: () => void }> = ({ loanerId, onBack }) => {
  const { user } = useAuth();
  const [loaner, setLoaner] = useState<Loaner | null>(null);
  const [transactions, setTransactions] = useState<LoanTransaction[]>([]);
  const [showAddModal, setShowAddModal] = useState<'loan' | 'payment' | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<LoanTransaction | null>(null);
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [editLoaner, setEditLoaner] = useState({ name: '', phone: '', address: '' });
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'transaction' | 'all' | 'loaner', transaction?: LoanTransaction } | null>(null);

  useEffect(() => {
    const unsubLoaner = onSnapshot(doc(db, 'loaners', loanerId), (doc) => {
      if (doc.exists()) {
        const data = doc.data() as Loaner;
        setLoaner({ id: doc.id, ...data } as Loaner);
        setEditLoaner({ name: data.name, phone: data.phone, address: data.address });
      }
    }, (error) => {
      console.error('Loaner Detail Snapshot Error:', error);
    });

    const q = query(
      collection(db, 'loanTransactions'),
      where('loanerId', '==', loanerId),
      orderBy('date', 'desc')
    );
    const unsubTrans = onSnapshot(q, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LoanTransaction)));
    }, (error) => {
      console.error('Loan Transactions Snapshot Error:', error);
    });

    return () => {
      unsubLoaner();
      unsubTrans();
    };
  }, [loanerId]);

  const handleTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !user) return;

    setLoading(true);
    const numAmount = Number(amount);
    const type = showAddModal!;

    try {
      const batch = writeBatch(db);
      
      if (editingTransaction) {
        const transRef = doc(db, 'loanTransactions', editingTransaction.id);
        const diff = numAmount - editingTransaction.amount;
        
        batch.update(transRef, {
          amount: numAmount,
          note,
        });

        const loanerRef = doc(db, 'loaners', loanerId);
        if (editingTransaction.type === 'loan') {
          batch.update(loanerRef, { totalTaken: increment(diff) });
        } else {
          batch.update(loanerRef, { totalPaid: increment(diff) });
        }
      } else {
        const transRef = doc(collection(db, 'loanTransactions'));
        batch.set(transRef, {
          loanerId,
          amount: numAmount,
          type,
          note,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });

        const loanerRef = doc(db, 'loaners', loanerId);
        if (type === 'loan') {
          batch.update(loanerRef, { totalTaken: increment(numAmount) });
        } else {
          batch.update(loanerRef, { totalPaid: increment(numAmount) });
        }
      }

      await batch.commit();
      toast.success(editingTransaction ? 'আপডেট করা হয়েছে' : (type === 'loan' ? 'লোন যোগ করা হয়েছে' : 'পেমেন্ট যোগ করা হয়েছে'));
      setShowAddModal(null);
      setEditingTransaction(null);
      setAmount('');
      setNote('');
    } catch (error) {
      toast.error('কিছু সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleCalculatorSave = (result: number) => {
    setAmount(result.toString());
    setShowCalculator(false);
  };

  const handleDeleteTransaction = (transaction: LoanTransaction) => {
    setConfirmDelete({ type: 'transaction', transaction });
  };

  const executeDeleteTransaction = async () => {
    if (!confirmDelete || !confirmDelete.transaction) return;
    const transaction = confirmDelete.transaction;
    setLoading(true);
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'loanTransactions', transaction.id));
      
      const loanerRef = doc(db, 'loaners', loanerId);
      if (transaction.type === 'loan') {
        batch.update(loanerRef, { totalTaken: increment(-transaction.amount) });
      } else {
        batch.update(loanerRef, { totalPaid: increment(-transaction.amount) });
      }
      
      await batch.commit();
      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
      setConfirmDelete(null);
    }
  };

  const handleDeleteAllTransactions = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAllTransactions = async () => {
    setLoading(true);
    try {
      const batch = writeBatch(db);
      transactions.forEach(t => batch.delete(doc(db, 'loanTransactions', t.id)));
      
      const loanerRef = doc(db, 'loaners', loanerId);
      batch.update(loanerRef, { totalTaken: 0, totalPaid: 0 });
      
      await batch.commit();
      toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
      setConfirmDelete(null);
    }
  };

  const handleDeleteLoanerProfile = () => {
    setConfirmDelete({ type: 'loaner' });
  };

  const executeDeleteLoanerProfile = async () => {
    setLoading(true);
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'loaners', loanerId));
      const q = query(collection(db, 'loanTransactions'), where('loanerId', '==', loanerId));
      const snapshot = await getDocs(q);
      snapshot.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
      toast.success('লোন গ্রহীতা মুছে ফেলা হয়েছে');
      onBack();
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
      setConfirmDelete(null);
    }
  };

  const handleEditTransaction = (transaction: LoanTransaction) => {
    setEditingTransaction(transaction);
    setAmount(transaction.amount.toString());
    setNote(transaction.note || '');
    setShowAddModal(transaction.type);
  };

  const handleEditLoanerProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editLoaner.name || !user) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'loaners', loanerId), editLoaner);
      toast.success('লোন গ্রহীতা আপডেট করা হয়েছে');
      setShowEditModal(false);
    } catch (error) {
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  if (!loaner) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-white rounded-xl transition-all">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <h2 className="text-xl font-bold text-slate-800">{loaner.name}</h2>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowEditModal(true)}
            className="p-2 text-slate-400 hover:bg-white rounded-xl transition-all"
          >
            <Edit2 className="w-5 h-5" />
          </button>
          <button 
            onClick={handleDeleteLoanerProfile}
            className="p-2 text-rose-400 hover:bg-rose-50 rounded-xl transition-all"
          >
            <Trash2 className="w-5 h-5" />
          </button>
      </div>
    </div>

      <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 text-center">
        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">মোট পাওনা</p>
        <h3 className="text-4xl font-black text-amber-600 mb-6">
          {formatCurrency(loaner.totalTaken - loaner.totalPaid)}
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-50 p-3 rounded-2xl">
            <p className="text-[10px] text-slate-400 font-bold uppercase">মোট লোন</p>
            <p className="font-bold text-slate-700">{formatCurrency(loaner.totalTaken)}</p>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl">
            <p className="text-[10px] text-slate-400 font-bold uppercase">মোট পরিশোধ</p>
            <p className="font-bold text-slate-700">{formatCurrency(loaner.totalPaid)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <button 
          onClick={() => setShowAddModal('loan')}
          className="flex items-center justify-center gap-2 py-4 bg-amber-600 text-white rounded-2xl font-bold shadow-lg shadow-amber-100 active:scale-95 transition-all"
        >
          <Plus className="w-5 h-5" />
          লোন দিন
        </button>
        <button 
          onClick={() => setShowAddModal('payment')}
          className="flex items-center justify-center gap-2 py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all"
        >
          <Check className="w-5 h-5" />
          পেমেন্ট নিন
        </button>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
          {transactions.length > 0 && (
            <button 
              onClick={handleDeleteAllTransactions}
              className="text-rose-500 text-xs font-bold flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              সব মুছুন
            </button>
          )}
        </div>
        {transactions.map((t) => (
          <div key={t.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
            <div className="flex items-center gap-4">
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center",
                t.type === 'loan' ? "bg-amber-50 text-amber-500" : "bg-emerald-50 text-emerald-500"
              )}>
                {t.type === 'loan' ? <Plus className="w-5 h-5" /> : <Check className="w-5 h-5" />}
              </div>
              <div>
                <h5 className="font-bold text-slate-800">{formatCurrency(t.amount)}</h5>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold">
                  <Calendar className="w-3 h-3" />
                  {formatDate(t.date)}
                  {t.note && <span className="flex items-center gap-1 ml-2"><FileText className="w-3 h-3" /> {t.note}</span>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1 transition-all">
              <button 
                onClick={() => handleEditTransaction(t)}
                className="p-2 text-slate-400 hover:text-amber-600"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button 
                onClick={() => handleDeleteTransaction(t)}
                className="p-2 text-slate-400 hover:text-rose-500"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'loaner'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteLoanerProfile}
        title="লোন গ্রহীতা মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই লোন গ্রহীতাকে মুছতে চান? তার সকল লেনদেনও মুছে যাবে।"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'transaction'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteTransaction}
        title="লেনদেন মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই লেনদেনটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAllTransactions}
        title="সব লেনদেন মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল লেনদেন মুছতে চান? এতে ব্যালেন্স ০ হয়ে যাবে।"
      />

      <AnimatePresence>
        {showEditModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEditModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">লোন গ্রহীতা এডিট করুন</h3>
                <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleEditLoanerProfile} className="space-y-4">
                <input
                  type="text"
                  placeholder="নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={editLoaner.name}
                  onChange={(e) => setEditLoaner({ ...editLoaner, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন নম্বর"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={editLoaner.phone}
                  onChange={(e) => setEditLoaner({ ...editLoaner, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={editLoaner.address}
                  onChange={(e) => setEditLoaner({ ...editLoaner, address: e.target.value })}
                />

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-amber-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-amber-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      আপডেট করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingTransaction ? 'লেনদেন এডিট' : (showAddModal === 'loan' ? 'লোন দিন' : 'পেমেন্ট নিন')}
                </h3>
                <button onClick={() => {
                  setShowAddModal(null);
                  setEditingTransaction(null);
                  setAmount('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleTransaction} className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <label className="text-sm font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button 
                      type="button"
                      onClick={() => setShowCalculator(true)}
                      className="text-amber-600 text-xs font-bold flex items-center gap-1"
                    >
                      <Calculator className="w-3 h-3" />
                      ক্যালকুলেটর
                    </button>
                  </div>
                  <input
                    type="number"
                    placeholder="টাকার পরিমাণ"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-amber-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>
                <input
                  type="text"
                  placeholder="নোট (ঐচ্ছিক)"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-4 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95",
                    showAddModal === 'loan' ? "bg-amber-600 shadow-amber-100" : "bg-emerald-600 shadow-emerald-100"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={() => setShowCalculator(false)} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
