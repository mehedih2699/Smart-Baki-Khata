import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2, 
  Calendar,
  Edit3,
  Search
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Note } from '../types';
import { formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';

export const NotesPage: React.FC = () => {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [showModal, setShowModal] = useState<Note | 'new' | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'notes'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setNotes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Note)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'notes'));
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (showModal && typeof showModal === 'object') {
      setTitle(showModal.title);
      setContent(showModal.content);
    } else {
      setTitle('');
      setContent('');
    }
  }, [showModal]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !user) return;

    setLoading(true);
    try {
      if (showModal === 'new') {
        await addDoc(collection(db, 'notes'), {
          title,
          content,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });
        toast.success('নোট সেভ করা হয়েছে');
      } else if (showModal && typeof showModal === 'object') {
        await updateDoc(doc(db, 'notes', showModal.id), {
          title,
          content
        });
        toast.success('নোট আপডেট করা হয়েছে');
      }
      setShowModal(null);
    } catch (error) {
      handleFirestoreError(error, showModal === 'new' ? OperationType.CREATE : OperationType.UPDATE, showModal === 'new' ? 'notes' : `notes/${(showModal as Note).id}`);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('আপনি কি নিশ্চিতভাবে এই নোটটি মুছতে চান?')) return;
    try {
      await deleteDoc(doc(db, 'notes', id));
      toast.success('নোট মুছে ফেলা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `notes/${id}`);
    }
  };

  const handleDeleteAll = async () => {
    if (!confirm('আপনি কি নিশ্চিতভাবে সকল নোট মুছে ফেলতে চান?')) return;
    try {
      const batch = writeBatch(db);
      notes.forEach(n => batch.delete(doc(db, 'notes', n.id)));
      await batch.commit();
      toast.success('সকল নোট মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    }
  };

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    n.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (showModal) {
    return (
      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="fixed inset-0 z-[60] bg-slate-50 flex flex-col"
      >
        {/* Header */}
        <div className="bg-white border-b border-slate-200 px-4 py-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowModal(null)}
              className="p-2 hover:bg-slate-100 rounded-xl transition-all"
            >
              <X className="w-6 h-6 text-slate-500" />
            </button>
            <h2 className="text-xl font-bold text-slate-800">
              {showModal === 'new' ? 'নতুন নোট' : 'নোট এডিট করুন'}
            </h2>
          </div>
          <button
            onClick={handleSave}
            disabled={loading || !title}
            className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" />}
            সেভ করুন
          </button>
        </div>

        {/* Editor Content */}
        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-y-auto">
          <input
            type="text"
            placeholder="শিরোনাম লিখুন..."
            required
            className="w-full p-4 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold text-xl shadow-sm"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <textarea
            placeholder="বিস্তারিত এখানে লিখুন..."
            className="w-full flex-1 p-6 bg-white border border-slate-200 rounded-3xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-lg leading-relaxed shadow-sm min-h-[60vh]"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-bold text-slate-800">নোটস</h2>
        <div className="flex items-center gap-2">
          {notes.length > 0 && (
            <button 
              onClick={handleDeleteAll}
              className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
              title="সব মুছুন"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
          <button 
            onClick={() => setShowModal('new')}
            className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-100 active:scale-90 transition-all"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="নোট খুঁজুন..."
          className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-sm"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredNotes.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">কোন নোট পাওয়া যায়নি</p>
          </div>
        ) : (
          filteredNotes.map((note) => (
            <motion.div
              key={note.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => setShowModal(note)}
              className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm group relative"
            >
              <h3 className="font-bold text-lg text-slate-800 mb-2">{note.title}</h3>
              <p className="text-slate-500 text-sm line-clamp-3 mb-4">{note.content}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  <Calendar className="w-3 h-3" />
                  {formatDate(note.date)}
                </div>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(note.id);
                  }}
                  className="p-2 text-slate-300 hover:text-rose-500 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
