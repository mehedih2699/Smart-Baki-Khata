import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings, 
  Lock, 
  Store, 
  MapPin, 
  User, 
  Shield, 
  Download, 
  Upload, 
  Trash2, 
  ChevronRight,
  Check,
  Loader2,
  Image as ImageIcon,
  X,
  AlertTriangle,
  Plus,
  Palette,
  Zap,
  Tag
} from 'lucide-react';
import { doc, updateDoc, deleteDoc, collection, getDocs, query, where, writeBatch } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db, auth } from '../firebase';
import { useAuth } from '../AuthContext';
import { cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { deleteUser } from 'firebase/auth';

export const SettingsPage: React.FC = () => {
  const { user, refreshUser, logout } = useAuth();
  const [loading, setLoading] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [showPinModal, setShowPinModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [activeTab, setActiveTab] = useState<'profile' | 'app' | 'data'>('profile');
  
  // Profile Edit State
  const [editProfile, setEditProfile] = useState({
    ownerName: user?.ownerName || '',
    shopName: user?.shopName || '',
    shopAddress: user?.shopAddress || '',
  });

  // Quick Buttons State
  const [quickButtons, setQuickButtons] = useState<number[]>(user?.quickButtons || [10, 20, 50, 100, 500]);
  const [newQuickButton, setNewQuickButton] = useState('');

  // Debt Limits State
  const [debtLimits, setDebtLimits] = useState(user?.debtLimits || { green: 1000, orange: 5000, red: 10000 });

  // Cash Categories State
  const [cashCategories, setCashCategories] = useState<string[]>(user?.cashCategories || ['বিক্রি', 'ক্রয়', 'খরচ', 'অন্যান্য']);
  const [newCategory, setNewCategory] = useState('');

  const updateProfile = async (data: any) => {
    if (!user) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), data);
      await refreshUser();
      toast.success('তথ্য আপডেট করা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setLoading(false);
    }
  };

  const handlePinToggle = async () => {
    if (!user) return;
    if (!user.pinEnabled && !user.pin) {
      setShowPinModal(true);
      return;
    }
    await updateProfile({ pinEnabled: !user.pinEnabled });
  };

  const handleSetPin = async () => {
    if (newPin.length !== 4) {
      toast.error('পিন ৪ ডিজিটের হতে হবে');
      return;
    }
    await updateProfile({ pin: newPin, pinEnabled: true });
    setShowPinModal(false);
    setNewPin('');
  };

  const importData = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        setLoading(true);

        const collections = [
          'customers', 'transactions', 'cashEntries', 
          'savings', 'loaners', 'loanTransactions', 'notes'
        ];

        for (const collName of collections) {
          if (data[collName] && Array.isArray(data[collName])) {
            const batch = writeBatch(db);
            data[collName].forEach((item: any) => {
              const { id, ...rest } = item;
              const docRef = doc(collection(db, collName));
              batch.set(docRef, { ...rest, ownerUid: user.uid });
            });
            await batch.commit();
          }
        }

        toast.success('ডাটা সফলভাবে ইমপোর্ট করা হয়েছে');
      } catch (error) {
        console.error(error);
        toast.error('ডাটা ইমপোর্ট করতে সমস্যা হয়েছে');
      } finally {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const exportData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const collections = ['customers', 'transactions', 'cashEntries', 'savings', 'loaners', 'loanTransactions', 'notes'];
      const data: any = { profile: user };
      
      for (const col of collections) {
        const q = query(collection(db, col), where('ownerUid', '==', user.uid));
        const snapshot = await getDocs(q);
        data[col] = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      }

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `bakikhata_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success('ডাটা এক্সপোর্ট সফল হয়েছে');
    } catch (error) {
      console.error(error);
      toast.error('এক্সপোর্ট করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user || !auth.currentUser) return;
    setLoading(true);
    try {
      // 1. Delete all user data from Firestore
      const collections = ['customers', 'transactions', 'cashEntries', 'savings', 'loaners', 'loanTransactions', 'notes', 'users'];
      const batch = writeBatch(db);
      
      for (const col of collections) {
        const q = query(collection(db, col), where('ownerUid', '==', user.uid));
        if (col === 'users') {
          batch.delete(doc(db, 'users', user.uid));
        } else {
          const snapshot = await getDocs(q);
          snapshot.docs.forEach(d => batch.delete(d.ref));
        }
      }
      
      await batch.commit();

      // 2. Delete Auth user
      await deleteUser(auth.currentUser);
      
      toast.success('অ্যাকাউন্ট মুছে ফেলা হয়েছে');
      logout();
    } catch (error: any) {
      console.error(error);
      if (error.code === 'auth/requires-recent-login') {
        toast.error('নিরাপত্তার জন্য পুনরায় লগইন করে চেষ্টা করুন');
      } else {
        toast.error('মুছে ফেলতে সমস্যা হয়েছে');
      }
    } finally {
      setLoading(false);
      setShowDeleteModal(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-bold text-slate-800">সেটিংস</h2>
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button 
            onClick={() => setActiveTab('profile')}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-bold transition-all",
              activeTab === 'profile' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500"
            )}
          >প্রোফাইল</button>
          <button 
            onClick={() => setActiveTab('app')}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-bold transition-all",
              activeTab === 'app' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500"
            )}
          >অ্যাপ</button>
          <button 
            onClick={() => setActiveTab('data')}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-bold transition-all",
              activeTab === 'data' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500"
            )}
          >ডাটা</button>
        </div>
      </div>

      {activeTab === 'profile' && (
        <div className="space-y-6">
          {/* Profile Info */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-6">
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="w-24 h-24 bg-slate-100 rounded-[2rem] flex items-center justify-center text-slate-400 relative overflow-hidden group cursor-pointer border-4 border-white shadow-xl">
                {user?.shopLogo ? (
                  <img src={user.shopLogo} alt="Logo" className="w-full h-full object-cover" />
                ) : (
                  <ImageIcon className="w-10 h-10" />
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                  <Upload className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="text-center">
                <h3 className="font-bold text-xl text-slate-800">{user?.shopName}</h3>
                <p className="text-sm text-slate-500">{user?.ownerName}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">দোকানের নাম</label>
                <div className="relative">
                  <Store className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input 
                    type="text"
                    value={editProfile.shopName}
                    onChange={(e) => setEditProfile({ ...editProfile, shopName: e.target.value })}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">মালিকের নাম</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input 
                    type="text"
                    value={editProfile.ownerName}
                    onChange={(e) => setEditProfile({ ...editProfile, ownerName: e.target.value })}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">ঠিকানা</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input 
                    type="text"
                    value={editProfile.shopAddress}
                    onChange={(e) => setEditProfile({ ...editProfile, shopAddress: e.target.value })}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold"
                  />
                </div>
              </div>

              <button 
                onClick={() => updateProfile(editProfile)}
                disabled={loading}
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" />}
                তথ্য সেভ করুন
              </button>
            </div>
          </div>

          {/* Security */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
            <h4 className="font-bold text-slate-700 flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600" />
              নিরাপত্তা সেটিংস
            </h4>
            
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
              <div>
                <p className="font-bold text-slate-800">পিন লক</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase">অ্যাপ খোলার সময় পিন চাইবে</p>
              </div>
              <button 
                onClick={handlePinToggle}
                className={cn(
                  "w-12 h-6 rounded-full transition-all relative",
                  user?.pinEnabled ? "bg-emerald-500" : "bg-slate-300"
                )}
              >
                <div className={cn(
                  "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                  user?.pinEnabled ? "right-1" : "left-1"
                )} />
              </button>
            </div>

            <button 
              onClick={() => setShowPinModal(true)}
              className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-600 shadow-sm">
                  <Lock className="w-5 h-5" />
                </div>
                <p className="font-bold text-slate-800">পিন পরিবর্তন করুন</p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300" />
            </button>
          </div>
        </div>
      )}

      {activeTab === 'app' && (
        <div className="space-y-6">
          {/* Quick Buttons */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
            <h4 className="font-bold text-slate-700 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              কুইক বাটন সেটিংস
            </h4>
            <p className="text-xs text-slate-400">বাকি বা জমা দেওয়ার সময় এই বাটনগুলো দেখাবে</p>
            
            <div className="flex flex-wrap gap-2">
              {quickButtons.map((btn, idx) => (
                <div key={idx} className="flex items-center gap-1 bg-slate-100 px-3 py-2 rounded-xl border border-slate-200">
                  <span className="font-bold text-slate-700">{btn}</span>
                  <button 
                    onClick={() => {
                      const newBtns = quickButtons.filter((_, i) => i !== idx);
                      setQuickButtons(newBtns);
                      updateProfile({ quickButtons: newBtns });
                    }}
                    className="text-rose-500 p-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input 
                type="number"
                placeholder="নতুন বাটন (উদা: ৫০০)"
                className="flex-1 p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                value={newQuickButton}
                onChange={(e) => setNewQuickButton(e.target.value)}
              />
              <button 
                onClick={() => {
                  if (!newQuickButton) return;
                  const newBtns = [...quickButtons, parseInt(newQuickButton)].sort((a, b) => a - b);
                  setQuickButtons(newBtns);
                  updateProfile({ quickButtons: newBtns });
                  setNewQuickButton('');
                }}
                className="p-4 bg-emerald-600 text-white rounded-2xl"
              >
                <Plus className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Color Coding / Debt Limits */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
            <h4 className="font-bold text-slate-700 flex items-center gap-2">
              <Palette className="w-5 h-5 text-indigo-500" />
              কালার কোডিং (বাকি সীমা)
            </h4>
            <p className="text-xs text-slate-400">বাকি অনুযায়ী কাস্টমারের নামের কালার পরিবর্তন হবে</p>

            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-emerald-600 uppercase">সবুজ সীমা (নিরাপদ)</label>
                  <span className="text-xs font-bold text-slate-400">পর্যন্ত</span>
                </div>
                <input 
                  type="number"
                  value={debtLimits.green}
                  onChange={(e) => setDebtLimits({ ...debtLimits, green: parseInt(e.target.value) })}
                  className="w-full p-4 bg-emerald-50 border border-emerald-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold text-emerald-700"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-amber-600 uppercase">কমলা সীমা (সতর্কতা)</label>
                  <span className="text-xs font-bold text-slate-400">পর্যন্ত</span>
                </div>
                <input 
                  type="number"
                  value={debtLimits.orange}
                  onChange={(e) => setDebtLimits({ ...debtLimits, orange: parseInt(e.target.value) })}
                  className="w-full p-4 bg-amber-50 border border-amber-100 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all font-bold text-amber-700"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-rose-600 uppercase">লাল সীমা (ঝুঁকিপূর্ণ)</label>
                  <span className="text-xs font-bold text-slate-400">এর উপরে</span>
                </div>
                <input 
                  type="number"
                  value={debtLimits.red}
                  onChange={(e) => setDebtLimits({ ...debtLimits, red: parseInt(e.target.value) })}
                  className="w-full p-4 bg-rose-50 border border-rose-100 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition-all font-bold text-rose-700"
                />
              </div>

              <button 
                onClick={() => updateProfile({ debtLimits })}
                className="w-full py-4 bg-slate-800 text-white rounded-2xl font-bold active:scale-95 transition-all"
              >সেভ করুন</button>
            </div>
          </div>

          {/* Cash Categories */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
            <h4 className="font-bold text-slate-700 flex items-center gap-2">
              <Tag className="w-5 h-5 text-emerald-600" />
              ক্যাশ ক্যাটাগরি
            </h4>
            
            <div className="flex flex-wrap gap-2">
              {cashCategories.map((cat, idx) => (
                <div key={idx} className="flex items-center gap-1 bg-slate-100 px-3 py-2 rounded-xl border border-slate-200">
                  <span className="font-bold text-slate-700">{cat}</span>
                  <button 
                    onClick={() => {
                      const newCats = cashCategories.filter((_, i) => i !== idx);
                      setCashCategories(newCats);
                      updateProfile({ cashCategories: newCats });
                    }}
                    className="text-rose-500 p-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input 
                type="text"
                placeholder="নতুন ক্যাটাগরি"
                className="flex-1 p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              />
              <button 
                onClick={() => {
                  if (!newCategory) return;
                  const newCats = [...cashCategories, newCategory];
                  setCashCategories(newCats);
                  updateProfile({ cashCategories: newCats });
                  setNewCategory('');
                }}
                className="p-4 bg-emerald-600 text-white rounded-2xl"
              >
                <Plus className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'data' && (
        <div className="space-y-6">
          {/* Backup & Data */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
            <h4 className="font-bold text-slate-700 mb-2">ব্যাকআপ ও ডাটা</h4>
            
            <button 
              onClick={exportData}
              disabled={loading}
              className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all disabled:opacity-50"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-indigo-600 shadow-sm">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
                </div>
                <p className="font-bold text-slate-800">ডাটা এক্সপোর্ট (JSON)</p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300" />
            </button>

            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={importData} 
              accept=".json" 
              className="hidden" 
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              disabled={loading}
              className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all disabled:opacity-50"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-amber-600 shadow-sm">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
                </div>
                <p className="font-bold text-slate-800">ডাটা ইমপোর্ট</p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300" />
            </button>
          </div>

          {/* Danger Zone */}
          <div className="bg-rose-50 rounded-3xl p-6 border border-rose-100 space-y-4">
            <h4 className="font-bold text-rose-600 mb-2">ডেঞ্জার জোন</h4>
            <button 
              onClick={() => setShowDeleteModal(true)}
              className="w-full flex items-center justify-between p-4 bg-white rounded-2xl hover:bg-rose-100 transition-all text-rose-600"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-600 shadow-sm">
                  <Trash2 className="w-5 h-5" />
                </div>
                <p className="font-bold">অ্যাকাউন্ট মুছে ফেলুন</p>
              </div>
              <ChevronRight className="w-5 h-5 text-rose-300" />
            </button>
          </div>
        </div>
      )}

      {/* PIN Modal */}
      <AnimatePresence>
        {showPinModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
              onClick={() => setShowPinModal(false)} 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-8 shadow-2xl text-center"
            >
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-600">
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">নতুন পিন সেট করুন</h3>
              <p className="text-sm text-slate-400 mb-6">আপনার ৪ ডিজিটের পিনটি দিন</p>
              
              <input
                type="password"
                maxLength={4}
                placeholder="••••"
                autoFocus
                className="w-full text-4xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl outline-none transition-all text-center tracking-[1rem]"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
              />

              <button
                onClick={handleSetPin}
                disabled={loading}
                className="w-full mt-6 py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                  <>
                    <Check className="w-6 h-6" />
                    পিন সেভ করুন
                  </>
                )}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Account Modal */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
              onClick={() => setShowDeleteModal(false)} 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-8 shadow-2xl text-center"
            >
              <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4 text-rose-600">
                <AlertTriangle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">অ্যাকাউন্ট মুছতে চান?</h3>
              <p className="text-sm text-slate-400 mb-6 leading-relaxed">
                আপনি কি নিশ্চিতভাবে আপনার অ্যাকাউন্ট এবং সকল ডাটা মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।
              </p>
              
              <div className="flex flex-col gap-3">
                <button
                  onClick={handleDeleteAccount}
                  disabled={loading}
                  className="w-full py-4 bg-rose-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-rose-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'হ্যাঁ, মুছে ফেলুন'}
                </button>
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="w-full py-4 bg-slate-100 rounded-2xl text-slate-600 font-bold text-lg transition-all active:scale-95"
                >
                  না, ফিরে যান
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
