import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  Tag,
  Edit2
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  getDocs
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { CashEntry } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';

export const CashFlow: React.FC = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<CashEntry[]>([]);
  const [showAddModal, setShowAddModal] = useState<'income' | 'expense' | null>(null);
  const [editingEntry, setEditingEntry] = useState<CashEntry | null>(null);
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [note, setNote] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'entry' | 'all', id?: string } | null>(null);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'cashEntries'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));
    return () => unsubscribe();
  }, [user]);

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !category || !user) return;

    setLoading(true);
    try {
      if (editingEntry) {
        await updateDoc(doc(db, 'cashEntries', editingEntry.id), {
          amount: Number(amount),
          category,
          note,
        });
        toast.success('আপডেট করা হয়েছে');
      } else {
        await addDoc(collection(db, 'cashEntries'), {
          amount: Number(amount),
          type: showAddModal,
          category,
          note,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });
        toast.success('এন্ট্রি যোগ করা হয়েছে');
      }
      setShowAddModal(null);
      setEditingEntry(null);
      setAmount('');
      setCategory('');
      setNote('');
    } catch (error) {
      handleFirestoreError(error, editingEntry ? OperationType.UPDATE : OperationType.CREATE, editingEntry ? `cashEntries/${editingEntry.id}` : 'cashEntries');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAll = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAll = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const q = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
      const snapshot = await getDocs(q);
      const batch = writeBatch(db);
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
      setConfirmDelete(null);
    }
  };

  const handleEdit = (entry: CashEntry) => {
    setEditingEntry(entry);
    setAmount(entry.amount.toString());
    setCategory(entry.category);
    setNote(entry.note || '');
    setShowAddModal(entry.type);
  };

  const handleDelete = (id: string) => {
    setConfirmDelete({ type: 'entry', id });
  };

  const executeDeleteEntry = async () => {
    if (!confirmDelete || !confirmDelete.id) return;
    try {
      await deleteDoc(doc(db, 'cashEntries', confirmDelete.id));
      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    } finally {
      setConfirmDelete(null);
    }
  };

  const totalIncome = entries.filter(e => e.type === 'income').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = entries.filter(e => e.type === 'expense').reduce((acc, curr) => acc + curr.amount, 0);
  const netCash = totalIncome - totalExpense;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800 px-1">ক্যাশ হিসাব</h2>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">মোট ক্যাশ ব্যালেন্স</p>
            <h3 className={cn("text-3xl font-black", netCash >= 0 ? "text-emerald-600" : "text-rose-600")}>
              {formatCurrency(netCash)}
            </h3>
          </div>
          <div className={cn(
            "w-14 h-14 rounded-2xl flex items-center justify-center",
            netCash >= 0 ? "bg-emerald-50 text-emerald-500" : "bg-rose-50 text-rose-500"
          )}>
            {netCash >= 0 ? <TrendingUp className="w-8 h-8" /> : <TrendingDown className="w-8 h-8" />}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-emerald-50 p-4 rounded-3xl border border-emerald-100">
            <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider mb-1">মোট আয়</p>
            <p className="text-xl font-bold text-emerald-700">{formatCurrency(totalIncome)}</p>
          </div>
          <div className="bg-rose-50 p-4 rounded-3xl border border-rose-100">
            <p className="text-[10px] text-rose-600 font-bold uppercase tracking-wider mb-1">মোট খরচ</p>
            <p className="text-xl font-bold text-rose-700">{formatCurrency(totalExpense)}</p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-4">
        <button 
          onClick={() => setShowAddModal('income')}
          className="flex items-center justify-center gap-2 py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all"
        >
          <Plus className="w-5 h-5" />
          আয় যোগ করুন
        </button>
        <button 
          onClick={() => setShowAddModal('expense')}
          className="flex items-center justify-center gap-2 py-4 bg-rose-500 text-white rounded-2xl font-bold shadow-lg shadow-rose-100 active:scale-95 transition-all"
        >
          <Minus className="w-5 h-5" />
          খরচ যোগ করুন
        </button>
      </div>

      {/* History */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
          {entries.length > 0 && (
            <button 
              onClick={handleDeleteAll}
              className="text-rose-500 text-xs font-bold flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              সব মুছুন
            </button>
          )}
        </div>
        {entries.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">এখনো কোন এন্ট্রি নেই</p>
          </div>
        ) : (
          entries.map((entry) => (
            <div key={entry.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center",
                  entry.type === 'income' ? "bg-emerald-50 text-emerald-500" : "bg-rose-50 text-rose-500"
                )}>
                  {entry.type === 'income' ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-bold text-slate-800">{formatCurrency(entry.amount)}</h5>
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] rounded-full font-bold uppercase tracking-wider">
                      {entry.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold">
                    <Calendar className="w-3 h-3" />
                    {formatDate(entry.date)}
                    {entry.note && <span className="flex items-center gap-1 ml-2"><FileText className="w-3 h-3" /> {entry.note}</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1 transition-all">
                <button 
                  onClick={() => handleEdit(entry)}
                  className="p-2 text-slate-400 hover:text-emerald-500"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDelete(entry.id)}
                  className="p-2 text-slate-400 hover:text-rose-500"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Modal */}
      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'entry'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteEntry}
        title="এন্ট্রি মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই এন্ট্রিটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAll}
        title="সব ইতিহাস মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল ইতিহাস মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।"
      />

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingEntry ? 'এন্ট্রি এডিট করুন' : (showAddModal === 'income' ? 'আয় যোগ করুন' : 'খরচ যোগ করুন')}
                </h3>
                <button onClick={() => {
                  setShowAddModal(null);
                  setEditingEntry(null);
                  setAmount('');
                  setCategory('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddEntry} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">টাকার পরিমাণ</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">ক্যাটাগরি</label>
                  <select
                    required
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all appearance-none"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    <option value="">নির্বাচন করুন</option>
                    {user?.cashCategories?.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">নোট (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    placeholder="বিস্তারিত লিখুন"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-4 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95",
                    showAddModal === 'income' ? "bg-emerald-600 shadow-emerald-100" : "bg-rose-500 shadow-rose-100"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
