import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { PinLock } from './components/PinLock';
import { MainLayout } from './components/MainLayout';
import { Dashboard } from './pages/Dashboard';
import { CashFlow } from './pages/CashFlow';
import { SavingsPage } from './pages/Savings';
import { LoansPage } from './pages/Loans';
import { NotesPage } from './pages/Notes';
import { SettingsPage } from './pages/Settings';
import { CustomerProfile } from './pages/CustomerProfile';
import { ReportsPage } from './pages/Reports';
import { AdminPage } from './pages/Admin';
import { Toaster } from 'react-hot-toast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MaintenanceScreen } from './components/MaintenanceScreen';

const AppContent = () => {
  const { user, isAdmin, loading, systemSettings } = useAuth();
  const [pinVerified, setPinVerified] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.pinEnabled || systemSettings?.features?.pinLock === false) {
      setPinVerified(true);
    } else {
      setPinVerified(false);
    }
  }, [user, systemSettings]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  // Maintenance Mode Check
  if (systemSettings?.maintenanceMode && !isAdmin) {
    return (
      <MaintenanceScreen 
        appName={systemSettings.appName} 
        contactEmail={systemSettings.contactEmail}
        contactPhone={systemSettings.contactPhone}
      />
    );
  }

  if (user.pinEnabled && !pinVerified) {
    return <PinLock correctPin={user.pin || ''} onSuccess={() => setPinVerified(true)} />;
  }

  const renderPage = () => {
    if (selectedCustomerId) {
      return <CustomerProfile customerId={selectedCustomerId} onBack={() => setSelectedCustomerId(null)} />;
    }

    switch (currentPage) {
      case 'dashboard': return <Dashboard onSelectCustomer={setSelectedCustomerId} />;
      case 'cash': return <CashFlow />;
      case 'savings': return <SavingsPage />;
      case 'loans': return <LoansPage />;
      case 'notes': return <NotesPage />;
      case 'settings': return <SettingsPage />;
      case 'reports': return <ReportsPage />;
      case 'admin': return <AdminPage />;
      default: return <Dashboard onSelectCustomer={setSelectedCustomerId} />;
    }
  };

  return (
    <MainLayout currentPage={currentPage} onPageChange={setCurrentPage}>
      {renderPage()}
    </MainLayout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AppContent />
        <Toaster position="top-center" />
      </AuthProvider>
    </ErrorBoundary>
  );
}
