import React, { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  sendPasswordResetEmail,
  User
} from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from './lib/firestore-errors';
import { auth, db } from './firebase';
import { UserProfile } from './types';

export interface ContactInfo {
  label: string;
  value: string;
}

export interface SystemSettings {
  announcement?: string;
  latestVersion?: string;
  updateLink?: string;
  updateMessage?: string;
  forceUpdate?: boolean;
  maintenanceMode?: boolean;
  appName?: string;
  appLogo?: string;
  contactPhone?: string;
  contactEmail?: string;
  supportLink?: string;
  contacts?: ContactInfo[];
  privacyPolicy?: string;
  features: {
    savings: boolean;
    loans: boolean;
    notes: boolean;
    calculator: boolean;
    reports: boolean;
    feedback: boolean;
  };
}

interface AuthContextType {
  user: UserProfile | null;
  firebaseUser: User | null;
  isAdmin: boolean;
  loading: boolean;
  systemSettings: SystemSettings | null;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

export const AuthContext = React.createContext<AuthContextType>({
  user: null,
  firebaseUser: null,
  isAdmin: false,
  loading: true,
  systemSettings: null,
  logout: async () => {},
  refreshUser: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [systemSettings, setSystemSettings] = useState<SystemSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubProfile: (() => void) | undefined;

    // Fetch System Settings
    const unsubSettings = onSnapshot(doc(db, 'system', 'settings'), (doc) => {
      if (doc.exists()) {
        setSystemSettings(doc.data() as SystemSettings);
      }
    });

    const unsubscribe = onAuthStateChanged(auth, async (fUser) => {
      setFirebaseUser(fUser);
      if (fUser) {
        unsubProfile = onSnapshot(doc(db, 'users', fUser.uid), (doc) => {
          if (doc.exists()) {
            setUser({ uid: fUser.uid, ...doc.data() } as UserProfile);
          } else {
            setUser(null);
          }
          setLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${fUser.uid}`);
          setLoading(false);
        });
      } else {
        setUser(null);
        if (unsubProfile) unsubProfile();
        setLoading(false);
      }
    });

    return () => {
      unsubscribe();
      unsubSettings();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const logout = async () => {
    await signOut(auth);
  };

  const refreshUser = async () => {
    if (auth.currentUser) {
      try {
        const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
        if (userDoc.exists()) {
          setUser({ uid: auth.currentUser.uid, ...userDoc.data() } as UserProfile);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser.uid}`);
      }
    }
  };

  const isAdmin = firebaseUser?.email === 'mehedih0127@gmail.com';

  return (
    <AuthContext.Provider value={{ user, firebaseUser, isAdmin, loading, systemSettings, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => React.useContext(AuthContext);
