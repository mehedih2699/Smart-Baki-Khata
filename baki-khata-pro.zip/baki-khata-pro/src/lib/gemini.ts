import { GoogleGenAI } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

export const getGeminiAI = () => {
  if (aiInstance) return aiInstance;

  const apiKey = process.env.GEMINI_API_KEY;
  
  // If no API key or it's a dummy key, don't initialize to avoid crash
  if (!apiKey || apiKey === 'dummy_key' || apiKey === 'YOUR_GEMINI_API_KEY') {
    console.warn("Gemini API Key is missing or invalid. AI features will be disabled.");
    return null;
  }

  try {
    aiInstance = new GoogleGenAI({ apiKey });
    return aiInstance;
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
    return null;
  }
};
