import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './AuthContext';
import { ProductTour } from './components/ProductTour';
import { AuthScreen } from './components/AuthScreen';
import { PinLock } from './components/PinLock';
import { MainLayout } from './components/MainLayout';
import { Dashboard } from './pages/Dashboard';
import { CashFlow } from './pages/CashFlow';
import { SavingsPage } from './pages/Savings';
import { LoansPage } from './pages/Loans';
import { SettingsPage } from './pages/Settings';
import { CustomerProfile } from './pages/CustomerProfile';
import { AdminPage } from './pages/Admin';
import { NotesPage } from './pages/Notes';
import { ReportsPage } from './pages/Reports';
import { Toaster } from 'react-hot-toast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MaintenanceScreen } from './components/MaintenanceScreen';
import { BlockedScreen } from './components/BlockedScreen';
import { ConnectionStatus } from './components/ConnectionStatus';
import { UpdateModal } from './components/UpdateModal';
import { App as CapApp } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { motion, AnimatePresence } from 'motion/react';
import { APP_VERSION } from './constants';

const isVersionLower = (current: string, latest: string) => {
  const currentParts = current.split('.').map(Number);
  const latestParts = latest.split('.').map(Number);
  
  for (let i = 0; i < Math.max(currentParts.length, latestParts.length); i++) {
    const currentPart = currentParts[i] || 0;
    const latestPart = latestParts[i] || 0;
    if (currentPart < latestPart) return true;
    if (currentPart > latestPart) return false;
  }
  return false;
};

const AppContent = () => {
  const { user, isAdmin, loading, systemSettings } = useAuth();
  const [pinVerified, setPinVerified] = useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const prevPinEnabled = React.useRef(user?.pinEnabled);

  useEffect(() => {
    if (systemSettings?.latestVersion && isVersionLower(APP_VERSION, systemSettings.latestVersion)) {
      setShowUpdateModal(true);
    }
  }, [systemSettings?.latestVersion]);

  useEffect(() => {
    if (!loading) {
      // Small delay to let user state stabilize (handle cache vs server transition)
      const timer = setTimeout(() => {
        setIsReady(true);
        SplashScreen.hide();
      }, 200);
      return () => clearTimeout(timer);
    } else {
      setIsReady(false);
    }
  }, [loading]);

  useEffect(() => {
    const handleBackButton = async () => {
      if (isCalculatorOpen) {
        window.dispatchEvent(new CustomEvent('close-calculator'));
        return;
      }
      
      if (selectedCustomerId) {
        setSelectedCustomerId(null);
      } else if (currentPage !== 'dashboard') {
        setCurrentPage('dashboard');
      } else {
        await CapApp.exitApp();
      }
    };

    const handleCalcState = (e: any) => {
      setIsCalculatorOpen(e.detail.isOpen);
    };

    const handleAppStateChange = (state: any) => {
      // Lock app when it comes back from background if PIN is enabled
      const isPinRequired = user?.pinEnabled && systemSettings?.features?.pinLock !== false;
      if (state.isActive && isPinRequired) {
        setPinVerified(false);
      }
    };

    window.addEventListener('calculator-state-changed', handleCalcState);
    const backButtonListener = CapApp.addListener('backButton', handleBackButton);
    const appStateListener = CapApp.addListener('appStateChange', handleAppStateChange);

    return () => {
      window.removeEventListener('calculator-state-changed', handleCalcState);
      backButtonListener.then(l => l.remove());
      appStateListener.then(l => l.remove());
    };
  }, [selectedCustomerId, currentPage, isCalculatorOpen, user, systemSettings]);

  useEffect(() => {
    const handlePopState = () => {
      if (isCalculatorOpen) {
        window.dispatchEvent(new CustomEvent('close-calculator'));
      }
    };

    window.addEventListener('popstate', handlePopState);
    
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [isCalculatorOpen]);

  useEffect(() => {
    if (!user) return;
    
    const isPinRequired = user.pinEnabled && systemSettings?.features?.pinLock !== false;
    
    // If PIN was just enabled, reset verification to lock immediately
    if (user.pinEnabled && !prevPinEnabled.current && isPinRequired) {
      setPinVerified(false);
    }
    
    if (!isPinRequired) {
      setPinVerified(true);
    }
    
    prevPinEnabled.current = user.pinEnabled;
  }, [user?.uid, user?.pinEnabled, systemSettings?.features?.pinLock]);

  if (loading || !isReady) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#f8fafc]">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500 text-sm font-medium">স্মার্ট বাকি খাতা লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  // Blocked User Check
  if (user.blocked && !isAdmin) {
    return (
      <BlockedScreen 
        contactEmail={systemSettings?.contactEmail}
        contactPhone={systemSettings?.contactPhone}
      />
    );
  }

  // Maintenance Mode Check
  if (systemSettings?.maintenanceMode && !isAdmin) {
    return (
      <MaintenanceScreen 
        appName={systemSettings.appName} 
        contactEmail={systemSettings.contactEmail}
        contactPhone={systemSettings.contactPhone}
      />
    );
  }

  if (user.pinEnabled && !pinVerified) {
    return <PinLock correctPin={user.pin || ''} onSuccess={() => setPinVerified(true)} />;
  }

  const renderPage = () => {
    if (selectedCustomerId) {
      return <CustomerProfile customerId={selectedCustomerId} onBack={() => setSelectedCustomerId(null)} />;
    }

    switch (currentPage) {
      case 'dashboard': return <Dashboard onSelectCustomer={setSelectedCustomerId} />;
      case 'cash': return <CashFlow />;
      case 'savings': return <SavingsPage />;
      case 'loans': return <LoansPage />;
      case 'settings': return <SettingsPage />;
      case 'admin': return <AdminPage />;
      case 'notes': return <NotesPage />;
      case 'reports': return <ReportsPage />;
      default: return <Dashboard onSelectCustomer={setSelectedCustomerId} />;
    }
  };

  const handlePageChange = (page: string) => {
    setCurrentPage(page);
    setSelectedCustomerId(null);
  };

  return (
    <MainLayout currentPage={currentPage} onPageChange={handlePageChange}>
      <ProductTour />
      <AnimatePresence>
        {showUpdateModal && systemSettings && (
          <UpdateModal 
            settings={{
              ...systemSettings,
              // Admin bypasses force update
              forceUpdate: isAdmin ? false : systemSettings.forceUpdate 
            }} 
            onClose={() => setShowUpdateModal(false)} 
          />
        )}
      </AnimatePresence>
      {renderPage()}
    </MainLayout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <ConnectionStatus />
        <AppContent />
        <Toaster position="top-center" />
      </AuthProvider>
    </ErrorBoundary>
  );
}
