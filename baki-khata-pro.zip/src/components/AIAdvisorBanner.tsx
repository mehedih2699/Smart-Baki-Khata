import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Loader2, X, TrendingUp, TrendingDown, Target, Wallet, ChevronRight, ChevronUp } from 'lucide-react';
import { getBusinessAdvice, BusinessData } from '../services/aiAdvisor';
import { cn } from '../lib/utils';

interface AIAdvisorBannerProps {
  data: BusinessData;
}

export const AIAdvisorBanner: React.FC<AIAdvisorBannerProps> = ({ data }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [type, setType] = useState<'morning' | 'evening' | 'general'>('general');

  useEffect(() => {
    const checkAndFetchAdvice = async () => {
      const now = new Date();
      const hour = now.getHours();
      const today = now.toISOString().split('T')[0];
      
      let currentType: 'morning' | 'evening' | 'general' = 'general';
      if (hour >= 5 && hour < 12) {
        currentType = 'morning';
      } else if (hour >= 18 && hour < 24) {
        currentType = 'evening';
      } else {
        currentType = 'general';
      }

      setType(currentType);

      const cachedDate = localStorage.getItem(`ai_advice_${currentType}_date`);
      const cachedText = localStorage.getItem(`ai_advice_${currentType}_text`);

      if (cachedDate === today && cachedText) {
        setAdvice(cachedText);
      } else {
        setLoading(true);
        try {
          const newAdvice = await getBusinessAdvice(data, currentType === 'general' ? 'evening' : currentType);
          setAdvice(newAdvice);
          localStorage.setItem(`ai_advice_${currentType}_date`, today);
          localStorage.setItem(`ai_advice_${currentType}_text`, newAdvice);
        } catch (error) {
          console.error("Failed to fetch AI advice:", error);
          setAdvice("পরামর্শ লোড করা সম্ভব হয়নি।");
        } finally {
          setLoading(false);
        }
      }
    };

    checkAndFetchAdvice();
  }, [data]);

  if (!advice) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={cn(
          "relative overflow-hidden bg-white border border-indigo-100 rounded-2xl shadow-lg shadow-indigo-500/5 mb-6 group transition-all duration-300",
          isExpanded ? "p-5" : "p-3 cursor-pointer hover:bg-indigo-50/30"
        )}
        onClick={() => !isExpanded && setIsExpanded(true)}
      >
        {/* Decorative Background */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full -mr-16 -mt-16 blur-3xl opacity-50 group-hover:bg-indigo-100 transition-colors" />
        
        <div className="relative z-10 flex items-center gap-3">
          <div className={cn(
            "rounded-xl flex items-center justify-center shrink-0 shadow-md transition-all",
            isExpanded ? "w-10 h-10" : "w-8 h-8",
            type === 'morning' ? "bg-amber-500 shadow-amber-200" : 
            type === 'evening' ? "bg-indigo-600 shadow-indigo-200" : "bg-emerald-500 shadow-emerald-200"
          )}>
            {loading ? (
              <Loader2 className={cn("text-white animate-spin", isExpanded ? "w-5 h-5" : "w-4 h-4")} />
            ) : (
              <Sparkles className={cn("text-white animate-pulse", isExpanded ? "w-5 h-5" : "w-4 h-4")} />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            {!isExpanded ? (
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-bold text-slate-700 truncate">
                  {type === 'morning' ? 'সকালের পরামর্শ: ' : 
                   type === 'evening' ? 'সন্ধ্যার রিভিউ: ' : 'ব্যবসার পরামর্শ: '}
                  <span className="font-medium text-slate-500 italic">"{advice.slice(0, 40)}..."</span>
                </p>
                <div className="flex items-center gap-1 shrink-0">
                  <button className="px-3 py-1.5 bg-indigo-500 text-white rounded-lg text-[10px] font-black uppercase tracking-widest shadow-sm shadow-indigo-200 active:scale-95 transition-all">
                    দেখুন
                  </button>
                  <ChevronRight className="w-3 h-3 text-indigo-500" />
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <p className={cn(
                      "text-[10px] font-black uppercase tracking-[0.2em]",
                      type === 'morning' ? "text-amber-600" : 
                      type === 'evening' ? "text-indigo-600" : "text-emerald-600"
                    )}>
                      {type === 'morning' ? 'সকালের বিজনেস আপডেট' : 
                       type === 'evening' ? 'সন্ধ্যার বিজনেস রিভিউ' : 'বিজনেস অ্যাডভাইজর'}
                    </p>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsExpanded(false);
                    }}
                    className="flex items-center gap-1 px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    <span className="text-[10px] font-bold text-slate-600">বন্ধ করুন</span>
                    <ChevronUp className="w-3 h-3 text-slate-600" />
                  </button>
                </div>
                
                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-sm font-bold text-slate-700 leading-relaxed italic"
                >
                  "{advice}"
                </motion.p>
                
                <div className="flex items-center gap-4 pt-1">
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span className="text-[10px] font-bold text-slate-400">AI জেনারেটেড</span>
                  </div>
                  {type === 'morning' ? (
                    <div className="flex items-center gap-1.5">
                      <Target className="w-3 h-3 text-amber-500" />
                      <span className="text-[10px] font-bold text-slate-400">আজকের লক্ষ্য</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <Wallet className="w-3 h-3 text-indigo-500" />
                      <span className="text-[10px] font-bold text-slate-400">সঞ্চয় টিপস</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
