import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, AlertTriangle, X } from 'lucide-react';
import { SystemSettings } from '../AuthContext';

interface UpdateModalProps {
  settings: SystemSettings;
  onClose: () => void;
}

export const UpdateModal: React.FC<UpdateModalProps> = ({ settings, onClose }) => {
  const handleUpdate = () => {
    if (settings.updateLink) {
      window.open(settings.updateLink, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={settings.forceUpdate ? undefined : onClose}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
      />
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -mr-16 -mt-16 blur-2xl" />
        
        <div className="relative z-10">
          <div className="w-16 h-16 bg-emerald-100 rounded-3xl flex items-center justify-center text-emerald-600 mb-6">
            <Download className="w-8 h-8" />
          </div>

          <h3 className="text-2xl font-black text-slate-800 tracking-tight mb-2">নতুন আপডেট উপলব্ধ!</h3>
          <p className="text-slate-500 font-medium mb-6">ভার্সন {settings.latestVersion} এখন পাওয়া যাচ্ছে। আরও ভালো পারফরম্যান্স এবং নতুন ফিচারের জন্য এখনই আপডেট করুন।</p>

          {settings.updateMessage && (
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 mb-8">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                <AlertTriangle className="w-3 h-3" />
                কি নতুন আছে?
              </p>
              <p className="text-sm text-slate-600 font-medium leading-relaxed">{settings.updateMessage}</p>
            </div>
          )}

          <div className="flex flex-col gap-3">
            <button
              onClick={handleUpdate}
              className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-emerald-100 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-6 h-6" />
              এখনই আপডেট করুন
            </button>
            
            {!settings.forceUpdate && (
              <button
                onClick={onClose}
                className="w-full py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold active:scale-95 transition-all"
              >
                পরে করবো
              </button>
            )}
          </div>
        </div>

        {settings.forceUpdate && (
          <div className="mt-6 p-4 bg-rose-50 rounded-2xl border border-rose-100">
            <p className="text-[10px] text-rose-600 font-bold uppercase tracking-widest text-center">
              এই আপডেটটি বাধ্যতামূলক। অ্যাপটি ব্যবহার করতে আপনাকে আপডেট করতে হবে।
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
};
