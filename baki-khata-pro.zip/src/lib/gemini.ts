import { GoogleGenAI } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

export const getGeminiAI = () => {
  if (aiInstance) return aiInstance;

  const apiKey = process.env.GEMINI_API_KEY;
  
  if (!apiKey || apiKey === 'dummy_key' || apiKey === 'YOUR_GEMINI_API_KEY') {
    console.warn("Gemini API Key is missing. If you are building an APK, make sure to set GEMINI_API_KEY in your environment variables during the build process.");
    return null;
  }

  try {
    aiInstance = new GoogleGenAI({ apiKey });
    return aiInstance;
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
    return null;
  }
};
