import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Filter, 
  RefreshCw,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { collection, query, where, onSnapshot, getDocs } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Customer, CashEntry, Transaction } from '../types';
import { formatCurrency, cn } from '../lib/utils';
import { getGeminiAI } from '../lib/gemini';
import { 
  Chart as ChartJS, 
  ArcElement, 
  Tooltip, 
  Legend, 
  CategoryScale, 
  LinearScale, 
  BarElement,
  Title
} from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);



export const ReportsPage: React.FC = () => {
  const { user } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [cashEntries, setCashEntries] = useState<CashEntry[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [savings, setSavings] = useState<any[]>([]);
  const [loanTransactions, setLoanTransactions] = useState<any[]>([]);
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setDate(new Date().getDate() - 7)).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  const [aiInsights, setAiInsights] = useState('আপনার ব্যবসার তথ্য বিশ্লেষণ করা হচ্ছে...');
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    if (!user) return;

    const qCustomers = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubCustomers = onSnapshot(qCustomers, (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'customers'));

    const qCash = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
    const unsubCash = onSnapshot(qCash, (snapshot) => {
      setCashEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));

    const qTrans = query(collection(db, 'transactions'), where('ownerUid', '==', user.uid));
    const unsubTrans = onSnapshot(qTrans, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'transactions'));

    const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
    const unsubSavings = onSnapshot(qSavings, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));

    const qLoans = query(collection(db, 'loanTransactions'), where('ownerUid', '==', user.uid));
    const unsubLoans = onSnapshot(qLoans, (snapshot) => {
      setLoanTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'loanTransactions'));

    return () => {
      unsubCustomers();
      unsubCash();
      unsubTrans();
      unsubSavings();
      unsubLoans();
    };
  }, [user]);

  const filteredCash = cashEntries.filter(e => e.date >= dateRange.start && e.date <= dateRange.end + 'T23:59:59');
  const filteredTrans = transactions.filter(t => t.date >= dateRange.start && t.date <= dateRange.end + 'T23:59:59');
  const filteredSavings = savings.filter(s => s.date >= dateRange.start && s.date <= dateRange.end + 'T23:59:59');
  const filteredLoanTrans = loanTransactions.filter(l => l.date >= dateRange.start && l.date <= dateRange.end + 'T23:59:59');

  const totalBaki = filteredTrans.filter(t => t.type === 'baki').reduce((acc, curr) => acc + curr.amount, 0);
  const totalJoma = filteredTrans.filter(t => t.type === 'joma').reduce((acc, curr) => acc + curr.amount, 0);
  const totalIncome = filteredCash.filter(e => e.type === 'income').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = filteredCash.filter(e => e.type === 'expense').reduce((acc, curr) => acc + curr.amount, 0);
  const totalSavings = filteredSavings.reduce((acc, curr) => acc + curr.amount, 0);

  const doughnutData = {
    labels: ['বাকি', 'জমা', 'আয়', 'খরচ'],
    datasets: [{
      data: [totalBaki, totalJoma, totalIncome, totalExpense],
      backgroundColor: ['#f43f5e', '#10b981', '#6366f1', '#f59e0b'],
      borderWidth: 0,
    }]
  };

  const riskyCustomers = customers.filter(c => c.totalBalance > (user?.debtLimits?.red || 10000));

  const generateSmartInsights = () => {
    const insights = [];
    
    if (totalBaki > totalJoma * 1.5) {
      insights.push('আপনার বাকি আদায়ের পরিমাণ জমার চেয়ে অনেক বেশি। বকেয়া টাকা তোলার দিকে নজর দিন।');
    }
    
    if (totalExpense > totalIncome) {
      insights.push('আপনার খরচ আয়ের চেয়ে বেশি হচ্ছে। অপ্রয়োজনীয় খরচ কমানোর চেষ্টা করুন।');
    }
    
    if (riskyCustomers.length > 0) {
      insights.push(`${riskyCustomers.length} জন কাস্টমারের বাকি লিমিট অতিক্রম করেছে। তাদের সাথে দ্রুত যোগাযোগ করুন।`);
    }
    
    if (totalSavings < (totalIncome * 0.1)) {
      insights.push('আপনার সঞ্চয়ের পরিমাণ আয়ের তুলনায় কম। প্রতি মাসে অন্তত ১০% সঞ্চয় করার চেষ্টা করুন।');
    }

    if (totalJoma > totalBaki) {
      insights.push('আপনার ব্যবসায় জমার পরিমাণ বাকির চেয়ে ভালো। এটি একটি ইতিবাচক দিক।');
    }

    if (insights.length === 0) {
      insights.push('আপনার ব্যবসার অবস্থা স্থিতিশীল। নিয়মিত হিসাব রাখুন এবং কাস্টমারদের সাথে সুসম্পর্ক বজায় রাখুন।');
    }

    setAiInsights(insights.join('\n\n'));
    setLoadingAi(false);
  };

  useEffect(() => {
    if (customers.length > 0 || cashEntries.length > 0) {
      setLoadingAi(true);
      // Small delay to simulate "thinking" and avoid layout shift
      const timer = setTimeout(() => {
        generateSmartInsights();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [customers.length, cashEntries.length, totalBaki, totalJoma, totalIncome, totalExpense]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 px-1">
        <h2 className="text-2xl font-bold text-slate-800">রিপোর্ট ও এনালাইসিস</h2>
        <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex-1 flex items-center gap-2 px-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input 
              type="date" 
              className="text-xs font-bold text-slate-600 outline-none bg-transparent"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
            />
          </div>
          <div className="w-px h-4 bg-slate-200" />
          <div className="flex-1 flex items-center gap-2 px-2">
            <input 
              type="date" 
              className="text-xs font-bold text-slate-600 outline-none bg-transparent"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
            />
          </div>
        </div>
      </div>

      {/* Summary Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">মোট বাকি</p>
          <p className="text-xl font-black text-rose-600">{formatCurrency(totalBaki)}</p>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">মোট জমা</p>
          <p className="text-xl font-black text-emerald-600">{formatCurrency(totalJoma)}</p>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">মোট আয়</p>
          <p className="text-xl font-black text-indigo-600">{formatCurrency(totalIncome)}</p>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">মোট ব্যয়</p>
          <p className="text-xl font-black text-amber-600">{formatCurrency(totalExpense)}</p>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm col-span-2">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">মোট সঞ্চয়</p>
          <p className="text-xl font-black text-emerald-600">{formatCurrency(totalSavings)}</p>
        </div>
      </div>

      {/* Charts */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <h4 className="font-bold text-slate-700 mb-6 text-center">ব্যবসায়িক চিত্র</h4>
        <div className="max-w-[250px] mx-auto">
          <Doughnut 
            data={doughnutData} 
            options={{ 
              plugins: { legend: { display: false } },
              cutout: '70%'
            }} 
          />
        </div>
        <div className="grid grid-cols-2 gap-4 mt-8">
          {doughnutData.labels.map((label, i) => (
            <div key={label} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: doughnutData.datasets[0].backgroundColor[i] }} />
              <span className="text-xs text-slate-500 font-medium">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Smart Insights */}
      <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-[2.5rem] p-8 text-white shadow-xl shadow-indigo-100">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-md">
              <TrendingUp className={cn("w-6 h-6", loadingAi && "animate-spin")} />
            </div>
            <h4 className="font-bold text-lg">স্মার্ট ইনসাইটস</h4>
          </div>
          <button 
            onClick={generateSmartInsights}
            disabled={loadingAi}
            className="text-xs font-bold bg-white/20 px-3 py-1.5 rounded-full hover:bg-white/30 transition-all"
          >
            রিফ্রেশ
          </button>
        </div>
        <div className="space-y-4">
          <p className="text-sm text-indigo-100 leading-relaxed whitespace-pre-wrap">
            {aiInsights || 'আপনার ব্যবসার তথ্য বিশ্লেষণ করা হচ্ছে...'}
          </p>
        </div>
      </div>

      {/* Risky Customers */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">ঝুঁকিপূর্ণ কাস্টমার ({riskyCustomers.length})</h4>
          <AlertTriangle className="w-5 h-5 text-amber-500" />
        </div>
        {riskyCustomers.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-dashed border-slate-200">
            <p className="text-slate-400 text-sm">সব কাস্টমার নিরাপদ সীমার মধ্যে আছেন</p>
          </div>
        ) : (
          riskyCustomers.map(c => (
            <div key={c.id} className="bg-white p-4 rounded-2xl border border-rose-100 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center font-bold">
                  {c.name[0]}
                </div>
                <div>
                  <h5 className="font-bold text-slate-800 text-sm">{c.name}</h5>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">{c.phone}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-rose-600">{formatCurrency(c.totalBalance)}</p>
                <p className="text-[10px] text-rose-400 font-bold uppercase">বাকি</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
