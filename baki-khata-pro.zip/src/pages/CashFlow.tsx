import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  Tag,
  Edit2,
  Calculator,
  ShoppingBag,
  ShoppingCart,
  Home,
  Zap,
  Users,
  User,
  Truck,
  Wallet,
  CreditCard,
  Smartphone,
  Search,
  Filter,
  BarChart3,
  PieChart as PieChartIcon,
  ArrowRightLeft,
  ChevronDown,
  Download,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  getDocs
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { CashEntry, Savings } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';

const CATEGORIES = {
  income: [
    { name: 'বিক্রয়', icon: ShoppingBag, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { name: 'বেতন', icon: Wallet, color: 'text-blue-500', bg: 'bg-blue-50' },
    { name: 'বিনিয়োগ', icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-50' },
    { name: 'অন্যান্য', icon: Plus, color: 'text-slate-500', bg: 'bg-slate-50' },
  ],
  expense: [
    { name: 'মালামাল ক্রয়', icon: ShoppingCart, color: 'text-rose-500', bg: 'bg-rose-50' },
    { name: 'দোকান ভাড়া', icon: Home, color: 'text-orange-500', bg: 'bg-orange-50' },
    { name: 'বিদ্যুৎ বিল', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { name: 'বেতন প্রদান', icon: Users, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { name: 'পরিবহন', icon: Truck, color: 'text-cyan-500', bg: 'bg-cyan-50' },
    { name: 'অন্যান্য', icon: Minus, color: 'text-slate-500', bg: 'bg-slate-50' },
  ]
};

const PAYMENT_METHODS = [
  { name: 'Cash', icon: Wallet, label: 'ক্যাশ' },
  { name: 'Bank', icon: CreditCard, label: 'ব্যাংক' },
  { name: 'Mobile Banking', icon: Smartphone, label: 'মোবাইল ব্যাংকিং' },
  { name: 'Personal', icon: User, label: 'পার্সোনাল/অন্যান্য' },
];

export const CashFlow: React.FC = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<CashEntry[]>([]);
  const [savings, setSavings] = useState<Savings[]>([]);
  const [showAddModal, setShowAddModal] = useState<'income' | 'expense' | 'transfer' | 'savings' | null>(null);
  const [editingEntry, setEditingEntry] = useState<CashEntry | null>(null);
  const [loading, setLoading] = useState(false);
  const userCategories = {
    income: user?.incomeCategories || CATEGORIES.income.map(c => c.name),
    expense: user?.expenseCategories || CATEGORIES.expense.map(c => c.name)
  };

  const getCategoryIcon = (name: string, type: 'income' | 'expense') => {
    if (name === 'ট্রান্সফার') return { name, icon: ArrowRightLeft, color: 'text-blue-500', bg: 'bg-blue-50' };
    if (name === 'সঞ্চয়') return { name, icon: PiggyBank, color: 'text-pink-500', bg: 'bg-pink-50' };
    const category = CATEGORIES[type].find(c => c.name === name);
    if (category) return category;
    return { name, icon: type === 'income' ? Plus : Minus, color: 'text-slate-500', bg: 'bg-slate-50' };
  };
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Banking' | 'Personal'>('Cash');
  const [toPaymentMethod, setToPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Banking' | 'Personal'>('Bank');
  const [note, setNote] = useState('');
  const [showCalculator, setShowCalculator] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'entry' | 'all', id?: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'history' | 'stats'>('history');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');

  useEffect(() => {
    if (showAddModal && !editingEntry) {
      if (showAddModal === 'income') {
        setCategory(userCategories.income[0] || '');
      } else if (showAddModal === 'expense') {
        setCategory(userCategories.expense[0] || '');
      }
    }
  }, [showAddModal, editingEntry, userCategories.income, userCategories.expense]);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    const handleCloseCalc = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleCloseCalc);
    return () => window.removeEventListener('close-calculator', handleCloseCalc);
  }, []);

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const handleCalculatorSave = (total: number) => {
    setAmount(total.toString());
    closeCalculator();
  };

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'cashEntries'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'savings'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Savings)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));
    return () => unsubscribe();
  }, [user]);

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || (!category && showAddModal !== 'transfer' && showAddModal !== 'savings') || !user) return;

    setLoading(true);
    try {
      // Optimistic UI: Close modal and reset state immediately
      const currentModal = showAddModal;
      const currentAmount = amount;
      const currentCategory = category;
      const currentPaymentMethod = paymentMethod;
      const currentToPaymentMethod = toPaymentMethod;
      const currentNote = note;
      const currentEditingEntry = editingEntry;

      setShowAddModal(null);
      setEditingEntry(null);
      setAmount('');
      setCategory('');
      setPaymentMethod('Cash');
      setNote('');
      setLoading(false);

      if (currentModal === 'transfer') {
        // Internal Transfer: Add an expense to source and income to destination
        const batch = writeBatch(db);
        const date = new Date().toISOString();
        
        const sourceRef = doc(collection(db, 'cashEntries'));
        batch.set(sourceRef, {
          amount: Number(currentAmount),
          type: 'expense',
          category: 'ট্রান্সফার',
          paymentMethod: currentPaymentMethod,
          note: `ট্রান্সফার: ${PAYMENT_METHODS.find(p => p.name === currentToPaymentMethod)?.label} এ (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        const destRef = doc(collection(db, 'cashEntries'));
        batch.set(destRef, {
          amount: Number(currentAmount),
          type: 'income',
          category: 'ট্রান্সফার',
          paymentMethod: currentToPaymentMethod,
          note: `ট্রান্সফার: ${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} থেকে (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        toast.success('ট্রান্সফার সফল হয়েছে');
        await batch.commit();
      } else if (currentModal === 'savings') {
        // Savings: Add to savings collection AND add an expense to cashEntries
        const batch = writeBatch(db);
        const date = new Date().toISOString();

        const savingRef = doc(collection(db, 'savings'));
        batch.set(savingRef, {
          amount: Number(currentAmount),
          note: `সঞ্চয় (${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} থেকে): ${currentNote}`,
          date,
          ownerUid: user.uid
        });

        const cashRef = doc(collection(db, 'cashEntries'));
        batch.set(cashRef, {
          amount: Number(currentAmount),
          type: 'expense',
          category: 'সঞ্চয়',
          paymentMethod: currentPaymentMethod,
          note: `সঞ্চয় করা হয়েছে (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        toast.success('সঞ্চয় সফল হয়েছে');
        await batch.commit();
      } else if (currentEditingEntry) {
        toast.success('আপডেট করা হয়েছে');
        await updateDoc(doc(db, 'cashEntries', currentEditingEntry.id), {
          amount: Number(currentAmount),
          category: currentCategory,
          paymentMethod: currentPaymentMethod,
          note: currentNote,
        });
      } else {
        toast.success('এন্ট্রি যোগ করা হয়েছে');
        await addDoc(collection(db, 'cashEntries'), {
          amount: Number(currentAmount),
          type: currentModal,
          category: currentCategory,
          paymentMethod: currentPaymentMethod,
          note: currentNote,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });
      }
    } catch (error) {
      handleFirestoreError(error, editingEntry ? OperationType.UPDATE : OperationType.CREATE, editingEntry ? `cashEntries/${editingEntry.id}` : 'cashEntries');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAll = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAll = async () => {
    if (!user) return;
    
    // Optimistic UI
    setConfirmDelete(null);
    setLoading(false);
    toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে');

    try {
      const batch = writeBatch(db);
      
      // Delete cashEntries
      const qEntries = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
      const snapshotEntries = await getDocs(qEntries);
      snapshotEntries.docs.forEach(doc => batch.delete(doc.ref));

      // Delete savings
      const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
      const snapshotSavings = await getDocs(qSavings);
      snapshotSavings.docs.forEach(doc => batch.delete(doc.ref));

      await batch.commit();
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    }
  };

  const handleEdit = (entry: CashEntry) => {
    setEditingEntry(entry);
    setAmount(entry.amount.toString());
    setCategory(entry.category);
    setPaymentMethod(entry.paymentMethod || 'Cash');
    setNote(entry.note || '');
    setShowAddModal(entry.type);
  };

  const handleDelete = (id: string) => {
    setConfirmDelete({ type: 'entry', id });
  };

  const executeDeleteEntry = async () => {
    if (!confirmDelete || !confirmDelete.id) return;
    const entryId = confirmDelete.id;
    setConfirmDelete(null);
    try {
      await deleteDoc(doc(db, 'cashEntries', entryId));
      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const currentMonth = new Date().toISOString().slice(0, 7);
  const totalIncome = entries.filter(e => e.type === 'income' && e.category !== 'ট্রান্সফার').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = entries.filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়').reduce((acc, curr) => acc + curr.amount, 0);
  const monthlyExpense = entries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়' && e.date.startsWith(currentMonth))
    .reduce((acc, curr) => acc + curr.amount, 0);
  const totalSavings = savings.reduce((acc, curr) => acc + curr.amount, 0);

  const getWalletBalance = (method: 'Cash' | 'Bank' | 'Mobile Banking' | 'Personal') => {
    const income = entries.filter(e => e.type === 'income' && e.paymentMethod === method).reduce((acc, curr) => acc + curr.amount, 0);
    const expense = entries.filter(e => e.type === 'expense' && e.paymentMethod === method).reduce((acc, curr) => acc + curr.amount, 0);
    return income - expense;
  };

  const walletBalances = {
    Cash: getWalletBalance('Cash'),
    Bank: getWalletBalance('Bank'),
    'Mobile Banking': getWalletBalance('Mobile Banking'),
    Personal: getWalletBalance('Personal')
  };

  const totalCashBalance = walletBalances.Cash + walletBalances.Bank + walletBalances['Mobile Banking'] + walletBalances.Personal;

  const filteredEntries = entries.filter(e => {
    const matchesSearch = e.note?.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         e.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || e.type === filterType;
    return matchesSearch && matchesType;
  });

  const chartData = [
    { name: 'আয়', value: totalIncome },
    { name: 'ব্যয়', value: totalExpense }
  ];

  const incomeCategoryData = entries
    .filter(e => e.type === 'income' && e.category !== 'ট্রান্সফার')
    .reduce((acc: any[], curr) => {
      const existing = acc.find(a => a.name === curr.category);
      if (existing) {
        existing.value += curr.amount;
      } else {
        acc.push({ name: curr.category, value: curr.amount });
      }
      return acc;
    }, [])
    .sort((a, b) => b.value - a.value);

  const expenseCategoryData = entries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়')
    .reduce((acc: any[], curr) => {
      const existing = acc.find(a => a.name === curr.category);
      if (existing) {
        existing.value += curr.amount;
      } else {
        acc.push({ name: curr.category, value: curr.amount });
      }
      return acc;
    }, [])
    .sort((a, b) => b.value - a.value);

  const COLORS = ['#10b981', '#f43f5e', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#14b8a6'];

  const budgetProgress = user?.monthlyBudget ? (monthlyExpense / user.monthlyBudget) * 100 : 0;

  const handleExport = () => {
    const data = entries.map(e => ({
      তারিখ: formatDate(e.date),
      ধরণ: e.type === 'income' ? 'আয়' : 'ব্যয়',
      পরিমাণ: e.amount,
      ক্যাটাগরি: e.category,
      পেমেন্ট: e.paymentMethod,
      নোট: e.note || ''
    }));
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + Object.keys(data[0]).join(",") + "\n"
      + data.map(row => Object.values(row).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `cash_flow_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('রিপোর্ট ডাউনলোড হয়েছে');
  };

  const getPaymentIcon = (method: string) => {
    const pm = PAYMENT_METHODS.find(p => p.name === method);
    return pm ? pm.icon : Wallet;
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-bold text-slate-800">ক্যাশ হিসাব</h2>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4">
        {user?.monthlyBudget ? (
          <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">মাসিক বাজেট প্রগ্রেস</p>
              <p className="text-xs font-bold text-slate-800">{formatCurrency(monthlyExpense)} / {formatCurrency(user.monthlyBudget)}</p>
            </div>
            <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${Math.min((monthlyExpense / user.monthlyBudget) * 100, 100)}%` }}
                className={cn(
                  "h-full rounded-full transition-all",
                  (monthlyExpense / user.monthlyBudget) * 100 > 90 ? "bg-rose-500" : (monthlyExpense / user.monthlyBudget) * 100 > 70 ? "bg-amber-500" : "bg-emerald-500"
                )}
              />
            </div>
            <p className="text-[10px] text-slate-400 font-bold text-center">
              {(monthlyExpense / user.monthlyBudget) * 100 > 100 ? 'আপনি বাজেট ছাড়িয়ে গেছেন!' : `${(100 - (monthlyExpense / user.monthlyBudget) * 100).toFixed(1)}% বাজেট বাকি আছে`}
            </p>
          </div>
        ) : null}

        <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl shadow-slate-200 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -mr-16 -mt-16 blur-2xl" />
          <div className="relative z-10">
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">মোট ক্যাশ ব্যালেন্স</p>
            <h3 className="text-4xl font-black tracking-tight">{formatCurrency(totalCashBalance)}</h3>
            
            <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-white/10">
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">ক্যাশ</p>
                <p className="text-sm font-bold">{formatCurrency(walletBalances.Cash)}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">ব্যাংক</p>
                <p className="text-sm font-bold">{formatCurrency(walletBalances.Bank)}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">মোবাইল</p>
                <p className="text-sm font-bold">{formatCurrency(walletBalances['Mobile Banking'])}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">পার্সোনাল</p>
                <p className="text-sm font-bold">{formatCurrency(walletBalances.Personal)}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">মোট আয়</p>
              <h4 className="text-xl font-black text-emerald-600">{formatCurrency(totalIncome)}</h4>
            </div>
            <div className="w-10 h-10 bg-emerald-50 text-emerald-500 rounded-xl flex items-center justify-center">
              <ArrowUpRight className="w-6 h-6" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">মোট ব্যয়</p>
              <h4 className="text-xl font-black text-rose-500">{formatCurrency(totalExpense)}</h4>
            </div>
            <div className="w-10 h-10 bg-rose-50 text-rose-500 rounded-xl flex items-center justify-center">
              <ArrowDownRight className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-indigo-600 p-6 rounded-[2rem] shadow-lg shadow-indigo-100 text-white flex items-center justify-between">
          <div>
            <p className="text-indigo-100 text-[10px] font-bold uppercase tracking-widest mb-1">মোট সঞ্চয়</p>
            <h4 className="text-2xl font-black">{formatCurrency(totalSavings)}</h4>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <PiggyBank className="w-7 h-7" />
          </div>
        </div>
      </div>

      {activeTab === 'history' ? (
        <>
          {/* Action Buttons */}
          <div className="grid grid-cols-4 gap-2">
            <button 
              onClick={() => setShowAddModal('income')}
              className="flex flex-col items-center justify-center gap-2 py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all"
            >
              <Plus className="w-5 h-5" />
              <span className="text-[10px]">আয়</span>
            </button>
            <button 
              onClick={() => setShowAddModal('expense')}
              className="flex flex-col items-center justify-center gap-2 py-4 bg-rose-500 text-white rounded-2xl font-bold shadow-lg shadow-rose-100 active:scale-95 transition-all"
            >
              <Minus className="w-5 h-5" />
              <span className="text-[10px]">ব্যয়</span>
            </button>
            <button 
              onClick={() => setShowAddModal('transfer')}
              className="flex flex-col items-center justify-center gap-2 py-4 bg-slate-800 text-white rounded-2xl font-bold shadow-lg shadow-slate-100 active:scale-95 transition-all"
            >
              <ArrowRightLeft className="w-5 h-5" />
              <span className="text-[10px]">ট্রান্সফার</span>
            </button>
            <button 
              onClick={() => setShowAddModal('savings')}
              className="flex flex-col items-center justify-center gap-2 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100 active:scale-95 transition-all"
            >
              <PiggyBank className="w-5 h-5" />
              <span className="text-[10px]">সঞ্চয়</span>
            </button>
          </div>

          {/* Search & Filter */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  placeholder="লেনদেন খুঁজুন..."
                  className="w-full pl-11 pr-4 py-3 bg-white border border-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button 
                onClick={handleExport}
                className="p-3 bg-white border border-slate-100 rounded-xl text-slate-600 hover:text-emerald-600 transition-all"
                title="রিপোর্ট ডাউনলোড"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
              <button 
                onClick={() => setFilterType('all')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'all' ? "bg-slate-800 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                সব
              </button>
              <button 
                onClick={() => setFilterType('income')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'income' ? "bg-emerald-600 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                আয়
              </button>
              <button 
                onClick={() => setFilterType('expense')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'expense' ? "bg-rose-500 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                ব্যয়
              </button>
            </div>
          </div>

          {/* History List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
              {entries.length > 0 && (
                <button 
                  onClick={handleDeleteAll}
                  className="text-rose-500 text-xs font-bold flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  সব মুছুন
                </button>
              )}
            </div>
            {filteredEntries.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
                <p className="text-slate-400">কোন লেনদেন পাওয়া যায়নি</p>
              </div>
            ) : (
              filteredEntries.map((entry) => {
                const catInfo = getCategoryIcon(entry.category, entry.type);
                const Icon = catInfo.icon;
                const PMIcon = getPaymentIcon(entry.paymentMethod);
                return (
                  <div key={entry.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110",
                        entry.type === 'income' ? "bg-emerald-50 text-emerald-500" : "bg-rose-50 text-rose-500"
                      )}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-bold text-slate-800">{formatCurrency(entry.amount)}</h5>
                          <span className="px-2 py-0.5 bg-slate-50 text-slate-500 text-[9px] rounded-md font-bold uppercase tracking-wider border border-slate-100">
                            {entry.category}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] text-slate-400 font-bold mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {formatDate(entry.date)}
                          </span>
                          <span className="flex items-center gap-1 text-slate-500">
                            <PMIcon className="w-3 h-3" />
                            {PAYMENT_METHODS.find(p => p.name === entry.paymentMethod)?.label || 'ক্যাশ'}
                          </span>
                        </div>
                        {entry.note && (
                          <p className="text-[10px] text-slate-400 mt-1 italic flex items-center gap-1">
                            <FileText className="w-3 h-3" /> {entry.note}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-100 transition-all">
                      <button 
                        onClick={() => handleEdit(entry)}
                        className="p-2 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 rounded-lg transition-all"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(entry.id)}
                        className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      ) : (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {/* Charts Section */}
          <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h4 className="text-sm font-bold text-slate-700 mb-6 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-500" />
              আয় বনাম ব্যয়
            </h4>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600, fill: '#64748b' }} />
                  <YAxis hide />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : '#f43f5e'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 md:gap-6">
            <div className="bg-white p-3 md:p-6 rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-sm">
              <h4 className="text-[10px] md:text-sm font-bold text-slate-700 mb-3 md:mb-6 flex items-center gap-1 md:gap-2">
                <PieChartIcon className="w-3 h-3 md:w-4 md:h-4 text-emerald-500" />
                আয়ের খাত
              </h4>
              {incomeCategoryData.length > 0 ? (
                <div className="flex flex-col items-center">
                  <div className="h-32 md:h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={incomeCategoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={25}
                          outerRadius={40}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {incomeCategoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-1 gap-1 w-full mt-2">
                    {incomeCategoryData.slice(0, 4).map((cat, index) => (
                      <div key={cat.name} className="flex items-center gap-1">
                        <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                        <span className="text-[8px] font-bold text-slate-600 truncate">{cat.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-20 md:h-40 flex items-center justify-center text-slate-400 text-[10px]">
                  তথ্য নেই
                </div>
              )}
            </div>

            <div className="bg-white p-3 md:p-6 rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-sm">
              <h4 className="text-[10px] md:text-sm font-bold text-slate-700 mb-3 md:mb-6 flex items-center gap-1 md:gap-2">
                <PieChartIcon className="w-3 h-3 md:w-4 md:h-4 text-rose-500" />
                ব্যয়ের খাত
              </h4>
              {expenseCategoryData.length > 0 ? (
                <div className="flex flex-col items-center">
                  <div className="h-32 md:h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={expenseCategoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={25}
                          outerRadius={40}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {expenseCategoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-1 gap-1 w-full mt-2">
                    {expenseCategoryData.slice(0, 4).map((cat, index) => (
                      <div key={cat.name} className="flex items-center gap-1">
                        <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                        <span className="text-[8px] font-bold text-slate-600 truncate">{cat.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-20 md:h-40 flex items-center justify-center text-slate-400 text-[10px]">
                  তথ্য নেই
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add Modal */}
      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'entry'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteEntry}
        title="এন্ট্রি মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই এন্ট্রিটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAll}
        title="সব ইতিহাস মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল ইতিহাস মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।"
      />

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-6 sm:p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingEntry ? 'এন্ট্রি এডিট করুন' : (
                    showAddModal === 'income' ? 'আয় যোগ করুন' : 
                    showAddModal === 'expense' ? 'খরচ যোগ করুন' : 
                    showAddModal === 'transfer' ? 'ইন্টারনাল ট্রান্সফার' : 'সঞ্চয় করুন'
                  )}
                </h3>
                <button onClick={() => {
                  setShowAddModal(null);
                  setEditingEntry(null);
                  setAmount('');
                  setCategory('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddEntry} className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-xs font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="text-emerald-600 hover:text-emerald-700 p-1 rounded-lg hover:bg-emerald-50 transition-all"
                    >
                      <Calculator className="w-4 h-4" />
                    </button>
                  </div>
                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                {showAddModal === 'transfer' || showAddModal === 'savings' ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1">কোথা থেকে</label>
                        <select 
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                          value={paymentMethod}
                          onChange={(e) => setPaymentMethod(e.target.value as any)}
                        >
                          {PAYMENT_METHODS.map(pm => (
                            <option key={pm.name} value={pm.name}>{pm.label}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1">কোথায়</label>
                        <select 
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                          disabled={showAddModal === 'savings'}
                          value={showAddModal === 'savings' ? 'Savings' : toPaymentMethod}
                          onChange={(e) => setToPaymentMethod(e.target.value as any)}
                        >
                          {showAddModal === 'savings' ? (
                            <option value="Savings">সঞ্চয় ফান্ড</option>
                          ) : (
                            PAYMENT_METHODS.map(pm => (
                              <option key={pm.name} value={pm.name}>{pm.label}</option>
                            ))
                          )}
                        </select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1">ক্যাটাগরি</label>
                      <div className="grid grid-cols-4 gap-2 max-h-40 overflow-y-auto p-1 no-scrollbar">
                        {(showAddModal === 'income' ? userCategories.income : userCategories.expense).map((catName) => {
                          const predefined = CATEGORIES[showAddModal as 'income' | 'expense']?.find(c => c.name === catName);
                          const CategoryIcon = predefined?.icon || (showAddModal === 'income' ? TrendingUp : TrendingDown);
                          const color = predefined?.color || (showAddModal === 'income' ? 'text-emerald-500' : 'text-rose-500');
                          const bg = predefined?.bg || (showAddModal === 'income' ? 'bg-emerald-50' : 'bg-rose-50');
                          
                          return (
                            <button
                              key={catName}
                              type="button"
                              onClick={() => setCategory(catName)}
                              className={cn(
                                "flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all",
                                category === catName 
                                  ? "border-emerald-500 bg-emerald-50" 
                                  : "border-transparent bg-slate-50 hover:bg-slate-100"
                              )}
                            >
                              <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", bg, color)}>
                                <CategoryIcon className="w-5 h-5" />
                              </div>
                              <span className="text-[8px] font-bold text-slate-600 truncate w-full text-center">{catName}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1">পেমেন্ট মেথড</label>
                      <div className="grid grid-cols-2 gap-2">
                        {PAYMENT_METHODS.map((pm) => (
                          <button
                            key={pm.name}
                            type="button"
                            onClick={() => setPaymentMethod(pm.name as any)}
                            className={cn(
                              "flex items-center gap-2 p-3 rounded-xl border-2 transition-all",
                              paymentMethod === pm.name 
                                ? "border-emerald-500 bg-emerald-50" 
                                : "border-transparent bg-slate-50 hover:bg-slate-100"
                            )}
                          >
                            <pm.icon className={cn("w-4 h-4", paymentMethod === pm.name ? "text-emerald-500" : "text-slate-400")} />
                            <span className="text-[10px] font-bold text-slate-600">{pm.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">নোট (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    placeholder="বিস্তারিত লিখুন"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-4 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95",
                    showAddModal === 'income' ? "bg-emerald-600 shadow-emerald-100" : 
                    showAddModal === 'expense' ? "bg-rose-500 shadow-rose-100" :
                    showAddModal === 'transfer' ? "bg-slate-800 shadow-slate-100" : "bg-indigo-600 shadow-indigo-100"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
