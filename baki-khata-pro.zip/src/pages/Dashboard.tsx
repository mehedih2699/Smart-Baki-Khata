import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Filter, 
  Eye, 
  EyeOff, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw,
  UserPlus,
  Phone,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Plus,
  Minus,
  X,
  Loader2,
  Check,
  Edit2,
  Trash2,
  Bell,
  Calculator,
  MapPin
} from 'lucide-react';
import { collection, query, where, onSnapshot, orderBy, limit, addDoc, serverTimestamp, getDocs, updateDoc, doc, writeBatch } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Customer, Transaction, CashEntry } from '../types';
import { formatCurrency, cn } from '../lib/utils';
import { APP_VERSION } from '../constants';
import { toast } from 'react-hot-toast';
import { getGeminiAI } from '../lib/gemini';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';
import { AIAdvisorBanner } from '../components/AIAdvisorBanner';
import { BusinessData } from '../services/aiAdvisor';


export const Dashboard: React.FC<{ onSelectCustomer: (id: string) => void }> = ({ onSelectCustomer }) => {
  const { user, systemSettings, isAdmin } = useAuth();
  const [showUpdateBanner, setShowUpdateBanner] = useState(true);
  const [showBalance, setShowBalance] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [isStatsExpanded, setIsStatsExpanded] = useState(false);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [monthlyTransactions, setMonthlyTransactions] = useState<Transaction[]>([]);
  const [cashEntries, setCashEntries] = useState<CashEntry[]>([]);
  const [savings, setSavings] = useState<any[]>([]);
  const [loanTransactions, setLoanTransactions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleShowBalance = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setShowBalance(true);
    timerRef.current = setTimeout(() => {
      setShowBalance(false);
    }, 4000);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    const handleCloseCalc = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleCloseCalc);
    return () => window.removeEventListener('close-calculator', handleCloseCalc);
  }, []);

  const isUpdateAvailable = systemSettings?.latestVersion && (() => {
    const latest = systemSettings.latestVersion.split('.').map(Number);
    const current = APP_VERSION.split('.').map(Number);
    for (let i = 0; i < Math.max(latest.length, current.length); i++) {
      const v1 = latest[i] || 0;
      const v2 = current[i] || 0;
      if (v1 > v2) return true;
      if (v1 < v2) return false;
    }
    return false;
  })();
  const isForceUpdate = systemSettings?.forceUpdate && isUpdateAvailable && !isAdmin;

  useEffect(() => {
    if (!user) return;

    const qCustomers = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubscribeCustomers = onSnapshot(qCustomers, (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'customers'));

    const qTransactions = query(collection(db, 'transactions'), where('ownerUid', '==', user.uid), orderBy('date', 'desc'), limit(10));
    const unsubscribeTransactions = onSnapshot(qTransactions, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'transactions'));

    const firstDayOfMonth = new Date();
    firstDayOfMonth.setDate(1);
    firstDayOfMonth.setHours(0, 0, 0, 0);

    const qMonthly = query(
      collection(db, 'transactions'),
      where('ownerUid', '==', user.uid),
      where('date', '>=', firstDayOfMonth.toISOString()),
      orderBy('date', 'desc')
    );
    const unsubscribeMonthly = onSnapshot(qMonthly, (snapshot) => {
      setMonthlyTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'monthly-transactions'));

    const qCash = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
    const unsubscribeCash = onSnapshot(qCash, (snapshot) => {
      setCashEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));

    const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
    const unsubscribeSavings = onSnapshot(qSavings, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));

    const qLoans = query(collection(db, 'loanTransactions'), where('ownerUid', '==', user.uid));
    const unsubscribeLoans = onSnapshot(qLoans, (snapshot) => {
      setLoanTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'loanTransactions'));

    const handleOpenAddCustomer = () => setShowAddCustomer(true);
    window.addEventListener('open-add-customer', handleOpenAddCustomer);

    return () => {
      unsubscribeCustomers();
      unsubscribeTransactions();
      unsubscribeMonthly();
      unsubscribeCash();
      unsubscribeSavings();
      unsubscribeLoans();
      window.removeEventListener('open-add-customer', handleOpenAddCustomer);
    };
  }, [user]);

  const totalBaki = customers.reduce((acc, curr) => acc + (curr.totalBalance > 0 ? curr.totalBalance : 0), 0);
  const totalJoma = customers.reduce((acc, curr) => acc + (curr.totalBalance < 0 ? Math.abs(curr.totalBalance) : 0), 0);
  
  const today = new Date().toISOString().split('T')[0];
  
  const todayTransactions = transactions.filter(t => t.date.startsWith(today));
  const todayBaki = todayTransactions.filter(t => t.type === 'baki').reduce((acc, curr) => acc + curr.amount, 0);
  const todayJoma = todayTransactions.filter(t => t.type === 'joma').reduce((acc, curr) => acc + curr.amount, 0);

  const todayCash = cashEntries.filter(e => e.date.startsWith(today));
  const todayIncome = todayCash.filter(e => e.type === 'income').reduce((acc, curr) => acc + curr.amount, 0);
  const todayExpense = todayCash.filter(e => e.type === 'expense').reduce((acc, curr) => acc + curr.amount, 0);

  const todaySavings = savings.filter(s => s.date.startsWith(today)).reduce((acc, curr) => acc + curr.amount, 0);
  
  const todayLoanTrans = loanTransactions.filter(l => l.date.startsWith(today));
  const todayLoanGiven = todayLoanTrans.filter(l => l.type === 'loan').reduce((acc, curr) => acc + curr.amount, 0);
  const todayLoanPaid = todayLoanTrans.filter(l => l.type === 'payment').reduce((acc, curr) => acc + curr.amount, 0);

  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [newCustomer, setNewCustomer] = useState({ name: '', phone: '', address: '', tag: 'New' as any, profilePic: '' });
  const [addingCustomer, setAddingCustomer] = useState(false);

  const currentMonth = new Date().toISOString().slice(0, 7);
  const monthlyExpense = cashEntries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়' && e.date.startsWith(currentMonth))
    .reduce((acc, curr) => acc + curr.amount, 0);
  const budgetProgress = user?.monthlyBudget ? (monthlyExpense / user.monthlyBudget) * 100 : 0;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast.error('ছবি ১ মেগাবাইটের কম হতে হবে');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewCustomer(prev => ({ ...prev, profilePic: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (editingCustomer) {
      setNewCustomer({
        name: editingCustomer.name,
        phone: editingCustomer.phone,
        address: editingCustomer.address,
        tag: editingCustomer.tag,
        profilePic: editingCustomer.profilePic || ''
      });
    } else {
      setNewCustomer({ name: '', phone: '', address: '', tag: 'New', profilePic: '' });
    }
  }, [editingCustomer]);

  const handleAddCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.name || !user) return;
    
    const isEditing = !!editingCustomer;
    const customerData = {
      ...newCustomer,
      ownerUid: user.uid,
      createdAt: isEditing ? editingCustomer.createdAt : new Date().toISOString()
    };

    // Optimistic UI: Close modal and reset state immediately
    setShowAddCustomer(false);
    setEditingCustomer(null);
    setNewCustomer({ name: '', phone: '', address: '', tag: 'New', profilePic: '' });
    toast.success(isEditing ? 'কাস্টমার আপডেট করা হয়েছে' : 'কাস্টমার যোগ করা হয়েছে');

    try {
      if (isEditing && editingCustomer) {
        await updateDoc(doc(db, 'customers', editingCustomer.id), customerData);
      } else {
        await addDoc(collection(db, 'customers'), {
          ...customerData,
          totalBalance: 0
        });
      }
    } catch (error) {
      console.error('Customer Save Error:', error);
      handleFirestoreError(error, OperationType.WRITE, isEditing ? `customers/${editingCustomer?.id}` : 'customers');
    }
  };

  const handleDeleteCustomer = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setConfirmDelete(id);
  };

  const executeDeleteCustomer = async () => {
    if (!confirmDelete) return;
    const id = confirmDelete;
    
    // Optimistic UI
    setConfirmDelete(null);
    toast.success('কাস্টমার মুছে ফেলা হয়েছে');

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'customers', id));
      
      const q = query(
        collection(db, 'transactions'), 
        where('ownerUid', '==', user.uid),
        where('customerId', '==', id)
      );
      const snapshot = await getDocs(q);
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `customers/${id}`);
    }
  };

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.phone.includes(searchQuery);
    const matchesFilter = activeFilter === 'All' || c.tag === activeFilter;
    return matchesSearch && matchesFilter;
  });

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const businessData: BusinessData = {
    totalBaki,
    totalJoma,
    todayIncome,
    todayExpense,
    todayBaki,
    todayJoma,
    monthlyExpense,
    monthlyBudget: user?.monthlyBudget || 0,
    customerCount: customers.length
  };

  return (
    <div className="space-y-6">
      {/* Global Announcement */}
      <AnimatePresence>
        {systemSettings?.announcement && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-2xl flex items-start gap-3 shadow-sm mb-2 overflow-hidden"
          >
            <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4 text-amber-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold text-amber-900">সিস্টেম নোটিশ</p>
              <p className="text-xs text-amber-700 mt-0.5">{systemSettings.announcement}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Update Banner */}
      <AnimatePresence>
        {isUpdateAvailable && showUpdateBanner && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-emerald-600 text-white p-4 rounded-2xl flex items-center justify-between shadow-lg shadow-emerald-100 mb-2 overflow-hidden"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                <RefreshCw className="w-5 h-5 animate-spin" />
              </div>
              <div>
                <p className="text-sm font-bold">নতুন আপডেট পাওয়া গেছে! (v{systemSettings.latestVersion})</p>
                <p className="text-[10px] text-emerald-100 line-clamp-1">{systemSettings.updateMessage || 'অ্যাপটি আপডেট করে নতুন ফিচারগুলো উপভোগ করুন।'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <a 
                href={systemSettings.updateLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-4 py-2 bg-white text-emerald-600 rounded-xl text-xs font-bold hover:bg-emerald-50 transition-all"
              >
                আপডেট করুন
              </a>
              {!isForceUpdate && (
                <button 
                  onClick={() => setShowUpdateBanner(false)}
                  className="p-2 hover:bg-white/20 rounded-xl transition-all"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Force Update Modal */}
      <AnimatePresence>
        {isForceUpdate && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white w-full max-w-md rounded-[2.5rem] p-8 text-center shadow-2xl"
            >
              <div className="w-20 h-20 bg-emerald-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <RefreshCw className="w-10 h-10 text-emerald-600 animate-spin" />
              </div>
              <h3 className="text-2xl font-black text-slate-800 mb-2">আপডেট প্রয়োজন!</h3>
              <p className="text-slate-500 mb-8 font-medium">
                অ্যাপটির নতুন ভার্সন (v{systemSettings.latestVersion}) রিলিজ হয়েছে। অ্যাপটি ব্যবহার চালিয়ে যেতে অবশ্যই আপডেট করতে হবে।
              </p>
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 mb-8 text-left">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">নতুন কি কি আছে:</p>
                <p className="text-sm text-slate-600 leading-relaxed">{systemSettings.updateMessage || 'পারফরম্যান্স ইমপ্রুভমেন্ট ও বাগ ফিক্স।'}</p>
              </div>
              <a 
                href={systemSettings.updateLink}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95"
              >
                এখনই আপডেট করুন
              </a>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Consolidated Balance Card Section */}
      <motion.div 
        id="tour-balance-card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden bg-gradient-to-br from-[#050510] via-[#1a1a3a] to-[#050510] rounded-[2.5rem] p-6 sm:p-8 text-white shadow-2xl shadow-indigo-500/20 border border-white/10"
      >
        {/* Decorative Background Elements - Galaxy Style */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/20 rounded-full -mr-48 -mt-48 blur-[100px] animate-pulse" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-violet-500/20 rounded-full -ml-40 -mb-40 blur-[100px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.1)_0%,transparent_70%)]" />
        
        <div className="relative z-10 space-y-6">
          {/* Main Balance Header */}
          <div className="flex items-center justify-between gap-4">
            <div className="space-y-1 flex-1">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                <p className="text-white/90 text-[10px] font-bold uppercase tracking-[0.2em]">মোট পাওনা (বাকি)</p>
              </div>
              <div className="flex items-center gap-4">
                <div 
                  onClick={handleShowBalance}
                  className="cursor-pointer group relative"
                >
                  <h3 className="text-3xl sm:text-4xl font-black tracking-tighter transition-all duration-300">
                    {showBalance ? (
                      <motion.span
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                      >
                        {formatCurrency(totalBaki)}
                      </motion.span>
                    ) : (
                      <span className="text-white/80 text-xl font-bold">ট্যাপ করুন</span>
                    )}
                  </h3>
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowCalculator(true);
                    }}
                    className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-all backdrop-blur-2xl border border-white/20 group"
                    title="ক্যালকুলেটর"
                  >
                    <Calculator className="w-5 h-5 text-white transition-colors" />
                  </button>
                  <button 
                    onClick={() => setIsStatsExpanded(!isStatsExpanded)}
                    className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-all backdrop-blur-2xl border border-white/20 group"
                  >
                    {isStatsExpanded ? (
                      <ChevronUp className="w-5 h-5 text-white" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-white" />
                    )}
                  </button>
                </div>
              </div>
            </div>
            <div className="flex w-12 h-12 bg-gradient-to-br from-indigo-500/30 to-purple-500/30 rounded-2xl items-center justify-center backdrop-blur-3xl border border-white/20 shadow-inner">
              <TrendingUp className="w-6 h-6 text-indigo-300" />
            </div>
          </div>

          {/* Stats Grid Inside Card */}
          <AnimatePresence>
            {isStatsExpanded && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: 'easeInOut' }}
                className="overflow-hidden"
              >
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4 pt-2">
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-emerald-400 transition-colors">আজকের বাকি</p>
                    <p className="text-xs sm:text-sm font-black text-emerald-400">+{formatCurrency(todayBaki)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-blue-400 transition-colors">আজকের জমা</p>
                    <p className="text-xs sm:text-sm font-black text-blue-400">-{formatCurrency(todayJoma)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-amber-400 transition-colors">আজকের আয়</p>
                    <p className="text-xs sm:text-sm font-black text-amber-400">{formatCurrency(todayIncome)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-rose-400 transition-colors">আজকের ব্যয়</p>
                    <p className="text-xs sm:text-sm font-black text-rose-400">{formatCurrency(todayExpense)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-teal-400 transition-colors">আজকের সঞ্চয়</p>
                    <p className="text-xs sm:text-sm font-black text-teal-400">{formatCurrency(todaySavings)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-indigo-400 transition-colors">মোট জমা</p>
                    <p className="text-xs sm:text-sm font-black text-indigo-400">{formatCurrency(totalJoma)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-orange-400 transition-colors">আজ বাকি নেওয়া</p>
                    <p className="text-xs sm:text-sm font-black text-orange-400">{formatCurrency(todayLoanGiven)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-3 border border-white/10 backdrop-blur-md hover:bg-white/20 transition-all group">
                    <p className="text-white/80 text-[8px] uppercase font-bold tracking-widest mb-1 group-hover:text-emerald-400 transition-colors">বাকি পরিশোধ</p>
                    <p className="text-xs sm:text-sm font-black text-emerald-400">{formatCurrency(todayLoanPaid)}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {/* Monthly Budget Progress */}
          {user?.monthlyBudget ? (
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-[10px] text-white/60 font-bold uppercase tracking-widest">মাসিক বাজেট প্রগ্রেস</p>
                <p className="text-xs font-bold text-white/90">{formatCurrency(monthlyExpense)} / {formatCurrency(user.monthlyBudget)}</p>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(budgetProgress, 100)}%` }}
                  className={cn(
                    "h-full rounded-full transition-all",
                    budgetProgress > 90 ? "bg-rose-500" : budgetProgress > 70 ? "bg-amber-500" : "bg-emerald-500"
                  )}
                />
              </div>
              <p className="text-[10px] text-white/40 font-bold text-center">
                {budgetProgress > 100 ? 'আপনি বাজেট ছাড়িয়ে গেছেন!' : `${(100 - budgetProgress).toFixed(1)}% বাজেট বাকি আছে`}
              </p>
            </div>
          ) : null}
        </div>
      </motion.div>

      {/* AI Advisor Banner */}
      <div id="tour-ai-advisor">
        <AIAdvisorBanner data={businessData} />
      </div>

      {/* Search & Filter */}
      <div id="tour-search-bar" className="space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="কাস্টমার খুঁজুন (নাম বা ফোন)"
            className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {['All', 'New', 'VIP', 'Regular', 'Risky'].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all",
                activeFilter === filter 
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-100" 
                  : "bg-white text-slate-600 border border-slate-200 hover:border-emerald-200"
              )}
            >
              {filter === 'All' ? 'সব' : filter}
            </button>
          ))}
        </div>
      </div>

      {/* Customer List */}
      <div id="tour-customer-list" className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">কাস্টমার তালিকা ({filteredCustomers.length})</h4>
          <button 
            onClick={() => setShowAddCustomer(true)}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm shadow-md shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95"
          >
            <UserPlus className="w-4 h-4" />
            নতুন কাস্টমার যোগ করুন
          </button>
        </div>

        {filteredCustomers.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">কোন কাস্টমার পাওয়া যায়নি</p>
          </div>
        ) : (
          filteredCustomers.map((customer) => (
            <motion.div
              key={customer.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSelectCustomer(customer.id)}
              className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg relative overflow-hidden",
                  customer.totalBalance > (user?.debtLimits?.red || 1000) ? "bg-rose-50 text-rose-600" : 
                  customer.totalBalance > (user?.debtLimits?.orange || 1500) ? "bg-amber-50 text-amber-600" : 
                  customer.totalBalance > (user?.debtLimits?.green || 500) ? "bg-emerald-50 text-emerald-600" : "bg-slate-50 text-slate-600"
                )}>
                  {customer.profilePic ? (
                    <img 
                      src={customer.profilePic} 
                      alt={customer.name} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <img 
                      src="/icon.png" 
                      alt="App Icon" 
                      className="w-full h-full object-cover opacity-40"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                        const parent = (e.target as HTMLImageElement).parentElement;
                        if (parent) parent.innerText = customer.name[0];
                      }}
                    />
                  )}
                  {customer.tag && systemSettings?.features?.customerTags !== false && (
                    <div className={cn(
                      "absolute -top-1 -right-1 px-1.5 py-0.5 rounded-md text-[8px] font-black uppercase tracking-tighter border-2 border-white",
                      customer.tag === 'VIP' ? "bg-amber-400 text-white" :
                      customer.tag === 'Risky' || customer.totalBalance > (user?.debtLimits?.red || 1000) ? "bg-rose-500 text-white" : 
                      customer.tag === 'New' ? "bg-blue-500 text-white" : "bg-emerald-500 text-white"
                    )}>
                      {customer.totalBalance > (user?.debtLimits?.red || 1000) ? 'Risky' : customer.tag}
                    </div>
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-bold text-slate-800">{customer.name}</h5>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Phone className="w-3 h-3" />
                    {customer.phone}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className={cn(
                    "font-bold",
                    customer.totalBalance > 0 ? "text-rose-600" : "text-emerald-600"
                  )}>
                    {formatCurrency(Math.abs(customer.totalBalance))}
                  </p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">
                    {customer.totalBalance > 0 ? 'বাকি' : 'জমা'}
                  </p>
                </div>
                <div className="flex items-center gap-1 transition-all">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingCustomer(customer);
                      setShowAddCustomer(true);
                    }}
                    className="p-2 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 rounded-xl transition-all"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={(e) => handleDeleteCustomer(e, customer.id)}
                    className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Add Customer Modal */}
      <ConfirmModal
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteCustomer}
        title="কাস্টমার মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই কাস্টমারকে মুছতে চান? তার সকল লেনদেনও মুছে যাবে।"
      />

      <AnimatePresence>
        {showAddCustomer && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddCustomer(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-6 sm:p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingCustomer ? 'কাস্টমার এডিট করুন' : 'নতুন কাস্টমার যোগ করুন'}
                </h3>
                <button onClick={() => {
                  setShowAddCustomer(false);
                  setEditingCustomer(null);
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddCustomer} className="space-y-4">
                <div className="flex flex-col items-center gap-4 mb-4">
                  <div className="relative group">
                    <div className="w-24 h-24 bg-slate-100 rounded-[2rem] flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300 group-hover:border-emerald-500 transition-all">
                      {newCustomer.profilePic ? (
                        <img src={newCustomer.profilePic} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <UserPlus className="w-8 h-8 text-slate-400" />
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">প্রোফাইল ছবি সেট করুন</p>
                </div>

                <input
                  type="text"
                  placeholder="কাস্টমারের নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন নম্বর"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={newCustomer.phone}
                  onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={newCustomer.address}
                  onChange={(e) => setNewCustomer({ ...newCustomer, address: e.target.value })}
                />

                <button
                  type="submit"
                  disabled={addingCustomer}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {addingCustomer ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      {editingCustomer ? 'আপডেট করুন' : 'যোগ করুন'}
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};

