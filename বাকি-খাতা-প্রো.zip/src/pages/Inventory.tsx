import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, 
  Plus, 
  Search, 
  Trash2, 
  Edit2, 
  X, 
  Check, 
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Loader2
} from 'lucide-react';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { toast } from 'react-hot-toast';
import { cn, formatCurrency, parseNumber } from '../lib/utils';
import { ConfirmModal } from '../components/ConfirmModal';
import { InventoryItem } from '../types';

const UNITS = ['পিস', 'কেজি', 'গ্রাম', 'লিটার', 'প্যাকেট', 'বক্স', 'বস্তা'];

import { SelectProductDropdown } from '../components/SelectProductDropdown';

import { SelectProductDropdown } from '../components/SelectProductDropdown';

export const InventoryPage: React.FC = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  
  const [newItem, setNewItem] = useState({ 
    name: '', 
    purchasePrice: '', 
    sellingPrice: '',
    stockQuantity: '',
    packageQuantity: '',
    looseQuantity: '',
    unit: 'পিস',
    lowStockAlert: '5',
    isPackaged: false,
    packageUnit: 'প্যাকেট',
    piecesPerPackage: '10',
    looseUnit: 'পিস',
    looseSellingPrice: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const [showSellModal, setShowSellModal] = useState(false);
  const [sellData, setSellData] = useState({ itemId: '', quantity: '1', discount: '0', saleType: 'loose' });
  const [isSelling, setIsSelling] = useState(false);

  // Suggested names for fast selection
  const DEFAULT_NAME_SUGGESTIONS = ['মিনিকেট চাল', 'নাজিরশাইল চাল', 'সয়াবিন তেল', 'মসুর ডাল', 'চিনি', 'আটা', 'ময়দা', 'লবণ', 'ডিম', 'নেভি সিগারেট', 'বেনসন সিগারেট', 'গোল্ডলিফ', 'মেরিস', 'ডার্বি'];
  const nameSuggestions = user?.inventoryNames && user.inventoryNames.length > 0 ? user.inventoryNames : DEFAULT_NAME_SUGGESTIONS;
  
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showManageSuggestions, setShowManageSuggestions] = useState(false);
  const [newSuggestion, setNewSuggestion] = useState('');
  
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const [showRestockModal, setShowRestockModal] = useState(false);
  const [restockData, setRestockData] = useState<{item: InventoryItem | null, packageQuantity: string, looseQuantity: string}>({ item: null, packageQuantity: '', looseQuantity: '' });
  const [isRestocking, setIsRestocking] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'inventory'), 
      where('ownerUid', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const itemsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as InventoryItem[];
      setItems(itemsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'inventory');
    });

    return () => unsubscribe();
  }, [user]);

  const filteredItems = items.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalInventoryValue = items.reduce((acc, item) => acc + (item.purchasePrice * item.stockQuantity), 0);
  const totalExpectedProfit = items.reduce((acc, item) => acc + ((item.sellingPrice - item.purchasePrice) * item.stockQuantity), 0);
  const lowStockItems = items.filter(item => item.stockQuantity <= item.lowStockAlert);

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newItem.name || !newItem.purchasePrice || !newItem.sellingPrice) {
      toast.error('সব তথ্য সঠিকভাবে পূরণ করুন');
      return;
    }

    let calculatedStock = 0;
    if (newItem.isPackaged) {
      const pQty = parseNumber(newItem.packageQuantity);
      const lQty = parseNumber(newItem.looseQuantity);
      const pp = parseNumber(newItem.piecesPerPackage) || 1;
      calculatedStock = (pQty * pp) + lQty;
      if (calculatedStock < 0) {
        toast.error('স্টকের পরিমাণ দিন');
        return;
      }
    } else {
      if (!newItem.stockQuantity && parseNumber(newItem.stockQuantity) < 0) {
        toast.error('স্টকের পরিমাণ দিন');
        return;
      }
      calculatedStock = parseNumber(newItem.stockQuantity);
    }

    setIsSubmitting(true);
    try {
      const baseItemData = {
        name: newItem.name,
        stockQuantity: calculatedStock,
        lowStockAlert: parseNumber(newItem.lowStockAlert),
        ownerUid: user.uid,
        updatedAt: new Date().toISOString()
      };

      let itemData: Partial<InventoryItem>;

      if (newItem.isPackaged) {
        itemData = {
          ...baseItemData,
          isPackaged: true,
          purchasePrice: parseNumber(newItem.purchasePrice),
          sellingPrice: parseNumber(newItem.sellingPrice),
          packageUnit: newItem.packageUnit,
          piecesPerPackage: parseNumber(newItem.piecesPerPackage) || 1,
          looseUnit: newItem.looseUnit,
          looseSellingPrice: parseNumber(newItem.looseSellingPrice),
          unit: newItem.looseUnit
        };
      } else {
        itemData = {
          ...baseItemData,
          isPackaged: false,
          purchasePrice: parseNumber(newItem.purchasePrice),
          sellingPrice: parseNumber(newItem.sellingPrice),
          unit: newItem.unit
        };
      }

      if (editingItem) {
        await updateDoc(doc(db, 'inventory', editingItem.id), itemData);
        toast.success('পণ্য আপডেট করা হয়েছে');
      } else {
        await addDoc(collection(db, 'inventory'), {
          ...itemData,
          totalSoldQty: 0,
          totalSoldAmount: 0,
          totalProfitEarned: 0
        });
        toast.success('নতুন পণ্য যোগ করা হয়েছে');
      }

      setShowAddModal(false);
      setEditingItem(null);
      setNewItem({ 
        name: '', purchasePrice: '', sellingPrice: '', stockQuantity: '', packageQuantity: '', looseQuantity: '',
        unit: 'পিস', lowStockAlert: '5', isPackaged: false,
        packageUnit: 'প্যাকেট', piecesPerPackage: '10', looseUnit: 'পিস', looseSellingPrice: '' 
      });
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, 'inventory');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteItem = async () => {
    if (!confirmDelete) return;
    
    try {
      await deleteDoc(doc(db, 'inventory', confirmDelete));
      toast.success('পণ্য ডিলেট করা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'inventory');
    } finally {
      setConfirmDelete(null);
    }
  };

  const handleCashSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !sellData.itemId || !sellData.quantity) {
      toast.error('পণ্য ও পরিমাণ দিন');
      return;
    }

    const itemToSell = items.find(i => i.id === sellData.itemId);
    if (!itemToSell) return;

    const sellQty = parseNumber(sellData.quantity);
    if (sellQty <= 0) {
      toast.error('সঠিক পরিমাণ দিন');
      return;
    }

    // Determine actual quantity removed from stock
    let stockToRemove = sellQty;
    let sellingPrice = itemToSell.sellingPrice;
    let unitLabel = itemToSell.unit;
    let unitPurchaseCost = itemToSell.purchasePrice;

    if (itemToSell.isPackaged) {
      if (sellData.saleType === 'package') {
        stockToRemove = sellQty * (itemToSell.piecesPerPackage || 1);
        sellingPrice = itemToSell.sellingPrice;
        unitLabel = itemToSell.packageUnit || '';
        unitPurchaseCost = itemToSell.purchasePrice;
      } else {
        stockToRemove = sellQty;
        sellingPrice = itemToSell.looseSellingPrice || itemToSell.sellingPrice;
        unitLabel = itemToSell.looseUnit || '';
        unitPurchaseCost = itemToSell.purchasePrice / (itemToSell.piecesPerPackage || 1);
      }
    }

    if (stockToRemove > itemToSell.stockQuantity) {
      toast.error('স্টকে যথেষ্ট পণ্য নেই');
      return;
    }

    setIsSelling(true);
    try {
      const discountAmount = parseNumber(sellData.discount);
      const totalSaleAmount = (sellQty * sellingPrice) - discountAmount;
      const totalCostAmount = sellQty * unitPurchaseCost;
      const profitEarned = totalSaleAmount - totalCostAmount;

      // 1. Reduce Stock & Update Lifetime Stats
      await updateDoc(doc(db, 'inventory', itemToSell.id), {
        stockQuantity: itemToSell.stockQuantity - stockToRemove,
        totalSoldQty: (itemToSell.totalSoldQty || 0) + stockToRemove,
        totalSoldAmount: (itemToSell.totalSoldAmount || 0) + totalSaleAmount,
        totalProfitEarned: (itemToSell.totalProfitEarned || 0) + profitEarned,
        updatedAt: new Date().toISOString()
      });

      // 2. Add to Cash Flow
      let noteStr = `নগদ বিক্রি: ${itemToSell.name} (${sellQty} ${unitLabel})`;
      if (discountAmount > 0) {
        noteStr += ` (ছাড়: ${discountAmount} ৳)`;
      }

      await addDoc(collection(db, 'cashEntries'), {
        amount: totalSaleAmount,
        type: 'income',
        category: 'নগদ বিক্রি',
        paymentMethod: 'Cash',
        note: noteStr,
        date: new Date().toISOString(),
        ownerUid: user.uid,
        linkedItemId: itemToSell.id,
        linkedStockRemoved: stockToRemove,
        linkedProfitEarned: profitEarned
      });

      toast.success('নগদ বিক্রি সম্পন্ন হয়েছে');
      setShowSellModal(false);
      setSellData({ itemId: '', quantity: '1', discount: '0', saleType: 'loose' });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'inventory');
    } finally {
      setIsSelling(false);
    }
  };

  const handleRestock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !restockData.item) return;

    const item = restockData.item;
    let addedStock = 0;

    if (item.isPackaged) {
      const pQty = parseNumber(restockData.packageQuantity);
      const lQty = parseNumber(restockData.looseQuantity);
      const pp = parseNumber(item.piecesPerPackage) || 1;
      addedStock = (pQty * pp) + lQty;
    } else {
      addedStock = parseNumber(restockData.looseQuantity);
    }

    if (addedStock <= 0) {
      toast.error('সঠিক পরিমাণ দিন');
      return;
    }

    setIsRestocking(true);
    try {
      await updateDoc(doc(db, 'inventory', item.id), {
        stockQuantity: item.stockQuantity + addedStock,
        updatedAt: new Date().toISOString()
      });
      toast.success('স্টক সফলভাবে আপডেট হয়েছে');
      setShowRestockModal(false);
    } catch(err) {
      handleFirestoreError(err, OperationType.UPDATE, 'inventory');
    } finally {
      setIsRestocking(false);
    }
  };

  const handleAddSuggestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newSuggestion.trim()) return;
    
    // Prevent duplicates
    if (nameSuggestions.includes(newSuggestion.trim())) {
      toast.error('এই নামটি আগেই যোগ করা আছে');
      return;
    }

    try {
      const updatedList = [...nameSuggestions, newSuggestion.trim()];
      await updateDoc(doc(db, 'users', user.uid), {
        inventoryNames: updatedList
      });
      setNewSuggestion('');
      toast.success('নতুন নাম যোগ করা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'users');
    }
  };

  const handleRemoveSuggestion = async (nameToRemove: string) => {
    if (!user) return;
    try {
      const updatedList = nameSuggestions.filter(name => name !== nameToRemove);
      await updateDoc(doc(db, 'users', user.uid), {
        inventoryNames: updatedList
      });
      toast.success('নাম মুছে ফেলা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'users');
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex flex-col justify-center items-center text-center group hover:border-emerald-200 transition-all">
          <Package className="w-5 h-5 text-emerald-500 mb-1" />
          <h3 className="text-sm font-black text-slate-800">{formatCurrency(totalInventoryValue)}</h3>
          <p className="text-slate-400 text-[9px] font-black uppercase tracking-wider mt-0.5">মোট মূল্য</p>
        </div>
        <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex flex-col justify-center items-center text-center group hover:border-blue-200 transition-all">
          <TrendingUp className="w-5 h-5 text-blue-500 mb-1" />
          <h3 className="text-sm font-black text-blue-600">{formatCurrency(totalExpectedProfit)}</h3>
          <p className="text-slate-400 text-[9px] font-black uppercase tracking-wider mt-0.5">সম্ভাব্য লাভ</p>
        </div>
        <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex flex-col justify-center items-center text-center group hover:border-rose-200 transition-all">
          <AlertTriangle className="w-5 h-5 text-rose-500 mb-1" />
          <h3 className="text-sm font-black text-rose-600">{lowStockItems.length} টি</h3>
          <p className="text-slate-400 text-[9px] font-black uppercase tracking-wider mt-0.5">অ্যালার্ট</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">স্টক ইনভেন্টরি</h2>
        </div>
        <div className="grid grid-cols-2 gap-3 w-full sm:w-auto">
          <button
            onClick={() => {
              setSellData({ itemId: '', quantity: '1' });
              setShowSellModal(true);
            }}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95"
          >
            <TrendingUp className="w-4 h-4" />
            নগদ বিক্রি
          </button>
          <button
            onClick={() => {
              setEditingItem(null);
              setNewItem({ name: '', purchasePrice: '', sellingPrice: '', stockQuantity: '', unit: UNITS[0], lowStockAlert: '5' });
              setShowAddModal(true);
            }}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-bold shadow-md shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            নতুন পণ্য
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="পণ্যের নাম দিয়ে খুঁজুন..."
          className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm transition-all"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-[2.5rem] p-12 text-center border border-slate-100 shadow-sm">
          <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <Package className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-1">কোন পণ্য পাওয়া যায়নি</h3>
          <p className="text-slate-500 text-sm">নতুন পণ্য যোগ করতে উপরের বাটনে ক্লিক করুন</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item) => (
            <motion.div
              layout
              key={item.id}
              className={cn(
                "group p-5 rounded-[2rem] border-2 transition-all hover:shadow-lg bg-white relative",
                item.stockQuantity <= item.lowStockAlert ? "border-rose-200" : "border-slate-100 hover:border-emerald-100"
              )}
            >
              {item.stockQuantity <= item.lowStockAlert && (
                <div className="absolute -top-3 -right-3 bg-rose-500 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-md flex items-center gap-1 animate-pulse border-2 border-white">
                  <AlertTriangle className="w-3 h-3" />
                  লো স্টক
                </div>
              )}
              
              <div className="flex items-start justify-between mb-4">
                <h3 className="font-black text-lg text-slate-800 pr-4">
                  {item.name}
                </h3>
                <div className="flex items-center gap-1 bg-slate-50 rounded-xl p-1 shrink-0">
                  <button
                    onClick={() => {
                      setRestockData({ item, packageQuantity: '', looseQuantity: '' });
                      setShowRestockModal(true);
                    }}
                    className="flex items-center gap-1 px-2 py-1.5 text-emerald-600 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-all font-bold text-xs mr-1 border border-emerald-100"
                  >
                    <Plus className="w-3 h-3" /> স্টক
                  </button>
                  <button
                    onClick={() => {
                      setEditingItem(item);
                      const pPack = item.piecesPerPackage || 1;
                      const pQty = item.isPackaged ? Math.floor(item.stockQuantity / pPack) : 0;
                      const lQty = item.isPackaged ? (item.stockQuantity % pPack) : 0;
                      
                      setNewItem({ 
                        name: item.name, 
                        purchasePrice: item.purchasePrice.toString(), 
                        sellingPrice: item.sellingPrice.toString(), 
                        stockQuantity: item.stockQuantity.toString(), 
                        packageQuantity: pQty.toString(),
                        looseQuantity: lQty.toString(),
                        unit: item.unit || 'পিস', 
                        lowStockAlert: item.lowStockAlert.toString(),
                        isPackaged: item.isPackaged || false,
                        packageUnit: item.packageUnit || 'প্যাকেট',
                        piecesPerPackage: item.piecesPerPackage?.toString() || '10',
                        looseUnit: item.looseUnit || 'পিস',
                        looseSellingPrice: item.looseSellingPrice?.toString() || ''
                      });
                      setShowAddModal(true);
                    }}
                    className="p-1.5 text-slate-400 hover:bg-white hover:text-emerald-500 rounded-lg transition-all"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setConfirmDelete(item.id)}
                    className="p-1.5 text-slate-400 hover:bg-white hover:text-rose-500 rounded-lg transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex bg-slate-50 rounded-2xl p-3 mb-4 items-center justify-between">
                <div className="text-center flex-1 border-r border-slate-200">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">স্টকে আছে</p>
                  <p className={cn(
                    "text-xl font-black",
                    item.stockQuantity <= item.lowStockAlert ? "text-rose-600" : "text-slate-800"
                  )}>
                    {item.isPackaged && item.piecesPerPackage ? (
                      <>
                        {Math.floor(item.stockQuantity / item.piecesPerPackage)} <span className="text-xs font-bold text-slate-500 mr-1">{item.packageUnit}</span>
                        {item.stockQuantity % item.piecesPerPackage > 0 && (
                          <>{item.stockQuantity % item.piecesPerPackage} <span className="text-xs font-bold text-slate-500">{item.looseUnit}</span></>
                        )}
                      </>
                    ) : (
                      <>{item.stockQuantity} <span className="text-xs font-bold text-slate-500">{item.unit}</span></>
                    )}
                  </p>
                </div>
                <div className="text-center flex-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">বিক্রি দাম</p>
                  <p className="text-xl font-black text-emerald-600">
                    {formatCurrency(item.sellingPrice)}
                  </p>
                  {item.isPackaged && (
                    <p className="text-[9px] text-slate-500 font-bold border-t border-slate-200 mt-1 pt-1">
                      খুচরা: {formatCurrency(item.looseSellingPrice || 0)} / {item.looseUnit}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="bg-blue-50/50 p-2 rounded-xl text-center border border-blue-100/50">
                  <p className="text-[10px] font-bold text-slate-400 uppercase">মোট বিক্রি</p>
                  <p className="font-black text-blue-700 text-sm">{formatCurrency(item.totalSoldAmount || 0)}</p>
                </div>
                <div className="bg-emerald-50/50 p-2 rounded-xl text-center border border-emerald-100/50">
                  <p className="text-[10px] font-bold text-slate-400 uppercase">মোট লাভ</p>
                  <p className="font-black text-emerald-700 text-sm">{formatCurrency(item.totalProfitEarned || 0)}</p>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 bg-slate-50/50 px-3 py-2 rounded-xl border border-slate-100">
                <span>কেনা দাম: <span className="text-slate-700">{formatCurrency(item.purchasePrice)}</span> {item.isPackaged ? `/${item.packageUnit}` : ''}</span>
                {item.totalSoldQty ? <span>সর্বমোট সেলস: <span className="text-blue-600">{item.totalSoldQty} {item.isPackaged ? item.looseUnit : item.unit}</span></span> : null}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl overflow-y-auto max-h-[90vh] no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingItem ? 'পণ্য আপডেট করুন' : 'নতুন পণ্য যোগ করুন'}
                </h3>
                <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSaveItem} className="space-y-4">
                <div className="space-y-1.5 relative">
                  <label className="text-sm font-bold text-slate-600 ml-1">পণ্যের নাম</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: মিনিকেট চাল"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    value={newItem.name}
                    onChange={(e) => {
                      setNewItem({ ...newItem, name: e.target.value });
                      setShowSuggestions(true);
                    }}
                    onFocus={() => setShowSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                  />
                  {showSuggestions && !editingItem && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-56 flex flex-col">
                      <div className="p-2 flex flex-wrap gap-2 overflow-y-auto">
                        {nameSuggestions.filter(s => s.toLowerCase().includes(newItem.name.toLowerCase())).map(suggestion => (
                          <button
                            key={suggestion}
                            type="button"
                            onClick={() => {
                              setNewItem({ ...newItem, name: suggestion });
                              setShowSuggestions(false);
                            }}
                            className="text-xs px-3 py-1.5 bg-slate-100 hover:bg-emerald-100 hover:text-emerald-700 text-slate-700 font-bold rounded-lg transition-all"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                      <div className="p-2 border-t border-slate-100 bg-slate-50 rounded-b-2xl">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowSuggestions(false);
                            setShowManageSuggestions(true);
                          }}
                          className="w-full py-2 text-xs font-bold text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all flex items-center justify-center gap-1"
                        >
                          <Edit2 className="w-3 h-3" /> সাজেশন এডিট করুন
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 text-sm font-bold text-slate-800 cursor-pointer mb-2 bg-emerald-50 p-3 rounded-xl border border-emerald-100">
                    <input
                      type="checkbox"
                      checked={newItem.isPackaged}
                      onChange={(e) => setNewItem({ ...newItem, isPackaged: e.target.checked })}
                      className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                    />
                    এই পণ্যটির ভেতরে কি খুচরা পিস/অংশ আছে? (যেমন বস্তায় কেজি, প্যাকেটে পিস)
                  </label>
                </div>

                {newItem.isPackaged ? (
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="space-y-1.5 relative">
                        <label className="text-xs font-bold text-slate-600 ml-1">বড় একক (যেমন: বস্তা)</label>
                        <input
                          type="text"
                          required
                          placeholder="বস্তা"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.packageUnit}
                          onChange={(e) => setNewItem({ ...newItem, packageUnit: e.target.value })}
                          onFocus={() => setFocusedField('packageUnit')}
                          onBlur={() => setTimeout(() => setFocusedField(null), 200)}
                        />
                        {focusedField === 'packageUnit' && (
                          <div className="absolute z-10 w-[200px] mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-40 overflow-y-auto">
                            <div className="p-2 flex flex-col">
                              {UNITS.filter(u => u.includes(newItem.packageUnit)).map(u => (
                                <button
                                  key={u}
                                  type="button"
                                  onClick={() => {
                                    setNewItem({ ...newItem, packageUnit: u });
                                    setFocusedField(null);
                                  }}
                                  className="text-left text-xs px-3 py-2 hover:bg-emerald-50 text-slate-700 font-bold rounded-lg transition-all"
                                >
                                  {u}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 ml-1">প্রতিটিতে কত আছে?</label>
                        <input
                          type="number"
                          required
                          min="1"
                          placeholder="50"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.piecesPerPackage}
                          onChange={(e) => setNewItem({ ...newItem, piecesPerPackage: e.target.value })}
                        />
                      </div>
                      <div className="space-y-1.5 relative">
                        <label className="text-xs font-bold text-slate-600 ml-1">ছোট একক (যেমন: কেজি)</label>
                        <input
                          type="text"
                          required
                          placeholder="কেজি"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.looseUnit}
                          onChange={(e) => setNewItem({ ...newItem, looseUnit: e.target.value })}
                          onFocus={() => setFocusedField('looseUnit')}
                          onBlur={() => setTimeout(() => setFocusedField(null), 200)}
                        />
                        {focusedField === 'looseUnit' && (
                          <div className="absolute z-10 w-[200px] right-0 mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-40 overflow-y-auto">
                            <div className="p-2 flex flex-col">
                              {UNITS.filter(u => u.includes(newItem.looseUnit)).map(u => (
                                <button
                                  key={u}
                                  type="button"
                                  onClick={() => {
                                    setNewItem({ ...newItem, looseUnit: u });
                                    setFocusedField(null);
                                  }}
                                  className="text-left text-xs px-3 py-2 hover:bg-emerald-50 text-slate-700 font-bold rounded-lg transition-all"
                                >
                                  {u}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 ml-1">কেনা দাম (প্রতি {newItem.packageUnit || 'বড় একক'})</label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.purchasePrice}
                          onChange={(e) => setNewItem({ ...newItem, purchasePrice: e.target.value })}
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 ml-1">বিক্রি দাম (প্রতি {newItem.packageUnit || 'বড় একক'})</label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.sellingPrice}
                          onChange={(e) => setNewItem({ ...newItem, sellingPrice: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 ml-1 text-blue-600">খুচরা বিক্রি দাম (প্রতি {newItem.looseUnit || 'ছোট একক'})</label>
                      <input
                        type="number"
                        required
                        min="0"
                        step="0.01"
                        placeholder="0.00"
                        className="w-full px-3 py-2 bg-white border border-blue-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                        value={newItem.looseSellingPrice}
                        onChange={(e) => setNewItem({ ...newItem, looseSellingPrice: e.target.value })}
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 ml-1 text-emerald-600">প্রাথমিক স্টক</label>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            placeholder="0"
                            className="w-full pl-3 pr-16 py-2 bg-white border border-emerald-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold"
                            value={newItem.packageQuantity}
                            onChange={(e) => setNewItem({ ...newItem, packageQuantity: e.target.value })}
                          />
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 pointer-events-none">
                            {newItem.packageUnit || 'প্যাকেট'}
                          </div>
                        </div>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            placeholder="0"
                            className="w-full pl-3 pr-16 py-2 bg-white border border-emerald-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold"
                            value={newItem.looseQuantity}
                            onChange={(e) => setNewItem({ ...newItem, looseQuantity: e.target.value })}
                          />
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 pointer-events-none">
                            {newItem.looseUnit || 'পিস'}
                          </div>
                        </div>
                      </div>
                      <p className="text-[10px] text-slate-500 ml-1">যেকোনো একটি বা দুটি ঘরে পরিমাণ বসাতে পারেন (অটোমেটিক হিসাব হয়ে যাবে)।</p>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-sm font-bold text-slate-600 ml-1">কেনা দাম</label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.purchasePrice}
                          onChange={(e) => setNewItem({ ...newItem, purchasePrice: e.target.value })}
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-sm font-bold text-slate-600 ml-1">বিক্রি দাম</label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.sellingPrice}
                          onChange={(e) => setNewItem({ ...newItem, sellingPrice: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-sm font-bold text-slate-600 ml-1">স্টকের পরিমাণ</label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="any"
                          placeholder="0"
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.stockQuantity}
                          onChange={(e) => setNewItem({ ...newItem, stockQuantity: e.target.value })}
                        />
                      </div>
                      <div className="space-y-1.5 relative">
                        <label className="text-sm font-bold text-slate-600 ml-1">একক (Unit)</label>
                        <input
                          type="text"
                          required
                          placeholder="যেমন: পিস"
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                          value={newItem.unit}
                          onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
                          onFocus={() => setFocusedField('unit')}
                          onBlur={() => setTimeout(() => setFocusedField(null), 200)}
                        />
                        {focusedField === 'unit' && (
                          <div className="absolute z-10 w-full right-0 mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-40 overflow-y-auto">
                            <div className="p-2 flex flex-col">
                              {UNITS.filter(u => u.includes(newItem.unit)).map(u => (
                                <button
                                  key={u}
                                  type="button"
                                  onClick={() => {
                                    setNewItem({ ...newItem, unit: u });
                                    setFocusedField(null);
                                  }}
                                  className="text-left text-sm px-3 py-2 hover:bg-emerald-50 text-slate-700 font-bold rounded-lg transition-all"
                                >
                                  {u}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}

                <div className="space-y-1.5">
                  <label className="text-sm font-bold text-slate-600 ml-1">লো স্টক অ্যালার্ট (কত নিচে নামলে সতর্ক করবে?)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="5"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    value={newItem.lowStockAlert}
                    onChange={(e) => setNewItem({ ...newItem, lowStockAlert: e.target.value })}
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 mt-4 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      সেভ করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sale Modal */}
      <AnimatePresence>
        {showSellModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSellModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl overflow-y-auto max-h-[90vh] min-h-[65vh] no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  নগদ বিক্রি
                </h3>
                <button onClick={() => setShowSellModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleCashSale} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-bold text-slate-600 ml-1">পণ্য নির্বাচন করুন</label>
                  <SelectProductDropdown 
                    items={items}
                    selectedId={sellData.itemId}
                    onSelect={(id) => setSellData({ ...sellData, itemId: id })}
                  />
                </div>

                {sellData.itemId && (
                  <>
                    {items.find(i => i.id === sellData.itemId)?.isPackaged && (
                      <div className="space-y-1.5">
                        <label className="text-sm font-bold text-slate-600 ml-1">কিভাবে বিক্রি করবেন?</label>
                        <select
                          className="w-full px-4 py-3 bg-blue-50 border border-blue-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none font-medium appearance-none text-blue-700"
                          value={sellData.saleType}
                          onChange={(e) => setSellData({ ...sellData, saleType: e.target.value })}
                        >
                          <option value="package">বড় একক ({items.find(i => i.id === sellData.itemId)?.packageUnit})</option>
                          <option value="loose">খুচরা ({items.find(i => i.id === sellData.itemId)?.looseUnit})</option>
                        </select>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-sm font-bold text-slate-600 ml-1">পরিমাণ ({items.find(i => i.id === sellData.itemId)?.isPackaged ? (sellData.saleType === 'package' ? items.find(i => i.id === sellData.itemId)?.packageUnit : items.find(i => i.id === sellData.itemId)?.looseUnit) : items.find(i => i.id === sellData.itemId)?.unit})</label>
                        <input
                          type="number"
                          required
                          min="0.01"
                          step="any"
                          placeholder="0"
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none"
                          value={sellData.quantity}
                          onChange={(e) => setSellData({ ...sellData, quantity: e.target.value })}
                        />
                      </div>
                      
                      <div className="space-y-1.5">
                        <label className="text-sm font-bold text-slate-600 ml-1">ছাড় (Discount)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0"
                          className="w-full px-4 py-3 bg-rose-50 border border-rose-200 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none text-rose-700"
                          value={sellData.discount}
                          onChange={(e) => setSellData({ ...sellData, discount: e.target.value })}
                        />
                      </div>
                    </div>
                    
                    <div className="mt-4 p-4 bg-blue-50 rounded-2xl border border-blue-100 flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-blue-800">মোট বিল:</span>
                        <span className="text-sm font-bold text-slate-500 line-through">
                          {(() => {
                            const item = items.find(i => i.id === sellData.itemId);
                            if (!item) return '';
                            let unitPrice = item.sellingPrice;
                            if (item.isPackaged && sellData.saleType === 'loose') {
                              unitPrice = item.looseSellingPrice || item.sellingPrice;
                            }
                            const discount = parseNumber(sellData.discount);
                            return discount > 0 ? formatCurrency(parseNumber(sellData.quantity) * unitPrice) : '';
                          })()}
                        </span>
                      </div>
                      <div className="flex items-center justify-between border-t border-blue-100 mt-2 pt-2">
                        <span className="text-sm font-black text-blue-800">পরিশোধযোগ্য:</span>
                        <span className="text-2xl font-black text-blue-700">
                          {(() => {
                            const item = items.find(i => i.id === sellData.itemId);
                            if (!item) return '0 ৳';
                            let unitPrice = item.sellingPrice;
                            if (item.isPackaged && sellData.saleType === 'loose') {
                              unitPrice = item.looseSellingPrice || item.sellingPrice;
                            }
                            return formatCurrency((parseNumber(sellData.quantity) * unitPrice) - parseNumber(sellData.discount));
                          })()}
                        </span>
                      </div>
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  disabled={isSelling || !sellData.itemId}
                  className="w-full py-4 bg-blue-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-blue-100 mt-4 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                >
                  {isSelling ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নগদ বিক্রি সম্পন্ন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Restock Modal */}
      <AnimatePresence>
        {showRestockModal && restockData.item && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRestockModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl overflow-y-auto max-h-[90vh] no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  স্টক যুক্ত করুন
                </h3>
                <button onClick={() => setShowRestockModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <div className="mb-6 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Package className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800">{restockData.item.name}</p>
                  <p className="text-xs text-slate-500 font-medium">বর্তমান স্টক: {
                    restockData.item.isPackaged && restockData.item.piecesPerPackage ? (
                      `${Math.floor(restockData.item.stockQuantity / restockData.item.piecesPerPackage)} ${restockData.item.packageUnit} ` +
                      (restockData.item.stockQuantity % (restockData.item.piecesPerPackage) > 0 ? `${restockData.item.stockQuantity % restockData.item.piecesPerPackage} ${restockData.item.looseUnit}` : '')
                    ) : (
                      `${restockData.item.stockQuantity} ${restockData.item.unit}`
                    )
                  }</p>
                </div>
              </div>

              <form onSubmit={handleRestock} className="space-y-4">
                {restockData.item.isPackaged ? (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-sm font-bold text-slate-600 ml-1 whitespace-nowrap overflow-hidden text-ellipsis">নতুন {restockData.item.packageUnit}</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder="0"
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                        value={restockData.packageQuantity}
                        onChange={(e) => setRestockData({ ...restockData, packageQuantity: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-sm font-bold text-slate-600 ml-1 whitespace-nowrap overflow-hidden text-ellipsis">নতুন {restockData.item.looseUnit}</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder="0"
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                        value={restockData.looseQuantity}
                        onChange={(e) => setRestockData({ ...restockData, looseQuantity: e.target.value })}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <label className="text-sm font-bold text-slate-600 ml-1">নতুন পরিমাণ ({restockData.item.unit})</label>
                    <input
                      type="number"
                      required
                      min="0.01"
                      step="any"
                      placeholder="0"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      value={restockData.looseQuantity}
                      onChange={(e) => setRestockData({ ...restockData, looseQuantity: e.target.value })}
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isRestocking}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 mt-4 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                >
                  {isRestocking ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      স্টক আপডেট
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Manage Suggestions Modal */}
      <AnimatePresence>
        {showManageSuggestions && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowManageSuggestions(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-8 shadow-2xl overflow-y-auto max-h-[90vh]"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  সাজেশন ম্যানেজ করুন
                </h3>
                <button onClick={() => setShowManageSuggestions(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <div className="space-y-4">
                <form onSubmit={handleAddSuggestion} className="flex gap-2">
                  <input
                    type="text"
                    required
                    placeholder="নতুন নাম..."
                    className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    value={newSuggestion}
                    onChange={(e) => setNewSuggestion(e.target.value)}
                  />
                  <button
                    type="submit"
                    className="px-4 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition-all font-bold"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </form>

                <div className="space-y-2 mt-4 max-h-60 overflow-y-auto pr-2">
                  {nameSuggestions.map(suggestion => (
                    <div key={suggestion} className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-100">
                      <span className="font-bold text-slate-700">{suggestion}</span>
                      <button
                        onClick={() => handleRemoveSuggestion(suggestion)}
                        className="p-1.5 text-slate-400 hover:bg-white hover:text-rose-500 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  {nameSuggestions.length === 0 && (
                    <p className="text-center text-slate-400 text-sm py-4">কোনো সাজেশন সেভ করা নেই</p>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={handleDeleteItem}
        title="পণ্য মুছতে চান?"
        message="আপনি কি নিশ্চিত যে এই পণ্যটি মুছে ফেলতে চান? এটি পুনরায় ফিরিয়ে আনা সম্ভব নয়।"
      />
    </div>
  );
};
