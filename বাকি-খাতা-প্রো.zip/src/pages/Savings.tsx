import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  PiggyBank, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  Edit2,
  Calculator
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  getDocs
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Savings } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';

export const SavingsPage: React.FC = () => {
  const { user } = useAuth();
  const [savings, setSavings] = useState<Savings[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSaving, setEditingSaving] = useState<Savings | null>(null);
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'entry' | 'all', id?: string } | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const handleCalculatorSave = (total: number) => {
    setAmount(total.toString());
    closeCalculator();
  };

  useEffect(() => {
    const handleClose = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleClose);
    return () => window.removeEventListener('close-calculator', handleClose);
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'savings'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Savings)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));
    return () => unsubscribe();
  }, [user]);

  const handleAddSaving = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !user) return;

    const currentAmount = amount;
    const currentNote = note;
    const currentEditingSaving = editingSaving;

    // Optimistic UI: Close modal and reset state immediately
    setShowAddModal(false);
    setEditingSaving(null);
    setAmount('');
    setNote('');
    setLoading(false);

    try {
      if (currentEditingSaving) {
        const batch = writeBatch(db);
        batch.update(doc(db, 'savings', currentEditingSaving.id), {
          amount: Number(currentAmount),
          note: currentNote,
        });

        // Find and update corresponding cashEntry
        const q = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid), where('date', '==', currentEditingSaving.date), where('category', '==', 'সঞ্চয়'));
        const snapshot = await getDocs(q);
        snapshot.docs.forEach(doc => {
          batch.update(doc.ref, {
            amount: Number(currentAmount),
            note: `সঞ্চয় করা হয়েছে (${currentNote})`
          });
        });

        await batch.commit();
        toast.success('আপডেট করা হয়েছে');
      } else {
        const batch = writeBatch(db);
        const date = new Date().toISOString();

        const savingRef = doc(collection(db, 'savings'));
        batch.set(savingRef, {
          amount: Number(currentAmount),
          note: currentNote,
          date,
          ownerUid: user.uid
        });

        const cashRef = doc(collection(db, 'cashEntries'));
        batch.set(cashRef, {
          amount: Number(currentAmount),
          type: 'expense',
          category: 'সঞ্চয়',
          paymentMethod: 'Cash',
          note: `সঞ্চয় করা হয়েছে (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        await batch.commit();
        toast.success('সঞ্চয় যোগ করা হয়েছে');
      }
    } catch (error) {
      handleFirestoreError(error, currentEditingSaving ? OperationType.UPDATE : OperationType.CREATE, currentEditingSaving ? `savings/${currentEditingSaving.id}` : 'savings');
    }
  };

  const handleDeleteAll = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAll = async () => {
    if (!user) return;
    setConfirmDelete(null);
    setLoading(true);
    try {
      const batch = writeBatch(db);
      
      const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
      const snapshotSavings = await getDocs(qSavings);
      snapshotSavings.docs.forEach(doc => batch.delete(doc.ref));

      const qCash = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid), where('category', '==', 'সঞ্চয়'));
      const snapshotCash = await getDocs(qCash);
      snapshotCash.docs.forEach(doc => batch.delete(doc.ref));

      await batch.commit();
      toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (saving: Savings) => {
    setEditingSaving(saving);
    setAmount(saving.amount.toString());
    setNote(saving.note || '');
    setShowAddModal(true);
  };

  const handleDelete = (id: string) => {
    setConfirmDelete({ type: 'entry', id });
  };

  const executeDeleteEntry = async () => {
    if (!confirmDelete || !confirmDelete.id || !user) return;
    const savingId = confirmDelete.id;
    const savingToDelete = savings.find(s => s.id === savingId);
    setConfirmDelete(null);
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'savings', savingId));

      if (savingToDelete) {
        const q = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid), where('date', '==', savingToDelete.date), where('category', '==', 'সঞ্চয়'));
        const snapshot = await getDocs(q);
        snapshot.docs.forEach(doc => batch.delete(doc.ref));
      }

      await batch.commit();
      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goalAmount, setGoalAmount] = useState('');

  useEffect(() => {
    if (user?.savingsGoal) {
      setGoalAmount(user.savingsGoal.toString());
    }
  }, [user?.savingsGoal]);

  const handleSetGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        savingsGoal: Number(goalAmount) || 0
      });
      toast.success('লক্ষ্যমাত্রা সেট করা হয়েছে');
      setShowGoalModal(false);
    } catch (error) {
      toast.error('লক্ষ্যমাত্রা সেট করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const totalSavings = savings.reduce((acc, curr) => acc + curr.amount, 0);
  const savingsGoal = user?.savingsGoal || 0;
  const goalProgress = savingsGoal > 0 ? Math.min(100, Math.round((totalSavings / savingsGoal) * 100)) : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-bold text-slate-800">সঞ্চয় হিসাব</h2>
        <button 
          onClick={() => setShowGoalModal(true)}
          className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-full hover:bg-indigo-100 transition-all"
        >
          {savingsGoal > 0 ? 'লক্ষ্যমাত্রা পরিবর্তন' : 'লক্ষ্যমাত্রা সেট করুন'}
        </button>
      </div>

      {/* Total Savings Card */}
      <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-8 rounded-[2.5rem] text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl" />
        
        <div className="flex items-center justify-between mb-6 relative z-10">
          <div>
            <p className="text-indigo-100 text-xs font-bold uppercase tracking-widest mb-1">মোট সঞ্চয়</p>
            <h3 className="text-4xl font-black">{formatCurrency(totalSavings)}</h3>
          </div>
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <PiggyBank className="w-10 h-10" />
          </div>
        </div>

        {savingsGoal > 0 && (
          <div className="relative z-10 pt-4 border-t border-white/10">
            <div className="flex items-center justify-between text-xs font-bold mb-2">
              <span className="text-indigo-100">লক্ষ্য: {formatCurrency(savingsGoal)}</span>
              <span className="text-white">{goalProgress}%</span>
            </div>
            <div className="h-2 w-full bg-black/20 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-1000" 
                style={{ width: `${goalProgress}%` }} 
              />
            </div>
          </div>
        )}
      </div>

      <button 
        onClick={() => setShowAddModal(true)}
        className="w-full flex items-center justify-center gap-2 py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold shadow-sm hover:border-indigo-500 hover:text-indigo-600 transition-all active:scale-95"
      >
        <Plus className="w-5 h-5" />
        নতুন সঞ্চয় যোগ করুন
      </button>

      {/* History */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">সঞ্চয়ের ইতিহাস</h4>
          {savings.length > 0 && (
            <button 
              onClick={handleDeleteAll}
              className="text-rose-500 text-xs font-bold flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              সব মুছুন
            </button>
          )}
        </div>
        {savings.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">এখনো কোন সঞ্চয় নেই</p>
          </div>
        ) : (
          savings.map((item) => (
            <div key={item.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-indigo-50 text-indigo-500 rounded-xl flex items-center justify-center">
                  <PiggyBank className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">{formatCurrency(item.amount)}</h5>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold">
                    <Calendar className="w-3 h-3" />
                    {formatDate(item.date)}
                    {item.note && <span className="flex items-center gap-1 ml-2"><FileText className="w-3 h-3" /> {item.note}</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1 transition-all">
                <button 
                  onClick={() => handleEdit(item)}
                  className="p-2 text-slate-400 hover:text-indigo-500"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDelete(item.id)}
                  className="p-2 text-slate-400 hover:text-rose-500"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Modal */}
      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'entry'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteEntry}
        title="সঞ্চয় মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই সঞ্চয়টি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAll}
        title="সব ইতিহাস মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল ইতিহাস মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।"
      />

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingSaving ? 'সঞ্চয় এডিট করুন' : 'সঞ্চয় যোগ করুন'}
                </h3>
                <button onClick={() => {
                  setShowAddModal(false);
                  setEditingSaving(null);
                  setAmount('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddSaving} className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-xs font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="text-emerald-600 hover:text-emerald-700 p-1 rounded-lg hover:bg-emerald-50 transition-all"
                    >
                      <Calculator className="w-4 h-4" />
                    </button>
                  </div>
                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">নোট (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    placeholder="বিস্তারিত লিখুন"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-indigo-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showGoalModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowGoalModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">সঞ্চয়ের লক্ষ্যমাত্রা</h3>
                <button onClick={() => setShowGoalModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSetGoal} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">লক্ষ্যমাত্রার পরিমাণ</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={goalAmount}
                    onChange={(e) => setGoalAmount(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-indigo-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      সেট করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
