import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Shield, 
  Activity, 
  Database, 
  AlertTriangle,
  CheckCircle2,
  Search,
  Filter,
  MessageSquare,
  Settings,
  LayoutDashboard,
  Trash2,
  Lock,
  Unlock,
  Bell,
  Save,
  Loader2,
  Mail,
  Calendar,
  Store,
  Plus
} from 'lucide-react';
import { 
  collection, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  doc, 
  updateDoc, 
  deleteDoc,
  getDoc,
  setDoc,
  Timestamp,
  where,
  getCountFromServer
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { UserProfile, Feedback } from '../types';
import { useAuth } from '../AuthContext';
import { formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

type AdminTab = 'overview' | 'users' | 'feedback' | 'settings';

export const AdminPage: React.FC = () => {
  const { isAdmin, isOnline } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [feedback, setFeedback] = useState<Feedback[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCustomers: 0,
    totalTransactions: 0,
    totalFeedback: 0,
    activeToday: 0,
    totalStorage: '4.5 MB'
  });

  const [announcement, setAnnouncement] = useState('');
  const [latestVersion, setLatestVersion] = useState('');
  const [updateLink, setUpdateLink] = useState('');
  const [updateMessage, setUpdateMessage] = useState('');
  const [forceUpdate, setForceUpdate] = useState(false);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [appName, setAppName] = useState('বাকি খাতা প্রো');
  const [appLogo, setAppLogo] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [supportLink, setSupportLink] = useState('');
  const [contacts, setContacts] = useState<{label: string, value: string}[]>([]);
  const [privacyPolicy, setPrivacyPolicy] = useState('');
  
  const [features, setFeatures] = useState({
    savings: true,
    loans: true,
    notes: true,
    calculator: true,
    reports: true,
    feedback: true,
    aiQuotes: true,
    customerTags: true,
    pinLock: true,
    notifications: true
  });
  const [savingSettings, setSavingSettings] = useState(false);

  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    type: 'danger' | 'warning' | 'info';
  }>({
    show: false,
    title: '',
    message: '',
    onConfirm: () => {},
    type: 'info'
  });

  const fetchData = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    else setLoading(true);
    
    console.log('Admin: Fetching data...');
    try {
      // Fetch Users
      const usersQ = query(collection(db, 'users'), limit(100));
      const usersSnapshot = await getDocs(usersQ);
      const usersData = usersSnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
      
      // Sort in memory to handle missing createdAt
      usersData.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
      
      setUsers(usersData);

      // Fetch Feedback
      const feedbackQ = query(collection(db, 'feedback'), orderBy('date', 'desc'), limit(50));
      const feedbackSnapshot = await getDocs(feedbackQ);
      const feedbackData = feedbackSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Feedback));
      setFeedback(feedbackData);

      // Fetch System Settings (Announcement, Features, Updates)
      const settingsDoc = await getDoc(doc(db, 'system', 'settings'));
      if (settingsDoc.exists()) {
        const data = settingsDoc.data();
        setAnnouncement(data.announcement || '');
        setLatestVersion(data.latestVersion || '');
        setUpdateLink(data.updateLink || '');
        setUpdateMessage(data.updateMessage || '');
        setForceUpdate(data.forceUpdate || false);
        setMaintenanceMode(data.maintenanceMode || false);
        setAppName(data.appName || 'বাকি খাতা প্রো');
        setAppLogo(data.appLogo || '');
        setContactPhone(data.contactPhone || '');
        setContactEmail(data.contactEmail || '');
        setSupportLink(data.supportLink || '');
        setContacts(data.contacts || []);
        setPrivacyPolicy(data.privacyPolicy || '');
        
        if (data.features) {
          setFeatures(prev => ({ ...prev, ...data.features }));
        }
      }

      // Detailed Stats
      const customersCount = await getCountFromServer(collection(db, 'customers'));
      const transactionsCount = await getCountFromServer(collection(db, 'transactions'));

      setStats({
        totalUsers: usersData.length,
        totalCustomers: customersCount.data().count,
        totalTransactions: transactionsCount.data().count,
        totalFeedback: feedbackData.length,
        activeToday: Math.floor(usersData.length * 0.4), // Mock active today
        totalStorage: `${(transactionsCount.data().count * 0.1 + customersCount.data().count * 0.05).toFixed(1)} MB`
      });

      if (isManual) toast.success('ডেটা আপডেট করা হয়েছে');
    } catch (error: any) {
      console.error('Admin Fetch Error:', error);
      let errorMessage = 'ডেটা লোড করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।';
      
      if (error.code === 'permission-denied') {
        errorMessage = 'সার্ভার পারমিশন ইরোর। আপনার এই কাজটি করার অনুমতি নেই।';
      } else if (error.message?.includes('index')) {
        errorMessage = 'ডেটাবেস ইনডেক্স প্রয়োজন। অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করুন।';
      } else {
        errorMessage = `Error: ${error.message || 'Unknown error'}`;
      }
      toast.error(errorMessage);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    if (isAdmin) {
      fetchData();
    }
  }, [isAdmin, fetchData]);

  useEffect(() => {
    if (isOnline && isAdmin) {
      fetchData();
    }
  }, [isOnline, isAdmin, fetchData]);

  const handleSaveSettings = async () => {
    setSavingSettings(true);
    try {
      await setDoc(doc(db, 'system', 'settings'), {
        announcement,
        latestVersion,
        updateLink,
        updateMessage,
        forceUpdate,
        maintenanceMode,
        appName,
        appLogo,
        contactPhone,
        contactEmail,
        supportLink,
        contacts,
        privacyPolicy,
        features,
        updatedAt: new Date().toISOString()
      }, { merge: true });
      toast.success('সেটিংস সেভ করা হয়েছে');
    } catch (error) {
      console.error('Save Settings Error:', error);
      toast.error('সেটিংস সেভ করতে সমস্যা হয়েছে');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleToggleBlockUser = async (uid: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'users', uid), {
        blocked: !currentStatus
      });
      setUsers(users.map(u => u.uid === uid ? { ...u, blocked: !currentStatus } : u));
      toast.success(currentStatus ? 'ইউজার আনব্লক করা হয়েছে' : 'ইউজার ব্লক করা হয়েছে');
    } catch (error) {
      console.error('Block User Error:', error);
      toast.error('অ্যাকশনটি সম্পন্ন করা যায়নি');
    }
  };

  const handleDeleteUser = async (uid: string) => {
    setConfirmModal({
      show: true,
      title: 'ইউজার ডিলিট',
      message: 'আপনি কি নিশ্চিত যে আপনি এই ইউজারকে ডিলিট করতে চান? এটি আর ফিরিয়ে আনা যাবে না।',
      type: 'danger',
      onConfirm: async () => {
        try {
          console.log('Admin: Deleting user', uid);
          
          // 1. Get the current user's ID token for authentication
          const idToken = await auth.currentUser?.getIdToken();
          
          if (!idToken) {
            toast.error('আপনার সেশন শেষ হয়ে গেছে, আবার লগইন করুন।');
            return;
          }

          // 2. Call the backend API to delete the user from Firebase Auth
          const response = await fetch('/api/admin/delete-user', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ uid, idToken }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'ইউজার ডিলিট করতে ব্যর্থ হয়েছে');
          }

          // 3. Update the local state
          setUsers(users.filter(u => u.uid !== uid));
          toast.success('ইউজার ডিলিট করা হয়েছে');
        } catch (error: any) {
          console.error('Delete User Error:', error);
          toast.error(error.message || 'ইউজার ডিলিট করতে সমস্যা হয়েছে');
        }
      }
    });
  };

  const handleDeleteFeedback = async (id: string) => {
    setConfirmModal({
      show: true,
      title: 'ফিডব্যাক ডিলিট',
      message: 'আপনি কি এই ফিডব্যাকটি ডিলিট করতে চান?',
      type: 'danger',
      onConfirm: async () => {
        try {
          console.log('Admin: Deleting feedback', id);
          await deleteDoc(doc(db, 'feedback', id));
          setFeedback(feedback.filter(f => f.id !== id));
          toast.success('ফিডব্যাক ডিলিট করা হয়েছে');
        } catch (error: any) {
          console.error('Delete Feedback Error:', error);
          handleFirestoreError(error, OperationType.DELETE, `feedback/${id}`);
        }
      }
    });
  };

  const handleResetPin = async (uid: string) => {
    setConfirmModal({
      show: true,
      title: 'পিন রিসেট',
      message: 'আপনি কি এই ইউজারের পিন রিসেট করতে চান?',
      type: 'warning',
      onConfirm: async () => {
        try {
          console.log('Admin: Resetting PIN for', uid);
          await updateDoc(doc(db, 'users', uid), {
            pin: '',
            pinEnabled: false
          });
          setUsers(users.map(u => u.uid === uid ? { ...u, pin: '', pinEnabled: false } : u));
          toast.success('পিন রিসেট করা হয়েছে');
        } catch (error: any) {
          console.error('Reset PIN Error:', error);
          handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
        }
      }
    });
  };

  const filteredUsers = users.filter(u => 
    u.ownerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.shopName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const tabs = [
    { id: 'overview', label: 'ওভারভিউ', icon: LayoutDashboard },
    { id: 'users', label: 'ইউজার ম্যানেজমেন্ট', icon: Users },
    { id: 'feedback', label: 'ফিডব্যাক', icon: MessageSquare },
    { id: 'settings', label: 'সিস্টেম সেটিংস', icon: Settings },
  ];

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.show}
        onClose={() => setConfirmModal({ ...confirmModal, show: false })}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.type}
      />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900">পাওয়ারফুল অ্যাডমিন প্যানেল</h1>
          <p className="text-slate-500 font-medium">সিস্টেমের সবকিছু এখান থেকে কন্ট্রোল করুন</p>
        </div>
        <div className="flex items-center gap-3 self-start">
          <button 
            onClick={() => fetchData(true)}
            disabled={refreshing}
            className="p-2 bg-white text-slate-600 rounded-2xl border border-slate-200 shadow-sm hover:bg-slate-50 transition-all disabled:opacity-50"
            title="Refresh Data"
          >
            <Activity className={cn("w-5 h-5", refreshing && "animate-spin text-emerald-500")} />
          </button>
          <div className="bg-emerald-100 text-emerald-700 px-4 py-2 rounded-2xl flex items-center gap-2 font-bold border border-emerald-200">
            <Shield className="w-5 h-5" />
            সুপার অ্যাডমিন মোড
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto gap-2 p-1 bg-slate-100 rounded-2xl no-scrollbar">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as AdminTab)}
            className={cn(
              "flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all whitespace-nowrap",
              activeTab === tab.id 
                ? "bg-white text-emerald-600 shadow-sm" 
                : "text-slate-500 hover:text-slate-700 hover:bg-white/50"
            )}
          >
            <tab.icon className="w-5 h-5" />
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard icon={Users} label="মোট ইউজার" value={stats.totalUsers} color="blue" />
              <StatCard icon={Store} label="মোট কাস্টমার" value={stats.totalCustomers} color="emerald" />
              <StatCard icon={Activity} label="মোট ট্রানজেকশন" value={stats.totalTransactions} color="amber" />
              <StatCard icon={MessageSquare} label="মোট ফিডব্যাক" value={stats.totalFeedback} color="purple" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                  <Activity className="w-6 h-6 text-emerald-500" />
                  সিস্টেম হেলথ
                </h3>
                <div className="space-y-6">
                  <HealthItem label="ডেটাবেস কানেকশন" status="online" />
                  <HealthItem label="অথেন্টিকেশন সার্ভিস" status="online" />
                  <HealthItem label="স্টোরেজ সার্ভিস" status="online" />
                  <div className="pt-4 border-t border-slate-50">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-500 font-medium">ডেটাবেস সাইজ</span>
                      <span className="font-bold text-slate-800">{stats.totalStorage}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                  <Bell className="w-6 h-6 text-amber-500" />
                  সাম্প্রতিক ফিডব্যাক
                </h3>
                <div className="space-y-4">
                  {feedback.slice(0, 3).map((f) => (
                    <div key={f.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-sm text-slate-700 font-medium line-clamp-2">{f.content}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{f.userEmail}</span>
                        <span className="text-[10px] text-slate-400">{formatDate(f.date)}</span>
                      </div>
                    </div>
                  ))}
                  {feedback.length === 0 && (
                    <p className="text-center text-slate-400 py-8">কোন ফিডব্যাক পাওয়া যায়নি</p>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'users' && (
          <motion.div
            key="users"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden"
          >
            <div className="p-8 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <h3 className="text-xl font-bold text-slate-800">ইউজার লিস্ট ({filteredUsers.length})</h3>
              <div className="flex items-center gap-4">
                <div className="relative flex-1 md:w-64">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="নাম, দোকান বা ইমেইল..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  />
                </div>
                <button className="p-3 bg-slate-50 rounded-xl text-slate-500 hover:bg-slate-100 transition-all">
                  <Filter className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="overflow-x-auto hidden md:block">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50">
                    <th className="px-8 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">ইউজার</th>
                    <th className="px-8 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">দোকান ও ঠিকানা</th>
                    <th className="px-8 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">যোগদান</th>
                    <th className="px-8 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredUsers.map((u) => (
                    <tr key={u.uid} className="hover:bg-slate-50/50 transition-all group">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-600 font-bold border border-slate-200">
                            {u.ownerName?.[0] || 'U'}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-bold text-slate-800">{u.ownerName || 'Unknown'}</p>
                              {u.blocked && (
                                <span className="px-2 py-0.5 bg-rose-100 text-rose-600 text-[10px] font-bold rounded-full uppercase tracking-wider">
                                  Blocked
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-400 flex items-center gap-1">
                              <Mail className="w-3 h-3" />
                              {u.email}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <p className="font-bold text-slate-700">{u.shopName || 'N/A'}</p>
                        <p className="text-xs text-slate-400 line-clamp-1">{u.shopAddress || 'No address'}</p>
                      </td>
                      <td className="px-8 py-6">
                        <p className="text-sm font-medium text-slate-600 flex items-center gap-1">
                          <Calendar className="w-4 h-4 text-slate-300" />
                          {u.createdAt ? formatDate(u.createdAt) : 'N/A'}
                        </p>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleToggleBlockUser(u.uid, !!u.blocked)}
                            className={cn(
                              "p-2 rounded-xl transition-all",
                              u.blocked ? "bg-amber-100 text-amber-600 hover:bg-amber-200" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                            )}
                            title={u.blocked ? "Unblock User" : "Block User"}
                          >
                            {u.blocked ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                          </button>
                          <button 
                            onClick={() => handleResetPin(u.uid)}
                            className="p-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-xl transition-all"
                            title="Reset PIN"
                          >
                            <Shield className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => handleDeleteUser(u.uid)}
                            className="p-2 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-xl transition-all" 
                            title="Delete User"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden divide-y divide-slate-50">
              {filteredUsers.map((u) => (
                <div key={u.uid} className="p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600 font-bold border border-slate-200">
                      {u.ownerName?.[0] || 'U'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-slate-800 truncate text-sm">{u.ownerName || 'Unknown'}</p>
                        {u.blocked && (
                          <span className="px-1.5 py-0.5 bg-rose-100 text-rose-600 text-[8px] font-bold rounded-full uppercase tracking-wider">
                            Blocked
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 truncate">{u.email}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">দোকান</p>
                      <p className="text-xs font-bold text-slate-700 truncate">{u.shopName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">যোগদান</p>
                      <p className="text-xs font-bold text-slate-700">{u.createdAt ? formatDate(u.createdAt) : 'N/A'}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button 
                      onClick={() => handleToggleBlockUser(u.uid, !!u.blocked)}
                      className={cn(
                        "flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-2 font-bold text-[10px]",
                        u.blocked ? "bg-amber-100 text-amber-600" : "bg-slate-100 text-slate-600"
                      )}
                    >
                      {u.blocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                      {u.blocked ? 'আনব্লক' : 'ব্লক'}
                    </button>
                    <button 
                      onClick={() => handleResetPin(u.uid)}
                      className="p-2 bg-emerald-50 text-emerald-600 rounded-xl"
                    >
                      <Shield className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDeleteUser(u.uid)}
                      className="p-2 bg-rose-50 text-rose-600 rounded-xl" 
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {filteredUsers.length === 0 && (
              <div className="py-20 text-center">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-10 h-10 text-slate-200" />
                </div>
                <p className="text-slate-400 font-medium">কোন ইউজার পাওয়া যায়নি</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'feedback' && (
          <motion.div
            key="feedback"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {feedback.map((f) => (
              <div key={f.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-800">{f.userEmail}</p>
                      <p className="text-xs text-slate-400">{formatDate(f.date)}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleDeleteFeedback(f.id)}
                    className="p-2 text-slate-300 hover:text-rose-500 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <p className="text-slate-700 leading-relaxed">{f.content}</p>
                </div>
              </div>
            ))}
            {feedback.length === 0 && (
              <div className="bg-white py-20 rounded-[2.5rem] text-center border border-slate-100">
                <MessageSquare className="w-16 h-16 text-slate-100 mx-auto mb-4" />
                <p className="text-slate-400 font-medium">কোন ফিডব্যাক নেই</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-8 md:p-12 rounded-[2.5rem] border border-slate-100 shadow-sm"
          >
            <div className="max-w-4xl">
              <div className="flex items-center justify-between mb-10">
                <div>
                  <h3 className="text-2xl font-bold text-slate-800 mb-2">সিস্টেম সেটিংস</h3>
                  <p className="text-slate-500 font-medium">পুরো অ্যাপ্লিকেশনের গ্লোবাল সেটিংস এখান থেকে পরিবর্তন করুন।</p>
                </div>
                <div className="flex items-center gap-3 p-4 bg-rose-50 rounded-2xl border border-rose-100">
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-rose-600 uppercase tracking-wider">মেনটেন্যান্স মোড</span>
                    <span className="text-[10px] text-rose-400 font-medium">অ্যাপ বন্ধ থাকবে</span>
                  </div>
                  <button
                    onClick={() => setMaintenanceMode(!maintenanceMode)}
                    className={cn(
                      "relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus:outline-none",
                      maintenanceMode ? "bg-rose-500" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "inline-block h-5 w-5 transform rounded-full bg-white transition-transform",
                        maintenanceMode ? "translate-x-6" : "translate-x-1"
                      )}
                    />
                  </button>
                </div>
              </div>

              <div className="space-y-12">
                {/* App Branding */}
                <div className="space-y-6">
                  <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Store className="w-5 h-5 text-emerald-500" />
                    অ্যাপ ব্র্যান্ডিং
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 ml-1">অ্যাপের নাম</label>
                      <input 
                        type="text"
                        value={appName}
                        onChange={(e) => setAppName(e.target.value)}
                        placeholder="বাকি খাতা প্রো"
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 ml-1">লোগো ইউআরএল</label>
                      <input 
                        type="text"
                        value={appLogo}
                        onChange={(e) => setAppLogo(e.target.value)}
                        placeholder="https://..."
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Announcement Section */}
                <div className="space-y-4">
                  <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Bell className="w-5 h-5 text-amber-500" />
                    ঘোষণা ও নোটিশ
                  </h4>
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-slate-700 ml-1">
                      গ্লোবাল অ্যানাউন্সমেন্ট (সব ইউজার দেখবে)
                    </label>
                    <textarea
                      value={announcement}
                      onChange={(e) => setAnnouncement(e.target.value)}
                      placeholder="এখানে আপনার মেসেজ লিখুন..."
                      rows={3}
                      className="w-full p-6 bg-slate-50 border border-slate-200 rounded-3xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none font-medium"
                    />
                  </div>
                </div>

                {/* Feature Toggles (Editor Option) */}
                <div className="space-y-6">
                  <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-emerald-500" />
                    ফিচার কন্ট্রোল (এডিটর অপশন)
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <FeatureToggle 
                      label="সঞ্চয় (Savings)" 
                      enabled={features.savings} 
                      onChange={(val) => setFeatures({...features, savings: val})} 
                    />
                    <FeatureToggle 
                      label="ঋণ (Loans)" 
                      enabled={features.loans} 
                      onChange={(val) => setFeatures({...features, loans: val})} 
                    />
                    <FeatureToggle 
                      label="নোট (Notes)" 
                      enabled={features.notes} 
                      onChange={(val) => setFeatures({...features, notes: val})} 
                    />
                    <FeatureToggle 
                      label="ক্যালকুলেটর (Calculator)" 
                      enabled={features.calculator} 
                      onChange={(val) => setFeatures({...features, calculator: val})} 
                    />
                    <FeatureToggle 
                      label="রিপোর্ট (Reports)" 
                      enabled={features.reports} 
                      onChange={(val) => setFeatures({...features, reports: val})} 
                    />
                    <FeatureToggle 
                      label="ফিডব্যাক (Feedback)" 
                      enabled={features.feedback} 
                      onChange={(val) => setFeatures({...features, feedback: val})} 
                    />
                    <FeatureToggle 
                      label="AI কোটস" 
                      enabled={(features as any).aiQuotes} 
                      onChange={(val) => setFeatures({...features, aiQuotes: val} as any)} 
                    />
                    <FeatureToggle 
                      label="কাস্টমার ট্যাগ" 
                      enabled={(features as any).customerTags} 
                      onChange={(val) => setFeatures({...features, customerTags: val} as any)} 
                    />
                    <FeatureToggle 
                      label="পিন লক" 
                      enabled={(features as any).pinLock} 
                      onChange={(val) => setFeatures({...features, pinLock: val} as any)} 
                    />
                  </div>
                </div>

                {/* App Update Management */}
                <div className="space-y-6">
                  <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-500" />
                    অ্যাপ আপডেট ম্যানেজমেন্ট
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 ml-1">লেটেস্ট ভার্সন</label>
                      <input 
                        type="text"
                        value={latestVersion}
                        onChange={(e) => setLatestVersion(e.target.value)}
                        placeholder="e.g. 2.0.1"
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 ml-1">আপডেট লিঙ্ক (APK/Store)</label>
                      <input 
                        type="text"
                        value={updateLink}
                        onChange={(e) => setUpdateLink(e.target.value)}
                        placeholder="https://..."
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">আপডেট মেসেজ</label>
                    <textarea
                      value={updateMessage}
                      onChange={(e) => setUpdateMessage(e.target.value)}
                      placeholder="নতুন কি কি যোগ করা হয়েছে..."
                      rows={2}
                      className="w-full p-6 bg-slate-50 border border-slate-200 rounded-3xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none font-medium"
                    />
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                    <input 
                      type="checkbox"
                      id="forceUpdate"
                      checked={forceUpdate}
                      onChange={(e) => setForceUpdate(e.target.checked)}
                      className="w-5 h-5 rounded border-blue-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="forceUpdate" className="text-sm font-bold text-blue-800">
                      ফোর্স আপডেট (ইউজারকে আপডেট করতেই হবে)
                    </label>
                  </div>
                </div>

                {/* Contact & Support */}
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                      <Mail className="w-5 h-5 text-purple-500" />
                      কন্টাক্ট ও সাপোর্ট (ডায়নামিক)
                    </h4>
                    <button 
                      onClick={() => setContacts([...contacts, { label: '', value: '' }])}
                      className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl font-bold hover:bg-emerald-100 transition-all"
                    >
                      <Plus className="w-4 h-4" />
                      নতুন ফিল্ড
                    </button>
                  </div>

                  <div className="space-y-4">
                    {contacts.map((contact, index) => (
                      <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6 bg-slate-50 rounded-3xl border border-slate-100 relative group">
                        <button 
                          onClick={() => setContacts(contacts.filter((_, i) => i !== index))}
                          className="absolute -top-2 -right-2 w-8 h-8 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center transition-all shadow-sm hover:bg-rose-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 ml-1 uppercase tracking-wider">লেবেল (যেমন: ফোন, ইমেইল)</label>
                          <input 
                            type="text"
                            value={contact.label}
                            onChange={(e) => {
                              const newContacts = [...contacts];
                              newContacts[index].label = e.target.value;
                              setContacts(newContacts);
                            }}
                            placeholder="লেবেল লিখুন..."
                            className="w-full px-5 py-3 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 ml-1 uppercase tracking-wider">তথ্য (যেমন: নম্বর বা লিঙ্ক)</label>
                          <input 
                            type="text"
                            value={contact.value}
                            onChange={(e) => {
                              const newContacts = [...contacts];
                              newContacts[index].value = e.target.value;
                              setContacts(newContacts);
                            }}
                            placeholder="তথ্য লিখুন..."
                            className="w-full px-5 py-3 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                          />
                        </div>
                      </div>
                    ))}
                    {contacts.length === 0 && (
                      <div className="text-center py-10 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                        <p className="text-slate-400 font-medium">কোন কন্টাক্ট ফিল্ড নেই। "নতুন ফিল্ড" বাটনে ক্লিক করুন।</p>
                      </div>
                    )}
                  </div>

                  <div className="h-px bg-slate-100 my-8" />
                  
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest">পুরাতন কন্টাক্ট সেটিংস (ব্যাকআপ)</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 ml-1">সাপোর্ট ফোন</label>
                      <input 
                        type="text"
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        placeholder="+880..."
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 ml-1">সাপোর্ট ইমেইল</label>
                      <input 
                        type="text"
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        placeholder="support@..."
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">সাপোর্ট লিঙ্ক (WhatsApp/Messenger)</label>
                    <input 
                      type="text"
                      value={supportLink}
                      onChange={(e) => setSupportLink(e.target.value)}
                      placeholder="https://..."
                      className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    />
                  </div>
                </div>

                {/* Legal */}
                <div className="space-y-4">
                  <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Shield className="w-5 h-5 text-slate-500" />
                    প্রাইভেসি পলিসি
                  </h4>
                  <textarea
                    value={privacyPolicy}
                    onChange={(e) => setPrivacyPolicy(e.target.value)}
                    placeholder="আপনার অ্যাপের প্রাইভেসি পলিসি এখানে লিখুন..."
                    rows={5}
                    className="w-full p-6 bg-slate-50 border border-slate-200 rounded-3xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none font-medium"
                  />
                </div>

                <div className="pt-6 border-t border-slate-50">
                  <button
                    onClick={handleSaveSettings}
                    disabled={savingSettings}
                    className="flex items-center gap-2 px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all active:scale-95 disabled:opacity-50"
                  >
                    {savingSettings ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    সেটিংস সেভ করুন
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const StatCard = ({ icon: Icon, label, value, color }: any) => {
  const colors: any = {
    blue: "bg-blue-50 text-blue-600",
    emerald: "bg-emerald-50 text-emerald-600",
    amber: "bg-amber-50 text-amber-600",
    purple: "bg-purple-50 text-purple-600"
  };

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
      <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center mb-6", colors[color])}>
        <Icon className="w-7 h-7" />
      </div>
      <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">{label}</p>
      <h3 className="text-4xl font-black text-slate-900 mt-2">{value}</h3>
    </div>
  );
};

const HealthItem = ({ label, status }: { label: string, status: 'online' | 'offline' | 'warning' }) => (
  <div className="flex items-center justify-between">
    <span className="text-slate-600 font-medium">{label}</span>
    <div className="flex items-center gap-2">
      <span className={cn(
        "text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider",
        status === 'online' ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
      )}>
        {status}
      </span>
      <div className={cn(
        "w-2 h-2 rounded-full animate-pulse",
        status === 'online' ? "bg-emerald-500" : "bg-rose-500"
      )} />
    </div>
  </div>
);

const FeatureToggle = ({ label, enabled, onChange }: { label: string, enabled: boolean, onChange: (val: boolean) => void }) => (
  <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
    <span className="font-bold text-slate-700">{label}</span>
    <button
      onClick={() => onChange(!enabled)}
      className={cn(
        "relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus:outline-none",
        enabled ? "bg-emerald-500" : "bg-slate-300"
      )}
    >
      <span
        className={cn(
          "inline-block h-5 w-5 transform rounded-full bg-white transition-transform",
          enabled ? "translate-x-6" : "translate-x-1"
        )}
      />
    </button>
  </div>
);
