import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Phone, 
  MapPin, 
  Plus, 
  Minus, 
  Calculator, 
  Edit2, 
  Trash2, 
  Calendar,
  FileText,
  X,
  Check,
  Loader2,
  Download,
  MessageSquare,
  Clock
} from 'lucide-react';
import { 
  doc, 
  getDoc, 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  writeBatch,
  increment,
  deleteField
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Customer, Transaction, InventoryItem } from '../types';
import { formatCurrency, formatDate, formatTime, cn, parseNumber } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';
import { SelectProductDropdown } from '../components/SelectProductDropdown';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface CustomerProfileProps {
  customerId: string;
  onBack: () => void;
}

export const CustomerProfile: React.FC<CustomerProfileProps> = ({ customerId, onBack }) => {
  const { user } = useAuth();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [showAddModal, setShowAddModal] = useState<'baki' | 'joma' | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showEditTransModal, setShowEditTransModal] = useState<Transaction | null>(null);
  const [showDueDateModal, setShowDueDateModal] = useState(false);
  const [editDueDate, setEditDueDate] = useState({ date: '', amount: '' });
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');

  const [selectedProductId, setSelectedProductId] = useState('');
  const [productQuantity, setProductQuantity] = useState('1');
  const [productSaleType, setProductSaleType] = useState('loose');
  const [productDiscount, setProductDiscount] = useState('0');

  // Handle product selection to auto-fill amount
  useEffect(() => {
    if (selectedProductId && showAddModal === 'baki') {
      const item = inventoryItems.find(i => i.id === selectedProductId);
      if (item) {
        let unitPrice = item.sellingPrice;
        if (item.isPackaged && productSaleType === 'loose') {
          unitPrice = item.looseSellingPrice || item.sellingPrice;
        }
        const total = (unitPrice * parseNumber(productQuantity)) - parseNumber(productDiscount);
        setAmount(total > 0 ? total.toString() : '');
      }
    }
  }, [selectedProductId, productQuantity, productSaleType, productDiscount, showAddModal, inventoryItems]);

  const [editCustomer, setEditCustomer] = useState({ name: '', phone: '', address: '', profilePic: '' });
  const [visibleTxs, setVisibleTxs] = useState(50);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast.error('ছবি ১ মেগাবাইটের কম হতে হবে');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditCustomer(prev => ({ ...prev, profilePic: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'customer' | 'transaction' | 'all', id?: string, amount?: number, transType?: 'baki' | 'joma' } | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);

  const handleSetDueDate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer) return;

    setLoading(true);
    try {
      const updateData: any = {
        dueDate: editDueDate.date || null
      };

      if (editDueDate.date) {
        if (editDueDate.amount && !isNaN(parseNumber(editDueDate.amount))) {
          updateData.dueAmount = parseNumber(editDueDate.amount);
        } else {
          updateData.dueAmount = deleteField();
        }
      } else {
         updateData.dueAmount = deleteField();
         updateData.dueDate = deleteField();
      }

      await updateDoc(doc(db, 'customers', customer.id), updateData);
      toast.success('পরিশোধের তারিখ আপডেট করা হয়েছে');
      setShowDueDateModal(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `customers/${customer.id}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) return;
    
    // Fetch customer data
    const unsubCustomer = onSnapshot(doc(db, 'customers', customerId), (doc) => {
      if (doc.exists()) {
        const data = doc.data() as Customer;
        setCustomer({ id: doc.id, ...data } as Customer);
        setEditCustomer({ 
          name: data.name || '', 
          phone: data.phone || '', 
          address: data.address || '',
          profilePic: data.profilePic || ''
        });
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, `customers/${customerId}`));

    const q = query(
      collection(db, 'transactions'), 
      where('ownerUid', '==', user.uid),
      where('customerId', '==', customerId),
      orderBy('date', 'desc')
    );
    const unsubTransactions = onSnapshot(q, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'transactions'));

    const qInv = query(
      collection(db, 'inventory'),
      where('ownerUid', '==', user.uid)
    );
    const unsubInventory = onSnapshot(qInv, (snapshot) => {
      setInventoryItems(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'inventory'));

    return () => {
      unsubCustomer();
      unsubTransactions();
      unsubInventory();
    };
  }, [customerId, user]);

  useEffect(() => {
    const handleCloseCalc = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleCloseCalc);
    return () => window.removeEventListener('close-calculator', handleCloseCalc);
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const handleCalculatorSave = (total: number) => {
    setAmount(total.toString());
    closeCalculator();
  };

  const handleTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(parseNumber(amount))) return;
    if (!user || !customer) return;

    setLoading(true);
    const numAmount = parseNumber(amount);
    const type = showAddModal!;
    
    // Optimistic UI: Close modal and reset state immediately
    const prevSelectedProduct = selectedProductId;
    const prevProductQty = productQuantity;
    const prevNote = note;

    setShowAddModal(null);
    setAmount('');
    setNote('');
    setSelectedProductId('');
    setProductQuantity('1');
    setProductSaleType('loose');
    setProductDiscount('0');
    setLoading(false);
    toast.success(type === 'baki' ? 'বাকি যোগ করা হয়েছে' : 'জমা যোগ করা হয়েছে');

    try {
      const batch = writeBatch(db);
      const now = new Date();
      
      // Update inventory if a product was selected during a 'baki' transaction
      if (type === 'baki' && prevSelectedProduct) {
        const item = inventoryItems.find(i => i.id === prevSelectedProduct);
        if (item) {
          const sellQty = parseNumber(prevProductQty) || 1;
          
          let stockToRemove = sellQty;
          let unitPurchaseCost = item.purchasePrice;

          if (item.isPackaged) {
            if (productSaleType === 'package') {
              stockToRemove = sellQty * (item.piecesPerPackage || 1);
              unitPurchaseCost = item.purchasePrice;
            } else {
              stockToRemove = sellQty;
              unitPurchaseCost = item.purchasePrice / (item.piecesPerPackage || 1);
            }
          }
          
          const discountAmt = parseNumber(productDiscount);
          const currentAmount = numAmount; // The amount input is the final calculated amount
          const profitEarned = currentAmount - (sellQty * unitPurchaseCost);

          if (stockToRemove <= item.stockQuantity) {
            batch.update(doc(db, 'inventory', item.id), {
              stockQuantity: item.stockQuantity - stockToRemove,
              totalSoldQty: (item.totalSoldQty || 0) + stockToRemove,
              totalSoldAmount: (item.totalSoldAmount || 0) + currentAmount,
              totalProfitEarned: (item.totalProfitEarned || 0) + profitEarned,
              updatedAt: now.toISOString()
            });
          } else {
            toast.error(`স্টকে যথেষ্ট ${item.name} নেই!`);
            return; // Prevent transaction if stock is insufficient
          }
        }
      }

      // Automatically add to CashFlow if it's a 'joma' (collection)
      if (type === 'joma') {
        const cashFlowRef = doc(collection(db, 'cashEntries'));
        batch.set(cashFlowRef, {
          amount: numAmount,
          type: 'income',
          category: 'বকেয়া আদায়',
          paymentMethod: 'Cash',
          note: `বকেয়া আদায় (${customer.name})${prevNote ? ' - ' + prevNote : ''}`,
          date: now.toISOString(),
          ownerUid: user.uid
        });
      }

      // Add transaction
      let autoNote = '';
      if (type === 'baki' && prevSelectedProduct) {
        const item = inventoryItems.find(i => i.id === prevSelectedProduct);
        if (item) {
          const unitLabel = item.isPackaged ? (productSaleType === 'package' ? item.packageUnit : item.looseUnit) : item.unit;
          autoNote = `পণ্য কেনা: ${item.name} (${prevProductQty} ${unitLabel})`;
          if (parseNumber(productDiscount) > 0) {
            autoNote += ` (ছাড়: ${productDiscount} ৳)`;
          }
        }
      }

      const transData: any = {
        customerId,
        amount: numAmount,
        type,
        note: prevNote || autoNote,
        date: now.toISOString(),
        ownerUid: user.uid
      };
      
      if (type === 'baki' && prevSelectedProduct) {
        const item = inventoryItems.find(i => i.id === prevSelectedProduct);
        if (item) {
          const sellQty = parseNumber(prevProductQty) || 1;
          let stockToRemove = sellQty;
          let unitPurchaseCost = item.purchasePrice;
          if (item.isPackaged) {
            if (productSaleType === 'package') {
              stockToRemove = sellQty * (item.piecesPerPackage || 1);
              unitPurchaseCost = item.purchasePrice;
            } else {
              stockToRemove = sellQty;
              unitPurchaseCost = item.purchasePrice / (item.piecesPerPackage || 1);
            }
          }
          const profitEarned = numAmount - (sellQty * unitPurchaseCost);
          
          transData.linkedItemId = item.id;
          transData.linkedStockRemoved = stockToRemove;
          transData.linkedProfitEarned = profitEarned;
        }
      }

      const transRef = doc(collection(db, 'transactions'));
      batch.set(transRef, transData);

      // Update customer balance
      const balanceChange = type === 'baki' ? numAmount : -numAmount;
      const newBalance = customer.totalBalance + balanceChange;
      
      // Improved Auto-tagging logic
      const createdDate = customer.createdAt ? new Date(customer.createdAt) : now;
      const daysSinceCreated = (now.getTime() - createdDate.getTime()) / (1000 * 3600 * 24);
      const transCount = transactions.length + 1;

      let newTag: string = user?.customerCategories?.[0] || 'Regular';
      
      // 1. Risky: High debt (above user limit or 1000)
      if (newBalance > (user.debtLimits?.red || 1000)) {
        newTag = user?.customerCategories?.find(c => c === 'Risky') || 'Risky';
      } 
      // 2. New: Created within 7 days and has few transactions
      else if (daysSinceCreated < 7 && transCount < 5) {
        newTag = user?.customerCategories?.find(c => c === 'New') || 'New';
      } 
      // 3. VIP: High transaction volume and low debt
      else if (newBalance < 500 && transCount > 15) {
        newTag = user?.customerCategories?.find(c => c === 'VIP') || 'VIP';
      } 
      // 4. Regular: Default
      else {
        newTag = user?.customerCategories?.find(c => c === 'Regular') || user?.customerCategories?.[0] || 'Regular';
      }

      const customerRef = doc(db, 'customers', customerId);
      batch.update(customerRef, {
        totalBalance: increment(balanceChange),
        tag: newTag,
        updatedAt: now.toISOString()
      });

      await batch.commit();
    } catch (error) {
      console.error('Transaction error:', error);
      toast.error('সেভ করতে সমস্যা হয়েছে, পরে চেষ্টা করুন');
    }
  };

  const handleDeleteTransaction = (transId: string, transAmount: number, transType: 'baki' | 'joma') => {
    setConfirmDelete({ type: 'transaction', id: transId, amount: transAmount, transType });
  };

  const executeDeleteTransaction = async () => {
    if (!confirmDelete || !confirmDelete.id || !confirmDelete.amount || !confirmDelete.transType) return;
    const { id: transId, amount: transAmount, transType } = confirmDelete;
    const transToDelete = transactions.find(t => t.id === transId);
    
    // Optimistic UI
    setConfirmDelete(null);

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'transactions', transId));

      // Revert linked inventory if applicable
      if (transToDelete?.linkedItemId) {
        batch.update(doc(db, 'inventory', transToDelete.linkedItemId), {
          stockQuantity: increment(transToDelete.linkedStockRemoved || 0),
          totalSoldQty: increment(-(transToDelete.linkedStockRemoved || 0)),
          totalSoldAmount: increment(-transToDelete.amount),
          totalProfitEarned: increment(-(transToDelete.linkedProfitEarned || 0)),
        });
      }
      
      // Improved Auto-tagging logic
      const balanceChange = transType === 'baki' ? -transAmount : transAmount;
      const now = new Date();
      const createdDate = customer.createdAt ? new Date(customer.createdAt) : now;
      const daysSinceCreated = (now.getTime() - createdDate.getTime()) / (1000 * 3600 * 24);
      const transCount = Math.max(0, transactions.length - 1);
      const newBalance = customer.totalBalance + balanceChange;

      let newTag: string = user?.customerCategories?.[0] || 'Regular';
      if (newBalance > (user.debtLimits?.red || 1000)) {
        newTag = user?.customerCategories?.find(c => c === 'Risky') || 'Risky';
      } else if (daysSinceCreated < 7 && transCount < 5) {
        newTag = user?.customerCategories?.find(c => c === 'New') || 'New';
      } else if (newBalance < 500 && transCount > 15) {
        newTag = user?.customerCategories?.find(c => c === 'VIP') || 'VIP';
      } else {
        newTag = user?.customerCategories?.find(c => c === 'Regular') || user?.customerCategories?.[0] || 'Regular';
      }

      batch.update(doc(db, 'customers', customerId), {
        totalBalance: increment(balanceChange),
        tag: newTag,
        updatedAt: now.toISOString()
      });

      await batch.commit();
      toast.success('লেনদেন মুছে ফেলা হয়েছে');
    } catch (error) {
      console.error('Delete transaction error:', error);
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const handleDeleteCustomer = () => {
    setConfirmDelete({ type: 'customer' });
  };

  const executeDeleteCustomer = async () => {
    if (!confirmDelete) return;
    
    // Optimistic UI
    setConfirmDelete(null);
    toast.success('কাস্টমার মুছে ফেলা হয়েছে');
    onBack();

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'customers', customerId));
      transactions.forEach(t => {
        batch.delete(doc(db, 'transactions', t.id));
        if (t.linkedItemId) {
          batch.update(doc(db, 'inventory', t.linkedItemId), {
            stockQuantity: increment(t.linkedStockRemoved || 0),
            totalSoldQty: increment(-(t.linkedStockRemoved || 0)),
            totalSoldAmount: increment(-t.amount),
            totalProfitEarned: increment(-(t.linkedProfitEarned || 0)),
          });
        }
      });
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `customers/${customerId}`);
    }
  };

  const handleEditCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    // Optimistic UI
    setShowEditModal(false);
    toast.success('প্রোফাইল আপডেট করা হয়েছে');

    const updateData = {
      name: editCustomer.name || '',
      phone: editCustomer.phone || '',
      address: editCustomer.address || '',
      profilePic: editCustomer.profilePic || ''
    };

    try {
      await updateDoc(doc(db, 'customers', customerId), updateData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `customers/${customerId}`);
    }
  };

  const handleEditTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showEditTransModal || !user || !customer) return;
    
    // Optimistic UI
    const modalToEdit = showEditTransModal;
    setShowEditTransModal(null);
    setAmount('');
    setNote('');
    setLoading(false);
    toast.success('লেনদেন আপডেট করা হয়েছে');

    try {
      const batch = writeBatch(db);
      const oldAmount = modalToEdit.amount;
      const newAmount = parseNumber(amount);
      const type = modalToEdit.type;

      batch.update(doc(db, 'transactions', modalToEdit.id), {
        amount: newAmount,
        note
      });

      // Adjust balance: remove old, add new
      const oldBalanceChange = type === 'baki' ? -oldAmount : oldAmount;
      const newBalanceChange = type === 'baki' ? newAmount : -newAmount;
      const totalBalanceChange = oldBalanceChange + newBalanceChange;
      const newBalance = customer.totalBalance + totalBalanceChange;

      // Improved Auto-tagging logic
      const now = new Date();
      const createdDate = customer.createdAt ? new Date(customer.createdAt) : now;
      const daysSinceCreated = (now.getTime() - createdDate.getTime()) / (1000 * 3600 * 24);
      const transCount = transactions.length;

      let newTag: string = user?.customerCategories?.[0] || 'Regular';
      if (newBalance > (user.debtLimits?.red || 1000)) {
        newTag = user?.customerCategories?.find(c => c === 'Risky') || 'Risky';
      } else if (daysSinceCreated < 7 && transCount < 5) {
        newTag = user?.customerCategories?.find(c => c === 'New') || 'New';
      } else if (newBalance < 500 && transCount > 15) {
        newTag = user?.customerCategories?.find(c => c === 'VIP') || 'VIP';
      } else {
        newTag = user?.customerCategories?.find(c => c === 'Regular') || user?.customerCategories?.[0] || 'Regular';
      }
      
      batch.update(doc(db, 'customers', customerId), {
        totalBalance: increment(totalBalanceChange),
        tag: newTag
      });

      // Adjust linked inventory stats if amount changed
      if (modalToEdit.linkedItemId) {
        const amountDiff = newAmount - oldAmount;
        if (amountDiff !== 0) {
          batch.update(doc(db, 'inventory', modalToEdit.linkedItemId), {
            totalSoldAmount: increment(amountDiff),
            totalProfitEarned: increment(amountDiff)
          });
        }
      }

      await batch.commit();
    } catch (error) {
      console.error('Edit transaction error:', error);
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handleDeleteAllTransactions = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAllTransactions = async () => {
    setLoading(true);
    try {
      const batch = writeBatch(db);
      transactions.forEach(t => {
        batch.delete(doc(db, 'transactions', t.id));
        if (t.linkedItemId) {
          batch.update(doc(db, 'inventory', t.linkedItemId), {
            stockQuantity: increment(t.linkedStockRemoved || 0),
            totalSoldQty: increment(-(t.linkedStockRemoved || 0)),
            totalSoldAmount: increment(-t.amount),
            totalProfitEarned: increment(-(t.linkedProfitEarned || 0)),
          });
        }
      });
      // Reset tag based on creation date
      const now = new Date();
      const createdDate = customer.createdAt ? new Date(customer.createdAt) : now;
      const daysSinceCreated = (now.getTime() - createdDate.getTime()) / (1000 * 3600 * 24);
      const newTag = daysSinceCreated < 7 ? 'New' : 'Regular';

      batch.update(doc(db, 'customers', customerId), {
        totalBalance: 0,
        tag: newTag
      });
      await batch.commit();
      toast.success('সকল লেনদেন মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
      setConfirmDelete(null);
    }
  };

  const downloadPDF = () => {
    if (!customer || !user) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Add Logo if exists
    if (user.shopLogo) {
      try {
        doc.addImage(user.shopLogo, 'PNG', 10, 10, 20, 20);
      } catch (e) {
        console.error('Error adding logo to PDF:', e);
      }
    }

    // App Name & Shop Name
    doc.setFontSize(20);
    doc.setTextColor(16, 185, 129); // Emerald-600
    doc.text(user.shopName || 'বাকি খাতা', user.shopLogo ? 35 : 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('কাস্টমার রিপোর্ট', user.shopLogo ? 35 : 10, 28);

    // Customer Info
    doc.setDrawColor(240);
    doc.line(10, 35, pageWidth - 10, 35);
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`নাম: ${customer.name}`, 10, 45);
    doc.text(`ফোন: ${customer.phone || 'N/A'}`, 10, 52);
    doc.text(`ঠিকানা: ${customer.address || 'N/A'}`, 10, 59);
    
    const balanceText = `বর্তমান ব্যালেন্স: ${formatCurrency(Math.abs(customer.totalBalance))} (${customer.totalBalance > 0 ? 'পাবেন' : 'দেবেন'})`;
    doc.setFontSize(14);
    doc.setTextColor(customer.totalBalance > 0 ? 190 : 16, customer.totalBalance > 0 ? 18 : 185, customer.totalBalance > 0 ? 45 : 129);
    doc.text(balanceText, pageWidth - 10, 45, { align: 'right' });

    // Transactions Table
    const tableData = transactions.map(t => [
      formatDate(t.date),
      t.type === 'baki' ? 'বাকি (+)' : 'জমা (-)',
      formatCurrency(t.amount),
      t.note || '-'
    ]);

    autoTable(doc, {
      startY: 70,
      head: [['তারিখ', 'ধরন', 'পরিমাণ', 'নোট']],
      body: tableData,
      headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 253, 250] },
      styles: { font: 'helvetica', fontSize: 10 },
      margin: { top: 70 }
    });

    doc.save(`${customer.name}_report.pdf`);
    toast.success('PDF ডাউনলোড হচ্ছে...');
  };

  if (!customer) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="p-2 hover:bg-white rounded-xl transition-all">
          <ArrowLeft className="w-6 h-6 text-slate-600" />
        </button>
        <div className="flex gap-2">
          <button 
            onClick={downloadPDF}
            className="p-2 hover:bg-white rounded-xl transition-all text-emerald-600"
            title="PDF ডাউনলোড করুন"
          >
            <Download className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setShowEditModal(true)}
            className="p-2 hover:bg-white rounded-xl transition-all text-slate-400"
          >
            <Edit2 className="w-5 h-5" />
          </button>
          <button 
            onClick={handleDeleteCustomer}
            className="p-2 hover:bg-rose-50 rounded-xl transition-all text-rose-400"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-[2.5rem] p-5 shadow-sm border border-slate-100">
        <div className="flex items-center gap-4 mb-5">
          <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 text-xl font-bold shrink-0 overflow-hidden">
            {customer.profilePic ? (
              <img 
                src={customer.profilePic} 
                alt={customer.name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <img 
                src="/icon.png" 
                alt="App Icon" 
                className="w-full h-full object-cover opacity-40"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  const parent = (e.target as HTMLImageElement).parentElement;
                  if (parent) parent.innerText = customer.name[0];
                }}
              />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-bold text-slate-800 truncate">{customer.name}</h2>
              <span className={cn(
                "px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider",
                customer.tag === 'VIP' ? "bg-amber-100 text-amber-600" :
                customer.tag === 'Risky' ? "bg-rose-100 text-rose-600" : 
                customer.tag === 'New' ? "bg-blue-100 text-blue-600" :
                "bg-emerald-100 text-emerald-600"
              )}>
                {customer.tag}
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1 truncate">
              <MapPin className="w-3 h-3" /> {customer.address}
            </p>
          </div>
        </div>

        <div className="bg-slate-50 rounded-3xl p-4 flex items-center justify-between mb-4">
          <div>
            <p className="text-xs text-slate-600 font-black uppercase tracking-wider mb-1">বর্তমান ব্যালেন্স</p>
            <h3 className={cn(
              "text-3xl font-black",
              customer.totalBalance > 0 ? "text-rose-700" : "text-emerald-700"
            )}>
              {formatCurrency(Math.abs(customer.totalBalance))}
            </h3>
          </div>
          <div className="text-right flex flex-col items-end gap-2">
            <p className="text-xs font-black text-slate-700">
              {customer.totalBalance > 0 ? 'আপনি পাবেন' : 'কাস্টমার পাবে'}
            </p>
          </div>
        </div>

        <div className="bg-rose-50/50 border border-rose-100 rounded-3xl p-4 flex items-center justify-between">
          <div>
            <p className="text-[9px] text-rose-400 font-bold uppercase tracking-widest mb-0.5">পরিশোধের লক্ষ্যমাত্রা</p>
            {customer.dueDate ? (
              <div>
                <p className="text-sm font-black text-rose-600 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4" />
                  {formatDate(customer.dueDate)}
                </p>
                {customer.dueAmount && (
                  <p className="text-xs font-bold text-rose-500 mt-0.5">
                    লক্ষ্য: {formatCurrency(customer.dueAmount)}
                  </p>
                )}
              </div>
            ) : (
              <p className="text-xs font-bold text-slate-400">কোনো তারিখ সেট করা নেই</p>
            )}
          </div>
          <button 
            onClick={() => {
              setEditDueDate({ date: customer.dueDate || '', amount: customer.dueAmount?.toString() || '' });
              setShowDueDateModal(true);
            }}
            className="px-4 py-2 bg-white text-rose-600 rounded-xl text-xs font-bold shadow-sm border border-rose-100 hover:bg-rose-50 transition-all"
          >
            সেট করুন
          </button>
        </div>
      </div>

      {/* Contact Actions */}
      <div className="mb-6">
        {customer.phone ? (() => {
          let smsBody = '';
          let waText = '';
          try {
            if (customer.totalBalance > 0) {
              const formattedBalance = formatCurrency(Math.abs(customer.totalBalance));
              const msg = `আসসালামু আলাইকুম ${customer.name || ''} ভাই, আপনার বর্তমান বকেয়া বিল ${formattedBalance}। অনুগ্রহ করে বিলটি পরিশোধ করার অনুরোধ করা হলো। ধন্যবাদ।`;
              smsBody = `?body=${encodeURIComponent(msg)}`;
              waText = `?text=${encodeURIComponent(msg)}`;
            }
          } catch (e) {
            console.error(e);
          }
          
          const smsHref = `sms:${customer.phone}${smsBody}`;
          const waHref = `https://wa.me/${String(customer.phone).replace(/\D/g, '')}${waText}`;
          const telHref = `tel:${customer.phone}`;

          return (
          <div className="grid grid-cols-3 gap-4">
            <a 
              href={telHref}
              className="flex flex-col items-center gap-2 p-4 bg-blue-50 text-blue-600 rounded-3xl hover:bg-blue-100 transition-all font-bold"
            >
              <Phone className="w-6 h-6" />
              কল করুন
            </a>
            <a 
              href={smsHref}
              className="flex flex-col items-center gap-2 p-4 bg-indigo-50 text-indigo-600 rounded-3xl hover:bg-indigo-100 transition-all font-bold"
            >
              <MessageSquare className="w-6 h-6" />
              এসএমএস
            </a>
            <a 
              href={waHref}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-2 p-4 bg-green-50 text-green-600 rounded-3xl hover:bg-green-100 transition-all font-bold"
            >
              <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
              </svg>
              বিবার্তা
            </a>
          </div>
          );
        })() : (
          <button 
            onClick={() => setShowEditModal(true)}
            className="w-full py-4 bg-slate-50 border border-slate-100 border-dashed rounded-3xl text-sm font-bold text-slate-500 hover:bg-slate-100 transition-all flex items-center justify-center gap-2"
          >
            <Phone className="w-5 h-5" />
            যোগাযোগ করতে কাস্টমারের মোবাইল নম্বর যোগ করুন
          </button>
        )}
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-4">
        <button 
          onClick={() => setShowAddModal('baki')}
          className="flex flex-col items-center gap-2 p-4 bg-rose-50 text-rose-600 rounded-3xl hover:bg-rose-100 transition-all font-bold"
        >
          <Plus className="w-6 h-6" />
          বাকি (+)
        </button>
        <button 
          onClick={() => setShowAddModal('joma')}
          className="flex flex-col items-center gap-2 p-4 bg-emerald-50 text-emerald-600 rounded-3xl hover:bg-emerald-100 transition-all font-bold"
        >
          <Minus className="w-6 h-6" />
          জমা (-)
        </button>
        <button 
          onClick={(e) => {
            e.stopPropagation();
            setShowCalculator(true);
          }}
          className="flex flex-col items-center gap-2 p-4 bg-slate-100 text-slate-600 rounded-3xl hover:bg-slate-200 transition-all font-bold"
        >
          <Calculator className="w-6 h-6" />
          ক্যালকুলেটর
        </button>
      </div>

      {/* Transaction History */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
          {transactions.length > 0 && (
            <button 
              onClick={handleDeleteAllTransactions}
              className="text-[10px] font-bold text-rose-500 uppercase tracking-wider hover:bg-rose-50 px-2 py-1 rounded-lg transition-all"
            >
              সব মুছুন
            </button>
          )}
        </div>
        {transactions.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">এখনো কোন লেনদেন হয়নি</p>
          </div>
        ) : (
          <>
            {transactions.slice(0, visibleTxs).map((t) => (
              <div key={t.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center",
                    t.type === 'baki' ? "bg-rose-50 text-rose-500" : "bg-emerald-50 text-emerald-500"
                  )}>
                    {t.type === 'baki' ? <Plus className="w-5 h-5" /> : <Minus className="w-5 h-5" />}
                  </div>
                  <div>
                    <h5 className="font-black text-slate-800 text-lg">{formatCurrency(t.amount)}</h5>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 font-black mt-1">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                        {formatDate(t.date)}
                      </span>
                      <span className="flex items-center gap-1 text-slate-500">
                        <Clock className="w-3.5 h-3.5" />
                        {formatTime(t.date)}
                      </span>
                      {t.note && <span className="flex items-center gap-1 ml-2 text-slate-500 italic"><FileText className="w-3.5 h-3.5 text-slate-400" /> {t.note}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 transition-all">
                  <button 
                    onClick={() => {
                      setShowEditTransModal(t);
                      setAmount(t.amount.toString());
                      setNote(t.note || '');
                    }}
                    className="p-2 text-slate-300 hover:text-emerald-500"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleDeleteTransaction(t.id, t.amount, t.type)}
                    className="p-2 text-slate-300 hover:text-rose-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            
            {visibleTxs < transactions.length && (
              <button
                onClick={() => setVisibleTxs(prev => prev + 50)}
                className="w-full py-4 text-center text-sm font-bold text-slate-500 bg-slate-50 hover:bg-slate-100 rounded-2xl transition-all border border-slate-100"
              >
                আরও দেখুন
              </button>
            )}
          </>
        )}
      </div>

      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'customer'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteCustomer}
        title="কাস্টমার মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই কাস্টমার এবং তার সকল লেনদেন মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'transaction'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteTransaction}
        title="লেনদেন মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই লেনদেনটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAllTransactions}
        title="সব লেনদেন মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল লেনদেন মুছতে চান? এতে ব্যালেন্স ০ হয়ে যাবে।"
      />

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl max-h-[90vh] min-h-[65vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-black text-slate-800">
                  {showAddModal === 'baki' ? 'নতুন বাকি যোগ করুন' : 'নতুন জমা যোগ করুন'}
                </h3>
                <button onClick={() => setShowAddModal(null)} className="p-2 hover:bg-slate-100 rounded-full transition-all">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleTransaction} className="space-y-8">
                {showAddModal === 'baki' && (
                  <div className="space-y-1.5 border border-emerald-100 bg-emerald-50/50 p-4 rounded-2xl">
                    <label className="text-sm font-bold text-slate-800">পণ্য সিলেক্ট করুন (ঐচ্ছিক)</label>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">পণ্য বাছাই করলে স্টক থেকে অটোমেটিক কমে যাবে</p>
                    <div className="mt-2 text-base font-normal">
                      <SelectProductDropdown 
                        items={inventoryItems}
                        selectedId={selectedProductId}
                        onSelect={(id) => setSelectedProductId(id)}
                        allowClear={true}
                      />
                    </div>

                    {selectedProductId && (
                      <div className="mt-3 pt-3 border-t border-emerald-200/50 grid grid-cols-1 md:grid-cols-2 gap-4">
                        {inventoryItems.find(i => i.id === selectedProductId)?.isPackaged && (
                          <div className="space-y-1.5">
                            <label className="text-sm font-bold text-slate-600">কিভাবে বিক্রি করবেন?</label>
                            <select
                              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium appearance-none"
                              value={productSaleType}
                              onChange={(e) => setProductSaleType(e.target.value)}
                            >
                              <option value="package">বড় একক ({inventoryItems.find(i => i.id === selectedProductId)?.packageUnit})</option>
                              <option value="loose">খুচরা ({inventoryItems.find(i => i.id === selectedProductId)?.looseUnit})</option>
                            </select>
                          </div>
                        )}
                        <div className="space-y-1.5">
                          <label className="text-sm font-bold text-slate-600">পরিমাণ ({inventoryItems.find(i => i.id === selectedProductId)?.isPackaged ? (productSaleType === 'package' ? inventoryItems.find(i => i.id === selectedProductId)?.packageUnit : inventoryItems.find(i => i.id === selectedProductId)?.looseUnit) : inventoryItems.find(i => i.id === selectedProductId)?.unit})</label>
                          <input
                            type="number"
                            min="0.01"
                            max={inventoryItems.find(i => i.id === selectedProductId)?.stockQuantity || 0}
                            step="any"
                            placeholder="পরিমাণ"
                            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                            value={productQuantity}
                            onChange={(e) => setProductQuantity(e.target.value)}
                          />
                        </div>
                        <div className="space-y-1.5 md:col-span-2">
                          <label className="text-sm font-bold text-rose-600">ছাড় (Discount)</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="0"
                            className="w-full px-4 py-3 bg-white border border-rose-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-rose-600"
                            value={productDiscount}
                            onChange={(e) => setProductDiscount(e.target.value)}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-4">
                  <div className="flex items-center justify-between px-1">
                    <label className="text-sm font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="flex items-center gap-1.5 text-emerald-600 font-bold text-sm hover:opacity-80 transition-all"
                    >
                      <Calculator className="w-4 h-4" />
                      ক্যালকুলেটর
                    </button>
                  </div>
                  
                  {/* Quick Buttons */}
                  <div className="grid grid-cols-5 gap-2">
                    {(user?.quickButtons || [10, 20, 50, 100, 500]).map((btn: any) => (
                      <button
                        key={btn.id || btn}
                        type="button"
                        onClick={() => setAmount(prev => (parseNumber(prev) + parseNumber(btn.value || btn)).toString())}
                        className="py-2.5 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-600 rounded-xl text-xs font-black border border-slate-100 transition-all"
                      >
                        +{btn.value || btn}
                      </button>
                    ))}
                  </div>

                  <div className={cn(
                    "relative p-1 rounded-[2rem] border-2 transition-all",
                    showAddModal === 'baki' ? "border-emerald-500 bg-emerald-50/30" : "border-rose-500 bg-rose-50/30"
                  )}>
                    <input
                      type="number"
                      placeholder="0.00"
                      autoFocus
                      required
                      className="w-full text-5xl font-black p-6 bg-transparent outline-none text-center text-slate-700 placeholder:text-slate-300"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between px-1">
                    <label className="text-sm font-bold text-slate-500">নোট (ঐচ্ছিক)</label>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">কুইক আইটেম</span>
                  </div>
                  
                  {/* Quick Items */}
                  <div className="flex flex-wrap gap-2 mb-2">
                    {(user?.quickItems || ['সিগারেট', 'চা পাতা', 'পান', 'বিস্কুট']).map((item: string, idx: number) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setNote(prev => prev ? `${prev}, ${item}` : item)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-bold border transition-all",
                          note.includes(item) 
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-100" 
                            : "bg-slate-50 text-slate-600 border-slate-100 hover:bg-slate-100"
                        )}
                      >
                        {item}
                      </button>
                    ))}
                  </div>

                  <input
                    type="text"
                    placeholder="কি বাবদ?"
                    className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold text-slate-600"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-5 rounded-2xl text-white font-black text-xl shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95",
                    showAddModal === 'baki' ? "bg-rose-500 shadow-rose-200" : "bg-emerald-500 shadow-emerald-200"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-7 h-7" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Customer Modal */}
      <AnimatePresence>
        {showEditModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEditModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">কাস্টমার প্রোফাইল এডিট</h3>
                <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleEditCustomer} className="space-y-4">
                <div className="flex flex-col items-center gap-4 mb-4">
                  <div className="relative group">
                    <div className="w-24 h-24 bg-slate-100 rounded-[2rem] flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300 group-hover:border-emerald-500 transition-all">
                      {editCustomer.profilePic ? (
                        <img src={editCustomer.profilePic} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-400 text-3xl font-bold bg-emerald-50 text-emerald-600">
                          {editCustomer.name[0]}
                        </div>
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">প্রোফাইল ছবি পরিবর্তন করুন</p>
                </div>

                <input
                  type="text"
                  placeholder="নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={editCustomer.name}
                  onChange={(e) => setEditCustomer({ ...editCustomer, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={editCustomer.phone}
                  onChange={(e) => setEditCustomer({ ...editCustomer, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={editCustomer.address}
                  onChange={(e) => setEditCustomer({ ...editCustomer, address: e.target.value })}
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'আপডেট করুন'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Transaction Modal */}
      <AnimatePresence>
        {showEditTransModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEditTransModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">লেনদেন এডিট করুন</h3>
                <button onClick={() => setShowEditTransModal(null)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleEditTransaction} className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <label className="text-sm font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="flex items-center gap-1.5 text-emerald-600 font-bold text-sm hover:opacity-80 transition-all"
                    >
                      <Calculator className="w-4 h-4" />
                      ক্যালকুলেটর
                    </button>
                  </div>
                  <input
                    type="number"
                    className="w-full text-4xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-3xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500 ml-1">নোট</label>
                  <input
                    type="text"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'আপডেট করুন'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Due Date Modal */}
      <AnimatePresence>
        {showDueDateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDueDateModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-slate-800">পরিশোধের লক্ষ্যমাত্রা</h3>
                <button onClick={() => setShowDueDateModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSetDueDate} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">তারিখ</label>
                  <input
                    type="date"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition-all font-medium"
                    value={editDueDate.date}
                    onChange={(e) => setEditDueDate({ ...editDueDate, date: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">লক্ষ্যমাত্রা (৳)</label>
                  <input
                    type="number"
                    placeholder="কত টাকা পেতে চান?"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition-all font-medium"
                    value={editDueDate.amount}
                    onChange={(e) => setEditDueDate({ ...editDueDate, amount: e.target.value })}
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditDueDate({ date: '', amount: '' });
                    }}
                    className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
                  >
                    মুছে ফেলুন
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-4 bg-rose-600 text-white rounded-2xl font-bold hover:bg-rose-700 shadow-lg shadow-rose-200 transition-all"
                  >
                    সেভ করুন
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
