import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  Tag,
  Edit2,
  Calculator,
  ShoppingBag,
  ShoppingCart,
  Home,
  Zap,
  Users,
  User,
  Truck,
  Wallet,
  CreditCard,
  Smartphone,
  Search,
  Filter,
  BarChart3,
  PieChart as PieChartIcon,
  ArrowRightLeft,
  ChevronDown,
  Download,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  getDocs
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { CashEntry, Savings } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const CATEGORIES = {
  income: [
    { name: 'বিক্রয়', icon: ShoppingBag, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { name: 'বেতন', icon: Wallet, color: 'text-blue-500', bg: 'bg-blue-50' },
    { name: 'বিনিয়োগ', icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-50' },
    { name: 'অন্যান্য', icon: Plus, color: 'text-slate-500', bg: 'bg-slate-50' },
  ],
  expense: [
    { name: 'মালামাল ক্রয়', icon: ShoppingCart, color: 'text-rose-500', bg: 'bg-rose-50' },
    { name: 'দোকান ভাড়া', icon: Home, color: 'text-orange-500', bg: 'bg-orange-50' },
    { name: 'বিদ্যুৎ বিল', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { name: 'বেতন প্রদান', icon: Users, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { name: 'পরিবহন', icon: Truck, color: 'text-cyan-500', bg: 'bg-cyan-50' },
    { name: 'অন্যান্য', icon: Minus, color: 'text-slate-500', bg: 'bg-slate-50' },
  ]
};

const PAYMENT_METHODS = [
  { name: 'Cash', icon: Wallet, label: 'ক্যাশ' },
  { name: 'Bank', icon: CreditCard, label: 'ব্যাংক' },
  { name: 'Mobile Banking', icon: Smartphone, label: 'মোবাইল ব্যাংকিং' },
  { name: 'Personal', icon: User, label: 'পার্সোনাল/অন্যান্য' },
];

export const CashFlow: React.FC = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<CashEntry[]>([]);
  const [savings, setSavings] = useState<Savings[]>([]);
  const [showAddModal, setShowAddModal] = useState<'income' | 'expense' | 'transfer' | 'savings' | null>(null);
  const [editingEntry, setEditingEntry] = useState<CashEntry | null>(null);
  const [loading, setLoading] = useState(false);
  const userCategories = {
    income: user?.incomeCategories || CATEGORIES.income.map(c => c.name),
    expense: user?.expenseCategories || CATEGORIES.expense.map(c => c.name)
  };

  const getCategoryIcon = (name: string, type: 'income' | 'expense') => {
    if (name === 'ট্রান্সফার') return { name, icon: ArrowRightLeft, color: 'text-blue-500', bg: 'bg-blue-50' };
    if (name === 'সঞ্চয়') return { name, icon: PiggyBank, color: 'text-pink-500', bg: 'bg-pink-50' };
    const category = CATEGORIES[type].find(c => c.name === name);
    if (category) return category;
    return { name, icon: type === 'income' ? Plus : Minus, color: 'text-slate-500', bg: 'bg-slate-50' };
  };
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Banking' | 'Personal'>('Cash');
  const [toPaymentMethod, setToPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Banking' | 'Personal'>('Bank');
  const [note, setNote] = useState('');
  const [showCalculator, setShowCalculator] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'entry' | 'all', id?: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');

  useEffect(() => {
    if (showAddModal && !editingEntry) {
      if (showAddModal === 'income') {
        setCategory(userCategories.income[0] || '');
      } else if (showAddModal === 'expense') {
        setCategory(userCategories.expense[0] || '');
      }
    }
  }, [showAddModal, editingEntry, userCategories.income, userCategories.expense]);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    const handleCloseCalc = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleCloseCalc);
    return () => window.removeEventListener('close-calculator', handleCloseCalc);
  }, []);

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const handleCalculatorSave = (total: number) => {
    setAmount(total.toString());
    closeCalculator();
  };

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'cashEntries'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'savings'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Savings)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));
    return () => unsubscribe();
  }, [user]);

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || (!category && showAddModal !== 'transfer' && showAddModal !== 'savings') || !user) return;

    setLoading(true);
    try {
      // Optimistic UI: Close modal and reset state immediately
      const currentModal = showAddModal;
      const currentAmount = amount;
      const currentCategory = category;
      const currentPaymentMethod = paymentMethod;
      const currentToPaymentMethod = toPaymentMethod;
      const currentNote = note;
      const currentEditingEntry = editingEntry;

      setShowAddModal(null);
      setEditingEntry(null);
      setAmount('');
      setCategory('');
      setPaymentMethod('Cash');
      setNote('');
      setLoading(false);

      if (currentModal === 'transfer') {
        // Internal Transfer: Add an expense to source and income to destination
        const batch = writeBatch(db);
        const date = new Date().toISOString();
        
        const sourceRef = doc(collection(db, 'cashEntries'));
        batch.set(sourceRef, {
          amount: Number(currentAmount),
          type: 'expense',
          category: 'ট্রান্সফার',
          paymentMethod: currentPaymentMethod,
          note: `ট্রান্সফার: ${PAYMENT_METHODS.find(p => p.name === currentToPaymentMethod)?.label} এ (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        const destRef = doc(collection(db, 'cashEntries'));
        batch.set(destRef, {
          amount: Number(currentAmount),
          type: 'income',
          category: 'ট্রান্সফার',
          paymentMethod: currentToPaymentMethod,
          note: `ট্রান্সফার: ${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} থেকে (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        toast.success('ট্রান্সফার সফল হয়েছে');
        await batch.commit();
      } else if (currentModal === 'savings') {
        // Savings: Add to savings collection AND add an expense to cashEntries
        const batch = writeBatch(db);
        const date = new Date().toISOString();

        const savingRef = doc(collection(db, 'savings'));
        batch.set(savingRef, {
          amount: Number(currentAmount),
          note: `সঞ্চয় (${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} থেকে): ${currentNote}`,
          date,
          ownerUid: user.uid
        });

        const cashRef = doc(collection(db, 'cashEntries'));
        batch.set(cashRef, {
          amount: Number(currentAmount),
          type: 'expense',
          category: 'সঞ্চয়',
          paymentMethod: currentPaymentMethod,
          note: `সঞ্চয় করা হয়েছে (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        toast.success('সঞ্চয় সফল হয়েছে');
        await batch.commit();
      } else if (currentEditingEntry) {
        toast.success('আপডেট করা হয়েছে');
        await updateDoc(doc(db, 'cashEntries', currentEditingEntry.id), {
          amount: Number(currentAmount),
          category: currentCategory,
          paymentMethod: currentPaymentMethod,
          note: currentNote,
        });
      } else {
        toast.success('এন্ট্রি যোগ করা হয়েছে');
        await addDoc(collection(db, 'cashEntries'), {
          amount: Number(currentAmount),
          type: currentModal,
          category: currentCategory,
          paymentMethod: currentPaymentMethod,
          note: currentNote,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });
      }
    } catch (error) {
      handleFirestoreError(error, editingEntry ? OperationType.UPDATE : OperationType.CREATE, editingEntry ? `cashEntries/${editingEntry.id}` : 'cashEntries');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAll = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAll = async () => {
    if (!user) return;
    
    // Optimistic UI
    setConfirmDelete(null);
    setLoading(false);
    toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে');

    try {
      const batch = writeBatch(db);
      
      // Delete cashEntries
      const qEntries = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
      const snapshotEntries = await getDocs(qEntries);
      snapshotEntries.docs.forEach(doc => batch.delete(doc.ref));

      // Delete savings
      const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
      const snapshotSavings = await getDocs(qSavings);
      snapshotSavings.docs.forEach(doc => batch.delete(doc.ref));

      await batch.commit();
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    }
  };

  const handleEdit = (entry: CashEntry) => {
    setEditingEntry(entry);
    setAmount(entry.amount.toString());
    setCategory(entry.category);
    setPaymentMethod(entry.paymentMethod || 'Cash');
    setNote(entry.note || '');
    setShowAddModal(entry.type);
  };

  const handleDelete = (id: string) => {
    setConfirmDelete({ type: 'entry', id });
  };

  const executeDeleteEntry = async () => {
    if (!confirmDelete || !confirmDelete.id) return;
    const entryId = confirmDelete.id;
    setConfirmDelete(null);
    try {
      await deleteDoc(doc(db, 'cashEntries', entryId));
      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const currentMonth = new Date().toISOString().slice(0, 7);
  const totalIncome = entries.filter(e => e.type === 'income' && e.category !== 'ট্রান্সফার').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = entries.filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়').reduce((acc, curr) => acc + curr.amount, 0);
  const monthlyExpense = entries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়' && e.date.startsWith(currentMonth))
    .reduce((acc, curr) => acc + curr.amount, 0);
  const totalSavings = savings.reduce((acc, curr) => acc + curr.amount, 0);

  const getWalletBalance = (method: 'Cash' | 'Bank' | 'Mobile Banking' | 'Personal') => {
    const income = entries.filter(e => e.type === 'income' && e.paymentMethod === method).reduce((acc, curr) => acc + curr.amount, 0);
    const expense = entries.filter(e => e.type === 'expense' && e.paymentMethod === method).reduce((acc, curr) => acc + curr.amount, 0);
    return income - expense;
  };

  const walletBalances = {
    Cash: getWalletBalance('Cash'),
    Bank: getWalletBalance('Bank'),
    'Mobile Banking': getWalletBalance('Mobile Banking'),
    Personal: getWalletBalance('Personal')
  };

  const totalCashBalance = walletBalances.Cash + walletBalances.Bank + walletBalances['Mobile Banking'] + walletBalances.Personal;

  const filteredEntries = entries.filter(e => {
    const matchesSearch = e.note?.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         e.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || e.type === filterType;
    return matchesSearch && matchesType;
  });

  const chartData = [
    { name: 'আয়', value: totalIncome },
    { name: 'ব্যয়', value: totalExpense }
  ];

  const incomeCategoryData = entries
    .filter(e => e.type === 'income' && e.category !== 'ট্রান্সফার')
    .reduce((acc: any[], curr) => {
      const existing = acc.find(a => a.name === curr.category);
      if (existing) {
        existing.value += curr.amount;
      } else {
        acc.push({ name: curr.category, value: curr.amount });
      }
      return acc;
    }, [])
    .sort((a, b) => b.value - a.value);

  const expenseCategoryData = entries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়')
    .reduce((acc: any[], curr) => {
      const existing = acc.find(a => a.name === curr.category);
      if (existing) {
        existing.value += curr.amount;
      } else {
        acc.push({ name: curr.category, value: curr.amount });
      }
      return acc;
    }, [])
    .sort((a, b) => b.value - a.value);

  const COLORS = ['#10b981', '#f43f5e', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#14b8a6'];

  const budgetProgress = user?.monthlyBudget ? (monthlyExpense / user.monthlyBudget) * 100 : 0;

  const downloadPDF = () => {
    if (!user) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Add Logo if exists
    if (user.shopLogo) {
      try {
        doc.addImage(user.shopLogo, 'PNG', 10, 10, 20, 20);
      } catch (e) {
        console.error('Error adding logo to PDF:', e);
      }
    }

    // App Name & Shop Name
    doc.setFontSize(20);
    doc.setTextColor(16, 185, 129); // Emerald-600
    doc.text(user.shopName || 'বাকি খাতা', user.shopLogo ? 35 : 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('ক্যাশ বুক রিপোর্ট', user.shopLogo ? 35 : 10, 28);

    // Summary Info
    doc.setDrawColor(240);
    doc.line(10, 35, pageWidth - 10, 35);
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`মোট ক্যাশ ব্যালেন্স: ${formatCurrency(totalCashBalance)}`, 10, 45);
    doc.text(`মোট সঞ্চয়: ${formatCurrency(totalSavings)}`, 10, 52);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`মোট আয়: ${formatCurrency(totalIncome)}`, pageWidth - 10, 45, { align: 'right' });
    doc.text(`মোট ব্যয়: ${formatCurrency(totalExpense)}`, pageWidth - 10, 52, { align: 'right' });

    // Transactions Table
    const tableData = filteredEntries.map(e => [
      formatDate(e.date),
      e.type === 'income' ? 'আয়' : 'ব্যয়',
      formatCurrency(e.amount),
      e.category,
      PAYMENT_METHODS.find(p => p.name === e.paymentMethod)?.label || e.paymentMethod,
      e.note || '-'
    ]);

    autoTable(doc, {
      startY: 65,
      head: [['তারিখ', 'ধরন', 'পরিমাণ', 'ক্যাটাগরি', 'পেমেন্ট', 'নোট']],
      body: tableData,
      headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 253, 250] },
      styles: { font: 'helvetica', fontSize: 8 },
      margin: { top: 65 }
    });

    doc.save(`cash_book_report_${new Date().toISOString().split('T')[0]}.pdf`);
    toast.success('PDF ডাউনলোড হচ্ছে...');
  };

  const getPaymentIcon = (method: string) => {
    const pm = PAYMENT_METHODS.find(p => p.name === method);
    return pm ? pm.icon : Wallet;
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-bold text-slate-800">ক্যাশ হিসাব</h2>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 sm:p-8 text-slate-800 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40"
        >
          {/* iPhone Style Glassmorphism Background Elements */}
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-gradient-to-br from-emerald-400/20 to-teal-400/20 rounded-full blur-[60px]" />
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-gradient-to-tr from-blue-400/20 to-indigo-400/20 rounded-full blur-[60px]" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
              <p className="text-slate-600 text-xs font-black uppercase tracking-[0.1em]">মোট ক্যাশ ব্যালেন্স</p>
            </div>
            <h3 className="text-4xl font-black tracking-tight text-slate-800">{formatCurrency(totalCashBalance)}</h3>
            
            <div className="grid grid-cols-2 gap-3 mt-6 pt-6 border-t border-slate-200/50">
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <Wallet className="w-3.5 h-3.5 text-emerald-600 group-hover:text-emerald-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">ক্যাশ</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances.Cash)}</p>
              </div>
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-3.5 h-3.5 text-blue-600 group-hover:text-blue-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">ব্যাংক</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances.Bank)}</p>
              </div>
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <Smartphone className="w-3.5 h-3.5 text-purple-600 group-hover:text-purple-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">মোবাইল</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances['Mobile Banking'])}</p>
              </div>
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <User className="w-3.5 h-3.5 text-amber-600 group-hover:text-amber-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">পার্সোনাল</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances.Personal)}</p>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 gap-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40 flex items-center justify-between group"
          >
            <div className="absolute -right-8 -top-8 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl" />
            <div className="relative z-10">
              <p className="text-slate-600 text-xs font-black uppercase tracking-wider mb-1">মোট আয়</p>
              <h4 className="text-2xl font-black text-emerald-700">{formatCurrency(totalIncome)}</h4>
            </div>
            <div className="relative z-10 w-10 h-10 bg-emerald-500/10 text-emerald-600 rounded-xl flex items-center justify-center backdrop-blur-md border border-emerald-500/20 group-hover:scale-110 transition-transform">
              <ArrowUpRight className="w-6 h-6" />
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40 flex items-center justify-between group"
          >
            <div className="absolute -right-8 -top-8 w-24 h-24 bg-rose-500/5 rounded-full blur-xl" />
            <div className="relative z-10">
              <p className="text-slate-600 text-xs font-black uppercase tracking-wider mb-1">মোট ব্যয়</p>
              <h4 className="text-2xl font-black text-rose-600">{formatCurrency(totalExpense)}</h4>
            </div>
            <div className="relative z-10 w-10 h-10 bg-rose-500/10 text-rose-600 rounded-xl flex items-center justify-center backdrop-blur-md border border-rose-500/20 group-hover:scale-110 transition-transform">
              <ArrowDownRight className="w-6 h-6" />
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40 flex items-center justify-between group"
        >
          {/* Subtle background glow for savings */}
          <div className="absolute -right-16 -top-16 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl" />
          
          <div className="relative z-10 space-y-1">
            <p className="text-slate-600 text-xs font-black uppercase tracking-wider">মোট সঞ্চয়</p>
            <h4 className="text-3xl font-black text-indigo-700 tracking-tight">{formatCurrency(totalSavings)}</h4>
          </div>
          <div className="relative z-10 w-14 h-14 bg-indigo-500/10 text-indigo-600 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 backdrop-blur-md border border-indigo-500/20">
            <PiggyBank className="w-8 h-8" />
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <button 
          onClick={() => setShowAddModal('income')}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Plus className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-xs uppercase tracking-widest font-black">আয়</span>
        </button>

        <button 
          onClick={() => setShowAddModal('expense')}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Minus className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-xs uppercase tracking-widest font-black">ব্যয়</span>
        </button>

        <button 
          onClick={() => setShowAddModal('transfer')}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <ArrowRightLeft className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-xs uppercase tracking-widest font-black">ট্রান্সফার</span>
        </button>

        <button 
          onClick={() => setShowAddModal('savings')}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <PiggyBank className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-xs uppercase tracking-widest font-black">সঞ্চয়</span>
        </button>
      </div>

          {/* Search & Filter */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  placeholder="লেনদেন খুঁজুন..."
                  className="w-full pl-11 pr-4 py-3 bg-white border border-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button 
                onClick={downloadPDF}
                className="p-3 bg-white border border-slate-100 rounded-xl text-slate-600 hover:text-emerald-600 transition-all"
                title="PDF ডাউনলোড"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
              <button 
                onClick={() => setFilterType('all')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'all' ? "bg-slate-800 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                সব
              </button>
              <button 
                onClick={() => setFilterType('income')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'income' ? "bg-emerald-600 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                আয়
              </button>
              <button 
                onClick={() => setFilterType('expense')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'expense' ? "bg-rose-500 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                ব্যয়
              </button>
            </div>
          </div>

          {/* History List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
              {entries.length > 0 && (
                <button 
                  onClick={handleDeleteAll}
                  className="text-rose-500 text-xs font-bold flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  সব মুছুন
                </button>
              )}
            </div>
            {filteredEntries.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
                <p className="text-slate-400">কোন লেনদেন পাওয়া যায়নি</p>
              </div>
            ) : (
              filteredEntries.map((entry) => {
                const catInfo = getCategoryIcon(entry.category, entry.type);
                const Icon = catInfo.icon;
                const PMIcon = getPaymentIcon(entry.paymentMethod);
                return (
                  <div key={entry.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110",
                        entry.type === 'income' ? "bg-emerald-50 text-emerald-500" : "bg-rose-50 text-rose-500"
                      )}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-black text-slate-800 text-lg">{formatCurrency(entry.amount)}</h5>
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-[10px] rounded-md font-black uppercase tracking-wider border border-slate-200">
                            {entry.category}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-600 font-black mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                            {formatDate(entry.date)}
                          </span>
                          <span className="flex items-center gap-1 text-slate-700">
                            <PMIcon className="w-3.5 h-3.5 text-blue-600" />
                            {PAYMENT_METHODS.find(p => p.name === entry.paymentMethod)?.label || 'ক্যাশ'}
                          </span>
                        </div>
                        {entry.note && (
                          <p className="text-xs text-slate-500 mt-1.5 font-medium italic flex items-center gap-1.5">
                            <FileText className="w-3.5 h-3.5 text-slate-400" /> {entry.note}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-100 transition-all">
                      <button 
                        onClick={() => handleEdit(entry)}
                        className="p-2 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 rounded-lg transition-all"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(entry.id)}
                        className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

      {/* Add Modal */}
      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'entry'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteEntry}
        title="এন্ট্রি মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই এন্ট্রিটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAll}
        title="সব ইতিহাস মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল ইতিহাস মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।"
      />

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-6 sm:p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingEntry ? 'এন্ট্রি এডিট করুন' : (
                    showAddModal === 'income' ? 'আয় যোগ করুন' : 
                    showAddModal === 'expense' ? 'খরচ যোগ করুন' : 
                    showAddModal === 'transfer' ? 'ইন্টারনাল ট্রান্সফার' : 'সঞ্চয় করুন'
                  )}
                </h3>
                <button onClick={() => {
                  setShowAddModal(null);
                  setEditingEntry(null);
                  setAmount('');
                  setCategory('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddEntry} className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-xs font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="text-emerald-600 hover:text-emerald-700 p-1 rounded-lg hover:bg-emerald-50 transition-all"
                    >
                      <Calculator className="w-4 h-4" />
                    </button>
                  </div>
                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                {showAddModal === 'transfer' || showAddModal === 'savings' ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1">কোথা থেকে</label>
                        <select 
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                          value={paymentMethod}
                          onChange={(e) => setPaymentMethod(e.target.value as any)}
                        >
                          {PAYMENT_METHODS.map(pm => (
                            <option key={pm.name} value={pm.name}>{pm.label}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1">কোথায়</label>
                        <select 
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                          disabled={showAddModal === 'savings'}
                          value={showAddModal === 'savings' ? 'Savings' : toPaymentMethod}
                          onChange={(e) => setToPaymentMethod(e.target.value as any)}
                        >
                          {showAddModal === 'savings' ? (
                            <option value="Savings">সঞ্চয় ফান্ড</option>
                          ) : (
                            PAYMENT_METHODS.map(pm => (
                              <option key={pm.name} value={pm.name}>{pm.label}</option>
                            ))
                          )}
                        </select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1">ক্যাটাগরি</label>
                      <div className="grid grid-cols-4 gap-2 max-h-40 overflow-y-auto p-1 no-scrollbar">
                        {(showAddModal === 'income' ? userCategories.income : userCategories.expense).map((catName) => {
                          const predefined = CATEGORIES[showAddModal as 'income' | 'expense']?.find(c => c.name === catName);
                          const CategoryIcon = predefined?.icon || (showAddModal === 'income' ? TrendingUp : TrendingDown);
                          const color = predefined?.color || (showAddModal === 'income' ? 'text-emerald-500' : 'text-rose-500');
                          const bg = predefined?.bg || (showAddModal === 'income' ? 'bg-emerald-50' : 'bg-rose-50');
                          
                          return (
                            <button
                              key={catName}
                              type="button"
                              onClick={() => setCategory(catName)}
                              className={cn(
                                "flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all",
                                category === catName 
                                  ? "border-emerald-500 bg-emerald-50" 
                                  : "border-transparent bg-slate-50 hover:bg-slate-100"
                              )}
                            >
                              <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", bg, color)}>
                                <CategoryIcon className="w-5 h-5" />
                              </div>
                              <span className="text-[8px] font-bold text-slate-600 truncate w-full text-center">{catName}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1">পেমেন্ট মেথড</label>
                      <div className="grid grid-cols-2 gap-2">
                        {PAYMENT_METHODS.map((pm) => (
                          <button
                            key={pm.name}
                            type="button"
                            onClick={() => setPaymentMethod(pm.name as any)}
                            className={cn(
                              "flex items-center gap-2 p-3 rounded-xl border-2 transition-all",
                              paymentMethod === pm.name 
                                ? "border-emerald-500 bg-emerald-50" 
                                : "border-transparent bg-slate-50 hover:bg-slate-100"
                            )}
                          >
                            <pm.icon className={cn("w-4 h-4", paymentMethod === pm.name ? "text-emerald-500" : "text-slate-400")} />
                            <span className="text-[10px] font-bold text-slate-600">{pm.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">নোট (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    placeholder="বিস্তারিত লিখুন"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-4 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95",
                    showAddModal === 'income' ? "bg-emerald-600 shadow-emerald-100" : 
                    showAddModal === 'expense' ? "bg-rose-500 shadow-rose-100" :
                    showAddModal === 'transfer' ? "bg-slate-800 shadow-slate-100" : "bg-indigo-600 shadow-indigo-100"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
