import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  Tag,
  Edit2,
  Calculator,
  ShoppingBag,
  ShoppingCart,
  Home,
  Zap,
  Users,
  User,
  Truck,
  Wallet,
  CreditCard,
  Smartphone,
  Search,
  Filter,
  BarChart3,
  PieChart as PieChartIcon,
  ArrowRightLeft,
  ChevronDown,
  Download,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight,
  ArrowLeft
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  getDocs,
  increment
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { CashEntry, Savings } from '../types';
import { formatCurrency, formatDate, cn, parseNumber } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const CATEGORIES = {
  income: [
    { name: 'বিক্রয়', icon: ShoppingBag, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { name: 'বেতন', icon: Wallet, color: 'text-blue-500', bg: 'bg-blue-50' },
    { name: 'বিনিয়োগ', icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-50' },
    { name: 'অন্যান্য', icon: Plus, color: 'text-slate-500', bg: 'bg-slate-50' },
  ],
  expense: [
    { name: 'মালামাল ক্রয়', icon: ShoppingCart, color: 'text-rose-500', bg: 'bg-rose-50' },
    { name: 'দোকান ভাড়া', icon: Home, color: 'text-orange-500', bg: 'bg-orange-50' },
    { name: 'বিদ্যুৎ বিল', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { name: 'বেতন প্রদান', icon: Users, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { name: 'পরিবহন', icon: Truck, color: 'text-cyan-500', bg: 'bg-cyan-50' },
    { name: 'অন্যান্য', icon: Minus, color: 'text-slate-500', bg: 'bg-slate-50' },
  ]
};

const PAYMENT_METHODS = [
  { name: 'Cash', icon: Wallet, label: 'ক্যাশ' },
  { name: 'Bank', icon: CreditCard, label: 'ব্যাংক' },
  { name: 'Mobile Banking', icon: Smartphone, label: 'মোবাইল ব্যাংকিং' },
  { name: 'Personal', icon: User, label: 'পার্সোনাল/অন্যান্য' },
];

export const CashFlow: React.FC = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<CashEntry[]>([]);
  const [savings, setSavings] = useState<Savings[]>([]);
  const [showAddModal, setShowAddModal] = useState<'income' | 'expense' | 'transfer' | 'savings' | null>(null);
  const [showCashInputModal, setShowCashInputModal] = useState(false);
  const [actualCash, setActualCash] = useState('');
  const [savingsDirection, setSavingsDirection] = useState<'deposit' | 'withdraw'>('deposit');
  const [editingEntry, setEditingEntry] = useState<CashEntry | null>(null);
  const [loading, setLoading] = useState(false);
  const userCategories = {
    income: user?.incomeCategories || CATEGORIES.income.map(c => c.name),
    expense: user?.expenseCategories || CATEGORIES.expense.map(c => c.name)
  };

  const getCategoryIcon = (name: string, type: 'income' | 'expense') => {
    if (name === 'ট্রান্সফার') return { name, icon: ArrowRightLeft, color: 'text-blue-500', bg: 'bg-blue-50' };
    if (name === 'সঞ্চয়') return { name, icon: PiggyBank, color: 'text-pink-500', bg: 'bg-pink-50' };
    const category = CATEGORIES[type].find(c => c.name === name);
    if (category) return category;
    return { name, icon: type === 'income' ? Plus : Minus, color: 'text-slate-500', bg: 'bg-slate-50' };
  };
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Banking' | 'Personal'>('Cash');
  const [toPaymentMethod, setToPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Banking' | 'Personal'>('Bank');
  const [note, setNote] = useState('');
  const [showCalculator, setShowCalculator] = useState(false);
  const [showSavingsHistory, setShowSavingsHistory] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'entry' | 'all', id?: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [isEditingCategory, setIsEditingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [isEditingQuickItems, setIsEditingQuickItems] = useState(false);
  const [newQuickItemName, setNewQuickItemName] = useState('');
  
  const handleUpdateCategories = async (newCategories: string[], type: 'income' | 'expense') => {
    if (!user?.uid) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        [type === 'income' ? 'incomeCategories' : 'expenseCategories']: newCategories
      });
    } catch (error) {
      toast.error('ক্যাটাগরি আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handleUpdateQuickItems = async (newItems: string[]) => {
    if (!user?.uid) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        quickItemsCash: newItems
      });
    } catch (error) {
      toast.error('কুইক আইটেম আপডেট করতে সমস্যা হয়েছে');
    }
  };
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goalAmount, setGoalAmount] = useState('');
  const [goalDate, setGoalDate] = useState('');
  const [visibleTxs, setVisibleTxs] = useState(50);

  useEffect(() => {
    if (showAddModal && !editingEntry) {
      if (showAddModal === 'income') {
        setCategory(userCategories.income[0] || '');
      } else if (showAddModal === 'expense') {
        setCategory(userCategories.expense[0] || '');
      }
    }
  }, [showAddModal, editingEntry, userCategories.income, userCategories.expense]);

  useEffect(() => {
    if (showGoalModal && user?.savingsGoal) {
      setGoalAmount(user.savingsGoal.toString());
      setGoalDate(user.savingsGoalDate || '');
    }
  }, [showGoalModal, user]);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    const handleCloseCalc = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleCloseCalc);
    return () => window.removeEventListener('close-calculator', handleCloseCalc);
  }, []);

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const handleCalculatorSave = (total: number, calcNote?: string) => {
    setAmount(total.toString());
    if (calcNote) {
      setNote(prev => prev ? `${prev}, ${calcNote}` : calcNote);
    }
    closeCalculator();
  };

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'cashEntries'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'savings'),
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Savings)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));
    return () => unsubscribe();
  }, [user]);

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || (!category && showAddModal !== 'transfer' && showAddModal !== 'savings') || !user) return;

    setLoading(true);
    try {
      // Optimistic UI: Close modal and reset state immediately
      const currentModal = showAddModal;
      const currentAmount = amount;
      const currentCategory = category;
      const currentPaymentMethod = paymentMethod;
      const currentToPaymentMethod = toPaymentMethod;
      const currentNote = note;
      const currentEditingEntry = editingEntry;

      setShowAddModal(null);
      setEditingEntry(null);
      setAmount('');
      setCategory('');
      setPaymentMethod('Cash');
      setNote('');
      setLoading(false);

      if (currentModal === 'transfer') {
        // Internal Transfer: Add an expense to source and income to destination
        const batch = writeBatch(db);
        const date = new Date().toISOString();
        
        const sourceRef = doc(collection(db, 'cashEntries'));
        batch.set(sourceRef, {
          amount: parseNumber(currentAmount),
          type: 'expense',
          category: 'ট্রান্সফার',
          paymentMethod: currentPaymentMethod,
          note: `ট্রান্সফার: ${PAYMENT_METHODS.find(p => p.name === currentToPaymentMethod)?.label} এ (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        const destRef = doc(collection(db, 'cashEntries'));
        batch.set(destRef, {
          amount: parseNumber(currentAmount),
          type: 'income',
          category: 'ট্রান্সফার',
          paymentMethod: currentToPaymentMethod,
          note: `ট্রান্সফার: ${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} থেকে (${currentNote})`,
          date,
          ownerUid: user.uid
        });

        toast.success('ট্রান্সফার সফল হয়েছে');
        await batch.commit();
      } else if (currentModal === 'savings') {
        const batch = writeBatch(db);
        const date = new Date().toISOString();

        if (savingsDirection === 'deposit') {
          // Savings Deposit: Add to savings and deduct from cashEntries as expense
          const savingRef = doc(collection(db, 'savings'));
          batch.set(savingRef, {
            amount: parseNumber(currentAmount),
            note: `সঞ্চয় (${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} থেকে): ${currentNote}`,
            date,
            ownerUid: user.uid
          });

          const cashRef = doc(collection(db, 'cashEntries'));
          batch.set(cashRef, {
            amount: parseNumber(currentAmount),
            type: 'expense',
            category: 'সঞ্চয়',
            paymentMethod: currentPaymentMethod,
            note: `সঞ্চয় হিসেবে জমা (${currentNote})`,
            date,
            ownerUid: user.uid
          });
          toast.success('সঞ্চয় জমা সফল হয়েছে');
        } else {
          // Savings Withdrawal: Subtract from savings and add to cashEntries as income
          const savingRef = doc(collection(db, 'savings'));
          batch.set(savingRef, {
            amount: -parseNumber(currentAmount),
            note: `উত্তোলন (${PAYMENT_METHODS.find(p => p.name === currentPaymentMethod)?.label} এ): ${currentNote}`,
            date,
            ownerUid: user.uid
          });

          const cashRef = doc(collection(db, 'cashEntries'));
          batch.set(cashRef, {
            amount: parseNumber(currentAmount),
            type: 'income',
            category: 'সঞ্চয়',
            paymentMethod: currentPaymentMethod,
            note: `সঞ্চয় থেকে উত্তোলন (${currentNote})`,
            date,
            ownerUid: user.uid
          });
          toast.success('সঞ্চয় উত্তোলন সফল হয়েছে');
        }
        await batch.commit();
      } else if (currentEditingEntry) {
        const batch = writeBatch(db);
        batch.update(doc(db, 'cashEntries', currentEditingEntry.id), {
          amount: parseNumber(currentAmount),
          category: currentCategory,
          paymentMethod: currentPaymentMethod,
          note: currentNote,
        });

        if (currentEditingEntry.category === 'সঞ্চয়') {
          const q = query(collection(db, 'savings'), where('ownerUid', '==', user.uid), where('date', '==', currentEditingEntry.date));
          const snapshot = await getDocs(q);
          snapshot.docs.forEach(doc => {
            batch.update(doc.ref, {
              amount: parseNumber(currentAmount),
              note: currentNote
            });
          });
        } else if (currentEditingEntry.category === 'ট্রান্সফার') {
          const q = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid), where('date', '==', currentEditingEntry.date));
          const snapshot = await getDocs(q);
          snapshot.docs.forEach(doc => {
            if (doc.id !== currentEditingEntry.id) {
              batch.update(doc.ref, {
                amount: parseNumber(currentAmount)
              });
            }
          });
        }

        // Adjust linked inventory stats if amount changed
        if (currentEditingEntry.linkedItemId) {
          const amountDiff = parseNumber(currentAmount) - currentEditingEntry.amount;
          if (amountDiff !== 0) {
            batch.update(doc(db, 'inventory', currentEditingEntry.linkedItemId), {
              totalSoldAmount: increment(amountDiff),
              totalProfitEarned: increment(amountDiff)
            });
          }
        }

        await batch.commit();
        toast.success('আপডেট করা হয়েছে');
      } else {
        toast.success('এন্ট্রি যোগ করা হয়েছে');
        await addDoc(collection(db, 'cashEntries'), {
          amount: parseNumber(currentAmount),
          type: currentModal,
          category: currentCategory,
          paymentMethod: currentPaymentMethod,
          note: currentNote,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });
      }
    } catch (error) {
      handleFirestoreError(error, editingEntry ? OperationType.UPDATE : OperationType.CREATE, editingEntry ? `cashEntries/${editingEntry.id}` : 'cashEntries');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAll = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAll = async () => {
    if (!user) return;
    
    setConfirmDelete(null);
    setLoading(true);
    toast.loading('ইতিহাস মোছা হচ্ছে...', { id: 'deleteAll' });

    try {
      // Fetch cash entries
      const qEntries = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
      const snapshotEntries = await getDocs(qEntries);
      
      // Update inventory items safely in parallel (ignore if missing)
      for (let docSnap of snapshotEntries.docs) {
        const entryData = docSnap.data() as CashEntry;
        if (entryData.linkedItemId) {
          try {
            await updateDoc(doc(db, 'inventory', entryData.linkedItemId), {
              stockQuantity: increment(entryData.linkedStockRemoved || 0),
              totalSoldQty: increment(-(entryData.linkedStockRemoved || 0)),
              totalSoldAmount: increment(-entryData.amount),
              totalProfitEarned: increment(-(entryData.linkedProfitEarned || 0)),
            });
          } catch (e) {
            // Ignore if inventory item was deleted
          }
        }
      }

      // Delete cash entries in batches to prevent rate limits
      let batch = writeBatch(db);
      let count = 0;
      for (let docSnap of snapshotEntries.docs) {
        batch.delete(docSnap.ref);
        count++;
        if (count % 400 === 0) {
          await batch.commit();
          batch = writeBatch(db);
        }
      }
      if (count % 400 !== 0) {
        await batch.commit();
      }

      // Fetch and delete savings
      const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
      const snapshotSavings = await getDocs(qSavings);
      
      batch = writeBatch(db);
      count = 0;
      for (let docSnap of snapshotSavings.docs) {
        batch.delete(docSnap.ref);
        count++;
        if (count % 400 === 0) {
          await batch.commit();
          batch = writeBatch(db);
        }
      }
      if (count % 400 !== 0) {
        await batch.commit();
      }
      
      toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে', { id: 'deleteAll' });
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে', { id: 'deleteAll' });
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (entry: CashEntry) => {
    setEditingEntry(entry);
    setAmount(entry.amount.toString());
    setCategory(entry.category);
    setPaymentMethod(entry.paymentMethod || 'Cash');
    setNote(entry.note || '');
    setShowAddModal(entry.type);
  };

  const handleSaveGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    let numAmount = parseNumber(goalAmount);
    if (isNaN(numAmount) || numAmount < 0) {
      toast.error('সঠিক পরিমাণ লিখুন');
      return;
    }

    // Set to null if 0 (clearing the goal)
    const finalAmount = numAmount > 0 ? numAmount : null;
    const finalDate = numAmount > 0 && goalDate ? goalDate : null;

    try {
      await updateDoc(doc(db, 'users', user.uid), {
        savingsGoal: finalAmount,
        savingsGoalDate: finalDate
      });
      setShowGoalModal(false);
      setGoalAmount('');
      setGoalDate('');
      toast.success(finalAmount ? 'লক্ষ্যমাত্রা সেট করা হয়েছে' : 'লক্ষ্যমাত্রা মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('লক্ষ্যমাত্রা আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handleDelete = (id: string) => {
    setConfirmDelete({ type: 'entry', id });
  };

  const executeDeleteEntry = async () => {
    if (!confirmDelete || !confirmDelete.id || !user) return;
    const entryId = confirmDelete.id;
    const entryToDelete = entries.find(e => e.id === entryId);
    setConfirmDelete(null);
    try {
      await deleteDoc(doc(db, 'cashEntries', entryId));

      if (entryToDelete) {
        if (entryToDelete.category === 'সঞ্চয়') {
          const q = query(collection(db, 'savings'), where('ownerUid', '==', user.uid), where('date', '==', entryToDelete.date));
          const snapshot = await getDocs(q);
          const deletes = snapshot.docs.map(doc => deleteDoc(doc.ref));
          await Promise.allSettled(deletes);
        } else if (entryToDelete.category === 'ট্রান্সফার') {
          const q = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid), where('date', '==', entryToDelete.date));
          const snapshot = await getDocs(q);
          const deletes = snapshot.docs.map(doc => deleteDoc(doc.ref));
          await Promise.allSettled(deletes);
        }

        // Revert linked inventory if applicable
        if (entryToDelete.linkedItemId) {
          try {
            await updateDoc(doc(db, 'inventory', entryToDelete.linkedItemId), {
              stockQuantity: increment(entryToDelete.linkedStockRemoved || 0),
              totalSoldQty: increment(-(entryToDelete.linkedStockRemoved || 0)),
              totalSoldAmount: increment(-entryToDelete.amount),
              totalProfitEarned: increment(-(entryToDelete.linkedProfitEarned || 0)),
            });
          } catch(e) {
            // Ignore if inventory item was already deleted
          }
        }
      }

      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
      console.error(error);
    }
  };

  const currentMonth = new Date().toISOString().slice(0, 7);
  const totalIncome = entries.filter(e => e.type === 'income' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = entries.filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়').reduce((acc, curr) => acc + curr.amount, 0);
  const monthlyExpense = entries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়' && e.date.startsWith(currentMonth))
    .reduce((acc, curr) => acc + curr.amount, 0);
  const totalSavings = savings.reduce((acc, curr) => acc + curr.amount, 0);

  const getWalletBalance = (method: 'Cash' | 'Bank' | 'Mobile Banking' | 'Personal') => {
    const income = entries.filter(e => e.type === 'income' && e.paymentMethod === method).reduce((acc, curr) => acc + curr.amount, 0);
    const expense = entries.filter(e => e.type === 'expense' && e.paymentMethod === method).reduce((acc, curr) => acc + curr.amount, 0);
    return income - expense;
  };

  const walletBalances = {
    Cash: getWalletBalance('Cash'),
    Bank: getWalletBalance('Bank'),
    'Mobile Banking': getWalletBalance('Mobile Banking'),
    Personal: getWalletBalance('Personal')
  };

  // Exclude Personal cash from total business balance
  const totalCashBalance = walletBalances.Cash + walletBalances.Bank + walletBalances['Mobile Banking'];

  const filteredEntries = entries.filter(e => {
    const matchesSearch = e.note?.toLowerCase()?.includes(searchQuery.toLowerCase()) || 
                         e.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || e.type === filterType;
    return matchesSearch && matchesType;
  });

  const chartData = [
    { name: 'আয়', value: totalIncome },
    { name: 'ব্যয়', value: totalExpense }
  ];

  const incomeCategoryData = entries
    .filter(e => e.type === 'income' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়')
    .reduce((acc: any[], curr) => {
      const existing = acc.find(a => a.name === curr.category);
      if (existing) {
        existing.value += curr.amount;
      } else {
        acc.push({ name: curr.category, value: curr.amount });
      }
      return acc;
    }, [])
    .sort((a, b) => b.value - a.value);

  const expenseCategoryData = entries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়')
    .reduce((acc: any[], curr) => {
      const existing = acc.find(a => a.name === curr.category);
      if (existing) {
        existing.value += curr.amount;
      } else {
        acc.push({ name: curr.category, value: curr.amount });
      }
      return acc;
    }, [])
    .sort((a, b) => b.value - a.value);

  const COLORS = ['#10b981', '#f43f5e', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#14b8a6'];

  const budgetProgress = user?.monthlyBudget ? (monthlyExpense / user.monthlyBudget) * 100 : 0;

  const downloadPDF = () => {
    if (!user) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Add Logo if exists
    if (user.shopLogo) {
      try {
        doc.addImage(user.shopLogo, 'PNG', 10, 10, 20, 20);
      } catch (e) {
        console.error('Error adding logo to PDF:', e);
      }
    }

    // App Name & Shop Name
    doc.setFontSize(20);
    doc.setTextColor(16, 185, 129); // Emerald-600
    doc.text(user.shopName || 'বাকি খাতা', user.shopLogo ? 35 : 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('ক্যাশ বুক রিপোর্ট', user.shopLogo ? 35 : 10, 28);

    // Summary Info
    doc.setDrawColor(240);
    doc.line(10, 35, pageWidth - 10, 35);
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`মোট ব্যালেন্স: ${formatCurrency(totalCashBalance)}`, 10, 45);
    doc.text(`মোট সঞ্চয়: ${formatCurrency(totalSavings)}`, 10, 52);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`মোট আয়: ${formatCurrency(totalIncome)}`, pageWidth - 10, 45, { align: 'right' });
    doc.text(`মোট ব্যয়: ${formatCurrency(totalExpense)}`, pageWidth - 10, 52, { align: 'right' });

    // Transactions Table
    const tableData = filteredEntries.map(e => [
      formatDate(e.date),
      e.type === 'income' ? 'আয়' : 'ব্যয়',
      formatCurrency(e.amount),
      e.category,
      PAYMENT_METHODS.find(p => p.name === e.paymentMethod)?.label || e.paymentMethod,
      e.note || '-'
    ]);

    autoTable(doc, {
      startY: 65,
      head: [['তারিখ', 'ধরন', 'পরিমাণ', 'ক্যাটাগরি', 'পেমেন্ট', 'নোট']],
      body: tableData,
      headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 253, 250] },
      styles: { font: 'helvetica', fontSize: 8 },
      margin: { top: 65 }
    });

    doc.save(`cash_book_report_${new Date().toISOString().split('T')[0]}.pdf`);
    toast.success('PDF ডাউনলোড হচ্ছে...');
  };

  const getPaymentIcon = (method: string) => {
    const pm = PAYMENT_METHODS.find(p => p.name === method);
    return pm ? pm.icon : Wallet;
  };

  if (showSavingsHistory) {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-3 px-1 sticky top-0 bg-slate-50 z-10 pt-4 pb-2 border-b border-slate-200/50">
          <button onClick={() => setShowSavingsHistory(false)} className="p-2 -ml-2 hover:bg-white rounded-xl transition-all">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <PiggyBank className="w-6 h-6 text-indigo-600" />
              সঞ্চয়ের হিস্টোরি
            </h2>
            <p className="text-xs text-slate-500 font-bold mt-0.5">সর্বমোট সঞ্চয়: {formatCurrency(totalSavings)}</p>
          </div>
        </div>

        <div className="space-y-3 px-1">
          {savings.length === 0 ? (
            <div className="text-center py-20 text-slate-500 font-bold flex flex-col items-center gap-3">
              <PiggyBank className="w-16 h-16 text-slate-300" />
              <p>কোনো সঞ্চয় পাওয়া যায়নি</p>
            </div>
          ) : (
            savings.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(entry => (
              <div key={entry.id} className="bg-white rounded-2xl p-4 flex items-center justify-between gap-4 shadow-sm border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
                    <PiggyBank className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-800 text-lg">{formatCurrency(entry.amount)}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {formatDate(entry.date)}
                      </span>
                    </div>
                    {entry.note && (
                      <p className="text-sm text-slate-600 font-medium mt-1">{entry.note}</p>
                    )}
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button 
                    onClick={() => handleDelete(entry.id)}
                    className="p-2.5 rounded-xl hover:bg-rose-50 text-slate-400 hover:text-rose-500 transition-colors bg-slate-50"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-bold text-slate-800">ক্যাশ হিসাব</h2>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 sm:p-8 text-slate-800 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40"
        >
          {/* iPhone Style Glassmorphism Background Elements */}
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-gradient-to-br from-emerald-400/20 to-teal-400/20 rounded-full blur-[60px]" />
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-gradient-to-tr from-blue-400/20 to-indigo-400/20 rounded-full blur-[60px]" />
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                <p className="text-slate-600 text-xs font-black uppercase tracking-[0.1em]">মোট ব্যালেন্স (Cash + Bank)</p>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setShowCalculator(true);
                }}
                className="p-2 bg-white/40 hover:bg-white/60 rounded-xl transition-all backdrop-blur-md border border-white/40 group shadow-sm"
                title="ক্যালকুলেটর"
              >
                <Calculator className="w-5 h-5 text-slate-600 transition-colors" />
              </button>
            </div>
            <h3 className="text-4xl font-black tracking-tight text-slate-800">{formatCurrency(totalCashBalance)}</h3>
            
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mt-6 pt-6 border-t border-slate-200/50">
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <Wallet className="w-3.5 h-3.5 text-emerald-600 group-hover:text-emerald-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">ক্যাশ</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances.Cash)}</p>
              </div>
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-3.5 h-3.5 text-blue-600 group-hover:text-blue-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">ব্যাংক</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances.Bank)}</p>
              </div>
              <div className="bg-white/50 p-4 rounded-[1.5rem] border border-white/60 backdrop-blur-md shadow-sm hover:bg-white/70 transition-all group">
                <div className="flex items-center gap-2 mb-1">
                  <Smartphone className="w-3.5 h-3.5 text-purple-600 group-hover:text-purple-700 transition-colors" />
                  <p className="text-[10px] text-slate-600 font-black uppercase tracking-wider">মোবাইল</p>
                </div>
                <p className="text-base font-black text-slate-800">{formatCurrency(walletBalances['Mobile Banking'])}</p>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 gap-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40 flex items-center justify-between group"
          >
            <div className="absolute -right-8 -top-8 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl" />
            <div className="relative z-10">
              <p className="text-slate-600 text-xs font-black uppercase tracking-wider mb-1">মোট আয়</p>
              <h4 className="text-2xl font-black text-emerald-700">{formatCurrency(totalIncome)}</h4>
            </div>
            <div className="relative z-10 w-10 h-10 bg-emerald-500/10 text-emerald-600 rounded-xl flex items-center justify-center backdrop-blur-md border border-emerald-500/20 group-hover:scale-110 transition-transform">
              <ArrowUpRight className="w-6 h-6" />
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40 flex items-center justify-between group"
          >
            <div className="absolute -right-8 -top-8 w-24 h-24 bg-rose-500/5 rounded-full blur-xl" />
            <div className="relative z-10">
              <p className="text-slate-600 text-xs font-black uppercase tracking-wider mb-1">মোট ব্যয়</p>
              <h4 className="text-2xl font-black text-rose-600">{formatCurrency(totalExpense)}</h4>
            </div>
            <div className="relative z-10 w-10 h-10 bg-rose-500/10 text-rose-600 rounded-xl flex items-center justify-center backdrop-blur-md border border-rose-500/20 group-hover:scale-110 transition-transform">
              <ArrowDownRight className="w-6 h-6" />
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40 flex flex-col justify-between group"
        >
          {/* Subtle background glow for savings */}
          <div className="absolute -right-16 -top-16 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl" />
          
          <div className="flex items-center justify-between">
            <div className="relative z-10 space-y-1">
              <p className="text-slate-600 text-xs font-black uppercase tracking-wider">মোট সঞ্চয়</p>
              <h4 className="text-3xl font-black text-indigo-700 tracking-tight">{formatCurrency(totalSavings)}</h4>
            </div>
            <button 
              onClick={() => setShowAddModal('savings')}
              className="relative z-10 flex items-center gap-2 px-4 py-3 sm:px-5 sm:py-3.5 bg-indigo-600 text-white rounded-2xl font-bold transition-all hover:bg-indigo-700 hover:scale-105 active:scale-95 shadow-xl shadow-indigo-200"
              title="সঞ্চয় যোগ করুন"
            >
              <PiggyBank className="w-5 h-5 sm:w-6 sm:h-6" />
              <span className="text-sm sm:text-base tracking-wide">সঞ্চয় করুন</span>
            </button>
          </div>

          {/* Savings Goal Progress */}
          <div className="mt-4 pt-4 border-t border-slate-200/50 relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500">
                {user?.savingsGoal ? `লক্ষ্য: ${formatCurrency(user.savingsGoal)}` : 'কোনো লক্ষ্যমাত্রা নেই'}
              </span>
              <button 
                onClick={() => {
                  setGoalAmount(user?.savingsGoal?.toString() || '');
                  setGoalDate(user?.savingsGoalDate || '');
                  setShowGoalModal(true);
                }}
                className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg hover:bg-indigo-100 transition-colors flex items-center gap-1"
              >
                <Edit2 className="w-3 h-3" />
                {user?.savingsGoal ? 'পরিবর্তন' : 'সেট করুন'}
              </button>
            </div>
            {user?.savingsGoal && user.savingsGoal > 0 && (
              <button 
                onClick={() => setShowSavingsHistory(true)}
                className="w-full text-left bg-transparent block group cursor-pointer"
              >
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden mb-2 group-hover:bg-slate-200 transition-colors">
                  <div 
                    className="h-full bg-indigo-500 transition-all duration-1000" 
                    style={{ width: `${Math.min((totalSavings / user.savingsGoal) * 100, 100)}%` }} 
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] font-bold">
                  <span className="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full group-hover:bg-indigo-100 transition-colors">
                    {Math.min((totalSavings / user.savingsGoal) * 100, 100).toFixed(1)}% সম্পন্ন (হিস্টোরি দেখুন)
                  </span>
                </div>
                {user.savingsGoalDate && (
                  <div className="flex items-center justify-between text-[10px] font-bold mt-2">
                    <span className={cn(
                      "px-2 py-0.5 rounded-full flex items-center gap-1",
                      new Date(user.savingsGoalDate) < new Date() ? "text-rose-600 bg-rose-50" : "text-slate-500 bg-slate-100"
                    )}>
                      <Calendar className="w-3 h-3" />
                      {new Date(user.savingsGoalDate) < new Date() 
                        ? 'সময় শেষ' 
                        : `${Math.ceil((new Date(user.savingsGoalDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24))} দিন বাকি`}
                    </span>
                    {new Date(user.savingsGoalDate) >= new Date() && user.savingsGoal > totalSavings && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 flex items-center gap-1">
                        প্রতিদিন: {formatCurrency(Math.ceil((user.savingsGoal - totalSavings) / Math.ceil((new Date(user.savingsGoalDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24))))}
                      </span>
                    )}
                  </div>
                )}
              </button>
            )}
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-4 gap-2 sm:gap-4 w-full mx-auto my-8">
        <button 
          onClick={() => setShowAddModal('income')}
          className="flex flex-col items-center justify-center gap-1.5 sm:gap-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 text-emerald-700 rounded-3xl py-4 font-bold active:scale-95 transition-all group shadow-sm"
        >
          <div className="p-2 sm:p-2.5 bg-emerald-200/50 rounded-2xl group-hover:scale-110 transition-transform">
            <Plus className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <span className="text-[10px] sm:text-xs uppercase tracking-widest font-black">আয়</span>
        </button>

        <button 
          onClick={() => setShowAddModal('expense')}
          className="flex flex-col items-center justify-center gap-1.5 sm:gap-2 bg-rose-50 hover:bg-rose-100 border border-rose-100 text-rose-700 rounded-3xl py-4 font-bold active:scale-95 transition-all group shadow-sm"
        >
          <div className="p-2 sm:p-2.5 bg-rose-200/50 rounded-2xl group-hover:scale-110 transition-transform">
            <Minus className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <span className="text-[10px] sm:text-xs uppercase tracking-widest font-black">ব্যয়</span>
        </button>

        <button 
          onClick={() => setShowAddModal('transfer')}
          className="flex flex-col items-center justify-center gap-1.5 sm:gap-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-3xl py-4 font-bold active:scale-95 transition-all group shadow-sm"
        >
          <div className="p-2 sm:p-2.5 bg-slate-200/50 rounded-2xl group-hover:scale-110 transition-transform">
            <ArrowRightLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <span className="text-[10px] sm:text-xs uppercase tracking-widest font-black text-center leading-tight">ট্রান্সফার</span>
        </button>

        <button 
          onClick={() => setShowCashInputModal(true)}
          className="flex flex-col items-center justify-center gap-1.5 sm:gap-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 rounded-3xl py-4 font-bold active:scale-95 transition-all group shadow-sm relative overflow-hidden"
        >
          <div className="p-2 sm:p-2.5 bg-indigo-200/50 rounded-2xl group-hover:scale-110 transition-transform">
            <Calculator className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <span className="text-[10px] sm:text-xs uppercase tracking-widest font-black text-center leading-tight">ক্যাশ<br className="sm:hidden" />ইনপুট</span>
        </button>
      </div>

          {/* Search & Filter */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  placeholder="লেনদেন খুঁজুন..."
                  className="w-full pl-11 pr-4 py-3 bg-white border border-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button 
                onClick={downloadPDF}
                className="p-3 bg-white border border-slate-100 rounded-xl text-slate-600 hover:text-emerald-600 transition-all"
                title="PDF ডাউনলোড"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
              <button 
                onClick={() => setFilterType('all')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'all' ? "bg-slate-800 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                সব
              </button>
              <button 
                onClick={() => setFilterType('income')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'income' ? "bg-emerald-600 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                আয়
              </button>
              <button 
                onClick={() => setFilterType('expense')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                  filterType === 'expense' ? "bg-rose-500 text-white" : "bg-white text-slate-500 border border-slate-100"
                )}
              >
                ব্যয়
              </button>
            </div>
          </div>

          {/* History List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
              {entries.length > 0 && (
                <button 
                  onClick={handleDeleteAll}
                  className="text-rose-500 text-xs font-bold flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  সব মুছুন
                </button>
              )}
            </div>
            {filteredEntries.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
                <p className="text-slate-400">কোন লেনদেন পাওয়া যায়নি</p>
              </div>
            ) : (
              <>
                {(() => {
                  const displayEntries = filteredEntries.slice(0, visibleTxs);
                  const groups: { [date: string]: { entries: CashEntry[], totalIncome: number, totalExpense: number } } = {};
                  
                  displayEntries.forEach(entry => {
                    const d = new Date(entry.date);
                    const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                    if (!groups[dateKey]) {
                      groups[dateKey] = { entries: [], totalIncome: 0, totalExpense: 0 };
                    }
                    groups[dateKey].entries.push(entry);
                    if (entry.type === 'income' && entry.category !== 'ট্রান্সফার' && entry.category !== 'সঞ্চয়') groups[dateKey].totalIncome += entry.amount;
                    if (entry.type === 'expense' && entry.category !== 'ট্রান্সফার' && entry.category !== 'সঞ্চয়') groups[dateKey].totalExpense += entry.amount;
                  });
                  
                  const sortedGroups = Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0]));
                  
                  return sortedGroups.map(([date, group]) => (
                    <div key={date} className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden mb-4">
                      <div className="bg-slate-50/80 px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                           <Calendar className="w-4 h-4 text-slate-400" />
                           <span className="font-bold text-slate-700 text-sm">
                             {new Date(date).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })}
                           </span>
                        </div>
                        <div className="flex gap-4 text-xs font-bold">
                           {group.totalExpense > 0 && <span className="text-rose-500">ব্যয়: {formatCurrency(group.totalExpense)}</span>}
                           {group.totalIncome > 0 && <span className="text-emerald-500">আয়: {formatCurrency(group.totalIncome)}</span>}
                        </div>
                      </div>
                      <div className="divide-y divide-slate-100">
                        {group.entries.map((entry) => {
                          const catInfo = getCategoryIcon(entry.category, entry.type);
                          const Icon = catInfo.icon;
                          const PMIcon = getPaymentIcon(entry.paymentMethod);
                          return (
                            <div key={entry.id} className="p-4 bg-white hover:bg-slate-50/50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 group">
                              <div className="flex items-center gap-4">
                              <div className={cn(
                                "w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 shrink-0",
                                entry.type === 'income' ? "bg-emerald-50 text-emerald-500" : "bg-rose-50 text-rose-500"
                              )}>
                                <Icon className="w-6 h-6" />
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                  <h5 className="font-black text-slate-800 text-lg">{formatCurrency(entry.amount)}</h5>
                                  <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-[10px] rounded-md font-black uppercase tracking-wider border border-slate-200 truncate">
                                    {entry.category}
                                  </span>
                                </div>
                                <div className="flex items-center gap-3 text-xs text-slate-600 font-black mt-1">
                                  <span className="flex items-center gap-1 shrink-0">
                                    <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                                    {new Date(entry.date).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
                                  </span>
                                  <span className="flex items-center gap-1 text-slate-700 shrink-0">
                                    <PMIcon className="w-3.5 h-3.5 text-blue-600" />
                                    <span className="truncate">{PAYMENT_METHODS.find(p => p.name === entry.paymentMethod)?.label || 'ক্যাশ'}</span>
                                  </span>
                                </div>
                                {entry.note && (
                                  <p className="text-xs text-slate-500 mt-1.5 font-medium italic flex items-center gap-1.5 line-clamp-1">
                                    <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" /> {entry.note}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center justify-end gap-1 opacity-100 transition-all border-t sm:border-0 border-slate-100 pt-3 sm:pt-0">
                              <button 
                                onClick={() => handleEdit(entry)}
                                className="p-2 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 rounded-lg transition-all"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => handleDelete(entry.id)}
                                className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}
              
              {visibleTxs < filteredEntries.length && (
                <button
                  onClick={() => setVisibleTxs(prev => prev + 50)}
                  className="w-full py-4 text-center text-sm font-bold text-slate-500 bg-slate-50 hover:bg-slate-100 rounded-2xl transition-all border border-slate-100 mt-2"
                >
                  আরও দেখুন
                </button>
              )}
            </>
            )}
          </div>

      {/* Add Modal */}
      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'entry'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteEntry}
        title="এন্ট্রি মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই এন্ট্রিটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAll}
        title="সব ইতিহাস মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল ইতিহাস মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।"
      />

      {/* Savings Goal Modal */}
      <AnimatePresence>
        {showGoalModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowGoalModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-6 sm:p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">সঞ্চয়ের লক্ষ্যমাত্রা</h3>
                <button onClick={() => setShowGoalModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSaveGoal} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">লক্ষ্যমাত্রার পরিমাণ</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={goalAmount}
                    onChange={(e) => setGoalAmount(e.target.value)}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 ml-1">কত তারিখের মধ্যে? (ঐচ্ছিক)</label>
                  <input
                    type="date"
                    className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl outline-none transition-all text-slate-700 font-bold"
                    value={goalDate}
                    onChange={(e) => setGoalDate(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center gap-2"
                >
                  <Check className="w-6 h-6" />
                  সেভ করুন
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCashInputModal && (
          <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCashInputModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl z-10"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-black text-slate-800 flex items-center gap-2">
                  <Calculator className="w-6 h-6 text-indigo-600" />
                  ক্যাশ মিলান
                </h3>
                <button onClick={() => {
                  setShowCashInputModal(false);
                  setActualCash('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="bg-indigo-50 text-indigo-800 p-4 rounded-2xl flex items-center justify-between">
                  <span className="text-sm font-bold">অ্যাপের হিসাব মতে ক্যাশ:</span>
                  <span className="text-xl font-black">{formatCurrency(walletBalances.Cash)}</span>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 ml-1">ড্রয়ারে থাকা মোট ক্যাশ টাকা</label>
                  <input
                    type="number"
                    value={actualCash}
                    onChange={(e) => setActualCash(e.target.value)}
                    placeholder="0"
                    className="w-full text-center text-4xl p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 rounded-2xl outline-none font-black text-slate-800 transition-all"
                  />
                </div>

                {actualCash && parseFloat(actualCash) >= 0 && parseFloat(actualCash) !== walletBalances.Cash && (
                  <div className={cn(
                    "p-4 rounded-2xl border-2 text-center",
                    parseFloat(actualCash) > walletBalances.Cash 
                      ? "bg-emerald-50 border-emerald-100 text-emerald-800" 
                      : "bg-rose-50 border-rose-100 text-rose-800"
                  )}>
                    <p className="text-xs font-bold mb-1 opacity-80">
                      {parseFloat(actualCash) > walletBalances.Cash ? 'হিসাব না করা বেচাকেনা/আয়' : 'ক্যাশ শর্টেজ বা খরচ বাদ পড়েছে'}
                    </p>
                    <p className="text-2xl font-black mb-4 gap-1">
                      {parseFloat(actualCash) > walletBalances.Cash ? '+' : '-'}
                      {formatCurrency(Math.abs(parseFloat(actualCash) - walletBalances.Cash))}
                    </p>
                    
                    <button
                      onClick={async () => {
                        const amount = Math.abs(parseFloat(actualCash) - walletBalances.Cash);
                        const isIncome = parseFloat(actualCash) > walletBalances.Cash;
                        
                        setLoading(true);
                        try {
                          await addDoc(collection(db, 'cashEntries'), {
                            amount,
                            type: isIncome ? 'income' : 'expense',
                            category: isIncome ? 'বিক্রয়' : 'ক্যাশ শর্টেজ',
                            paymentMethod: 'Cash',
                            note: isIncome ? 'অটোমেটিক ক্যাশ মিলানোর মাধ্যমে আয়' : 'অটোমেটিক ক্যাশ মিলানোর মাধ্যমে খরচ/শর্টেজ',
                            date: new Date().toISOString(),
                            ownerUid: user?.uid
                          });
                          toast.success(isIncome ? 'আয় যোগ করা হয়েছে' : 'শর্টেজ যুক্ত করা হয়েছে');
                          setShowCashInputModal(false);
                          setActualCash('');
                        } catch(e) {
                          toast.error('সমস্যা হয়েছে');
                        } finally {
                          setLoading(false);
                        }
                      }}
                      disabled={loading}
                      className={cn(
                        "w-full py-3 rounded-xl font-bold text-sm text-white shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2",
                        parseFloat(actualCash) > walletBalances.Cash ? "bg-emerald-600 shadow-emerald-200" : "bg-rose-600 shadow-rose-200"
                      )}
                    >
                      {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                        parseFloat(actualCash) > walletBalances.Cash ? 'আয় হিসেবে যুক্ত করুন' : 'খরচ হিসেবে যুক্ত করুন'
                      )}
                    </button>
                  </div>
                )}

                {actualCash && parseFloat(actualCash) === walletBalances.Cash && (
                  <div className="bg-emerald-50 text-emerald-800 p-6 rounded-2xl text-center border-2 border-emerald-100">
                    <Check className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
                    <p className="font-black text-lg">অসাধারণ!</p>
                    <p className="text-sm font-medium mt-1">আপনার ক্যাশের হিসাব একদম ১০০% ঠিক আছে।</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-6 sm:p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingEntry ? 'এন্ট্রি এডিট করুন' : (
                    showAddModal === 'income' ? 'আয় যোগ করুন' : 
                    showAddModal === 'expense' ? 'খরচ যোগ করুন' : 
                    showAddModal === 'transfer' ? 'ইন্টারনাল ট্রান্সফার' : 'সঞ্চয় করুন'
                  )}
                </h3>
                <button onClick={() => {
                  setShowAddModal(null);
                  setEditingEntry(null);
                  setAmount('');
                  setCategory('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddEntry} className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-xs font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="text-emerald-600 hover:text-emerald-700 p-1 rounded-lg hover:bg-emerald-50 transition-all font-bold flex flex-row items-center gap-1"
                    >
                      <Calculator className="w-4 h-4" /> <span className="text-xs">ক্যালকুলেটর</span>
                    </button>
                  </div>

                  {/* Quick Buttons */}
                  <div className="grid grid-cols-5 gap-2 mb-2">
                    {(user?.quickButtons || [10, 20, 50, 100, 500]).map((btn: any) => (
                      <button
                        key={btn.id || btn}
                        type="button"
                        onClick={() => setAmount(prev => (parseNumber(prev) + parseNumber(btn.value || btn)).toString())}
                        className="py-2.5 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-600 rounded-xl text-xs font-black border border-slate-100 transition-all"
                      >
                        +{btn.value || btn}
                      </button>
                    ))}
                  </div>

                  <input
                    type="number"
                    placeholder="0.00"
                    autoFocus
                    required
                    className="w-full text-3xl font-black p-4 bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl outline-none transition-all text-center"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                {showAddModal === 'transfer' || showAddModal === 'savings' ? (
                  <>
                    {showAddModal === 'savings' && (
                      <div className="flex bg-slate-100 p-1 rounded-2xl mb-4">
                        <button
                          type="button"
                          onClick={() => setSavingsDirection('deposit')}
                          className={cn(
                            "flex-1 py-2 text-sm font-bold rounded-xl transition-all",
                            savingsDirection === 'deposit' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                          )}
                        >
                          সঞ্চয় জমা
                        </button>
                        <button
                          type="button"
                          onClick={() => setSavingsDirection('withdraw')}
                          className={cn(
                            "flex-1 py-2 text-sm font-bold rounded-xl transition-all",
                            savingsDirection === 'withdraw' ? "bg-white text-purple-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                          )}
                        >
                          সঞ্চয় উত্তোলন
                        </button>
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1">
                          {showAddModal === 'savings' ? (savingsDirection === 'deposit' ? 'কোথা থেকে' : 'সঞ্চয় থেকে') : 'কোথা থেকে'}
                        </label>
                        <select 
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                          disabled={showAddModal === 'savings' && savingsDirection === 'withdraw'}
                          value={showAddModal === 'savings' && savingsDirection === 'withdraw' ? 'Savings' : paymentMethod}
                          onChange={(e) => setPaymentMethod(e.target.value as any)}
                        >
                          {showAddModal === 'savings' && savingsDirection === 'withdraw' ? (
                            <option value="Savings">সঞ্চয় ফান্ড</option>
                          ) : (
                            PAYMENT_METHODS.map(pm => (
                              <option key={pm.name} value={pm.name}>{pm.label}</option>
                            ))
                          )}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1">
                          {showAddModal === 'savings' ? (savingsDirection === 'deposit' ? 'সঞ্চয় ফান্ডে' : 'কোথায়') : 'কোথায়'}
                        </label>
                        <select 
                          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                          disabled={showAddModal === 'savings' && savingsDirection === 'deposit'}
                          value={showAddModal === 'savings' && savingsDirection === 'deposit' ? 'Savings' : (showAddModal === 'savings' ? paymentMethod : toPaymentMethod)}
                          onChange={(e) => showAddModal === 'savings' ? setPaymentMethod(e.target.value as any) : setToPaymentMethod(e.target.value as any)}
                        >
                          {showAddModal === 'savings' && savingsDirection === 'deposit' ? (
                            <option value="Savings">সঞ্চয় ফান্ড</option>
                          ) : (
                            PAYMENT_METHODS.map(pm => (
                              <option key={pm.name} value={pm.name}>{pm.label}</option>
                            ))
                          )}
                        </select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between ml-1">
                        <label className="text-xs font-bold text-slate-500">ক্যাটাগরি</label>
                        <button 
                          type="button" 
                          onClick={() => setIsEditingCategory(!isEditingCategory)}
                          className={cn("text-[10px] font-bold px-2 py-0.5 rounded-lg transition-colors", isEditingCategory ? "bg-indigo-500 text-white" : "text-indigo-600 bg-indigo-50 hover:bg-indigo-100")}
                        >
                          {isEditingCategory ? 'সম্পন্ন' : 'এডিট'}
                        </button>
                      </div>
                      <div className="grid grid-cols-4 gap-2 max-h-40 overflow-y-auto p-1 no-scrollbar">
                        {(showAddModal === 'income' ? userCategories.income : userCategories.expense).map((catName) => {
                          const predefined = CATEGORIES[showAddModal as 'income' | 'expense']?.find(c => c.name === catName);
                          const CategoryIcon = predefined?.icon || (showAddModal === 'income' ? TrendingUp : TrendingDown);
                          const color = predefined?.color || (showAddModal === 'income' ? 'text-emerald-500' : 'text-rose-500');
                          const bg = predefined?.bg || (showAddModal === 'income' ? 'bg-emerald-50' : 'bg-rose-50');
                          
                          return (
                            <div key={catName} className="relative group">
                              <button
                                type="button"
                                disabled={isEditingCategory}
                                onClick={() => setCategory(catName)}
                                className={cn(
                                  "w-full flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all h-full",
                                  category === catName && !isEditingCategory
                                    ? "border-emerald-500 bg-emerald-50" 
                                    : "border-transparent bg-slate-50",
                                  !isEditingCategory && "hover:bg-slate-100",
                                  isEditingCategory && "opacity-50"
                                )}
                              >
                                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", bg, color)}>
                                  <CategoryIcon className="w-5 h-5" />
                                </div>
                                <span className="text-[8px] font-bold text-slate-600 truncate w-full text-center">{catName}</span>
                              </button>
                              {isEditingCategory && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const currentCats = showAddModal === 'income' ? userCategories.income : userCategories.expense;
                                    handleUpdateCategories(currentCats.filter(c => c !== catName), showAddModal as 'income' | 'expense');
                                  }}
                                  className="absolute -top-1 -right-1 bg-rose-500 text-white rounded-full p-0.5 shadow-md hover:scale-110 transition-transform z-10"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          );
                        })}
                        {isEditingCategory && (
                          <div className="flex flex-col gap-1 col-span-4 mt-2">
                            <div className="flex items-center gap-2">
                              <input 
                                type="text"
                                placeholder="নতুন নাম..."
                                value={newCategoryName}
                                onChange={(e) => setNewCategoryName(e.target.value)}
                                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  if (!newCategoryName.trim()) return;
                                  const currentCats = showAddModal === 'income' ? userCategories.income : userCategories.expense;
                                  if (!currentCats.includes(newCategoryName.trim())) {
                                    handleUpdateCategories([...currentCats, newCategoryName.trim()], showAddModal as 'income' | 'expense');
                                  }
                                  setNewCategoryName('');
                                }}
                                className="bg-indigo-600 text-white p-2 rounded-xl"
                              >
                                <Plus className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1">পেমেন্ট মেথড</label>
                      <div className="grid grid-cols-2 gap-2">
                        {(showAddModal === 'income' || showAddModal === 'expense' ? PAYMENT_METHODS.filter(pm => pm.name !== 'Personal' && pm.name !== 'Other') : PAYMENT_METHODS).map((pm) => (
                          <button
                            key={pm.name}
                            type="button"
                            onClick={() => setPaymentMethod(pm.name as any)}
                            className={cn(
                              "flex items-center gap-2 p-3 rounded-xl border-2 transition-all",
                              paymentMethod === pm.name 
                                ? "border-emerald-500 bg-emerald-50" 
                                : "border-transparent bg-slate-50 hover:bg-slate-100"
                            )}
                          >
                            <pm.icon className={cn("w-4 h-4", paymentMethod === pm.name ? "text-emerald-500" : "text-slate-400")} />
                            <span className="text-[10px] font-bold text-slate-600">{pm.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-xs font-bold text-slate-500">নোট (ঐচ্ছিক)</label>
                    <button 
                      type="button" 
                      onClick={() => setIsEditingQuickItems(!isEditingQuickItems)}
                      className={cn("text-[10px] font-bold px-2 py-0.5 rounded-lg transition-colors flex items-center gap-1", isEditingQuickItems ? "bg-indigo-500 text-white" : "text-indigo-600 bg-indigo-50 hover:bg-indigo-100")}
                    >
                      {isEditingQuickItems ? 'সম্পন্ন' : (
                        <>
                          <Edit2 className="w-3 h-3" />
                          কুইক আইটেম
                        </>
                      )}
                    </button>
                  </div>

                  {/* Quick Items */}
                  <div className="flex flex-wrap gap-2 mb-2">
                    {(user?.quickItemsCash || user?.quickItems || ['সিগারেট', 'চা পাতা', 'পান', 'বিস্কুট']).map((item: string, idx: number) => (
                      <div key={idx} className="relative group">
                        <button
                          type="button"
                          disabled={isEditingQuickItems}
                          onClick={() => setNote(prev => prev ? `${prev}, ${item}` : item)}
                          className={cn(
                            "px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all h-full",
                            note.includes(item) && !isEditingQuickItems
                              ? "bg-slate-800 text-white border-slate-800 shadow-md" 
                              : "bg-slate-50 text-slate-600 border-slate-100",
                            !isEditingQuickItems && "hover:bg-slate-100",
                            isEditingQuickItems && "opacity-50"
                          )}
                        >
                          {item}
                        </button>
                        {isEditingQuickItems && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              const currentItems = user?.quickItemsCash || user?.quickItems || ['সিগারেট', 'চা পাতা', 'পান', 'বিস্কুট'];
                              handleUpdateQuickItems(currentItems.filter((_, i) => i !== idx));
                            }}
                            className="absolute -top-1 -right-1 bg-rose-500 text-white rounded-full p-0.5 shadow-md hover:scale-110 transition-transform z-10"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    ))}
                    {isEditingQuickItems && (
                      <div className="flex items-center gap-1">
                        <input 
                          type="text"
                          placeholder="নতুন আইটেম..."
                          value={newQuickItemName}
                          onChange={(e) => setNewQuickItemName(e.target.value)}
                          className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-[10px] font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 w-24"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (!newQuickItemName.trim()) return;
                            const currentItems = user?.quickItemsCash || user?.quickItems || ['সিগারেট', 'চা পাতা', 'পান', 'বিস্কুট'];
                            if (!currentItems.includes(newQuickItemName.trim())) {
                              handleUpdateQuickItems([...currentItems, newQuickItemName.trim()]);
                            }
                            setNewQuickItemName('');
                          }}
                          className="bg-indigo-600 text-white p-1.5 rounded-lg"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>

                  <input
                    type="text"
                    placeholder="বিস্তারিত লিখুন"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-4 rounded-2xl text-white font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95",
                    showAddModal === 'income' ? "bg-emerald-600 shadow-emerald-100" : 
                    showAddModal === 'expense' ? "bg-rose-500 shadow-rose-100" :
                    showAddModal === 'transfer' ? "bg-slate-800 shadow-slate-100" : "bg-indigo-600 shadow-indigo-100"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
