import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  StickyNote, 
  Plus, 
  Search, 
  Trash2, 
  Edit2, 
  X, 
  Check, 
  Calendar,
  Clock,
  MoreVertical,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { toast } from 'react-hot-toast';
import { cn } from '../lib/utils';
import { ConfirmModal } from '../components/ConfirmModal';

interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  color: string;
  reminderDate?: string;
  ownerUid: string;
}

const COLORS = [
  { name: 'Emerald', bg: 'bg-emerald-50', border: 'border-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  { name: 'Blue', bg: 'bg-blue-50', border: 'border-blue-100', text: 'text-blue-700', dot: 'bg-blue-500' },
  { name: 'Amber', bg: 'bg-amber-50', border: 'border-amber-100', text: 'text-amber-700', dot: 'bg-amber-500' },
  { name: 'Rose', bg: 'bg-rose-50', border: 'border-rose-100', text: 'text-rose-700', dot: 'bg-rose-500' },
  { name: 'Indigo', bg: 'bg-indigo-50', border: 'border-indigo-100', text: 'text-indigo-700', dot: 'bg-indigo-500' },
  { name: 'Slate', bg: 'bg-slate-50', border: 'border-slate-100', text: 'text-slate-700', dot: 'bg-slate-500' },
];

export const NotesPage: React.FC = () => {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [viewingNote, setViewingNote] = useState<Note | null>(null);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [newNote, setNewNote] = useState({ title: '', content: '', color: COLORS[0].name, reminderDate: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notes'), 
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setNotes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Note)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'notes'));

    return () => unsubscribe();
  }, [user]);

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.content.trim() || !user) return;
    setIsSubmitting(true);

    const isEditing = !!editingNote;
    const noteData = {
      title: newNote.title,
      content: newNote.content,
      color: newNote.color || COLORS[0].name,
      reminderDate: newNote.reminderDate || '',
      date: new Date().toISOString(),
      ownerUid: user.uid
    };

    // Optimistic UI: Close modal and reset state immediately
    setShowAddModal(false);
    setEditingNote(null);
    setNewNote({ title: '', content: '', color: COLORS[0].name, reminderDate: '' });
    setIsSubmitting(false);
    toast.success(isEditing ? 'নোট আপডেট করা হয়েছে' : 'নতুন নোট যোগ করা হয়েছে');

    try {
      if (isEditing && editingNote) {
        await updateDoc(doc(db, 'notes', editingNote.id), noteData);
      } else {
        await addDoc(collection(db, 'notes'), noteData);
      }
    } catch (error) {
      console.error('Note Save Error:', error);
      handleFirestoreError(error, OperationType.WRITE, isEditing ? `notes/${editingNote?.id}` : 'notes');
    }
  };

  const handleDeleteNote = async () => {
    if (!confirmDelete) return;
    const noteId = confirmDelete;
    setConfirmDelete(null);
    try {
      await deleteDoc(doc(db, 'notes', noteId));
      toast.success('নোট মুছে ফেলা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `notes/${noteId}`);
    }
  };

  const handleDeleteAllNotes = async () => {
    if (!user) return;
    setConfirmDeleteAll(false);
    setIsSubmitting(true);
    try {
      const deletePromises = notes.map(note => deleteDoc(doc(db, 'notes', note.id)));
      await Promise.all(deletePromises);
      toast.success('সব নোট মুছে ফেলা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'notes');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredNotes = notes.filter(note => 
    note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    note.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getNoteColor = (colorName: string) => {
    return COLORS.find(c => c.name === colorName) || COLORS[0];
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <StickyNote className="w-7 h-7 text-emerald-600" />
            আমার নোটস
          </h2>
          <p className="text-slate-500 text-sm font-medium">গুরুত্বপূর্ণ তথ্য লিখে রাখুন</p>
        </div>
        <div className="flex items-center gap-2">
          {notes.length > 0 && (
            <button
              onClick={() => setConfirmDeleteAll(true)}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-rose-50 text-rose-600 rounded-2xl font-bold hover:bg-rose-100 transition-all active:scale-95"
            >
              <Trash2 className="w-5 h-5" />
              সব মুছুন
            </button>
          )}
          <button
            onClick={() => {
              setEditingNote(null);
              setNewNote({ title: '', content: '', color: COLORS[0].name, reminderDate: '' });
              setShowAddModal(true);
            }}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95"
          >
            <Plus className="w-5 h-5" />
            নতুন নোট
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="নোট খুঁজুন..."
          className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm transition-all"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filteredNotes.length === 0 ? (
        <div className="bg-white rounded-[2.5rem] p-12 text-center border border-slate-100 shadow-sm">
          <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <StickyNote className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-1">কোন নোট পাওয়া যায়নি</h3>
          <p className="text-slate-500 text-sm">নতুন নোট যোগ করতে উপরের বাটনে ক্লিক করুন</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => {
            const color = getNoteColor(note.color);
            return (
              <motion.div
                layout
                key={note.id}
                onClick={() => setViewingNote(note)}
                className={cn(
                  "group relative p-6 rounded-[2rem] border-2 transition-all hover:shadow-xl hover:-translate-y-1 cursor-pointer",
                  color.bg,
                  color.border
                )}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={cn("w-2 h-2 rounded-full", color.dot)} />
                    <h3 className={cn("font-black text-lg truncate pr-16", color.text)}>
                      {note.title || 'শিরোনামহীন'}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1 absolute top-4 right-4" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => {
                        setEditingNote(note);
                        setNewNote({ title: note.title, content: note.content, color: note.color, reminderDate: note.reminderDate || '' });
                        setShowAddModal(true);
                      }}
                      className="p-2 bg-white/50 hover:bg-white rounded-xl transition-all text-slate-600 shadow-sm"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(note.id)}
                      className="p-2 bg-rose-50/50 hover:bg-rose-50 rounded-xl transition-all text-rose-500 shadow-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <p className="text-slate-600 text-sm line-clamp-4 leading-relaxed mb-4 whitespace-pre-wrap">
                  {note.content}
                </p>
                <div className="flex items-center gap-4 mt-auto pt-4 border-t border-black/5 flex-wrap">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <Calendar className="w-3 h-3" />
                    {new Date(note.date).toLocaleDateString('bn-BD')}
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <Clock className="w-3 h-3" />
                    {new Date(note.date).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  {note.reminderDate && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-rose-500 uppercase tracking-wider bg-rose-50 px-2 py-1 rounded-full">
                      <AlertCircle className="w-3 h-3" />
                      রিমাইন্ডার: {new Date(note.reminderDate).toLocaleString('bn-BD', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="relative w-full h-full bg-white shadow-2xl overflow-hidden flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-white sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setShowAddModal(false)} 
                    className="p-2 hover:bg-slate-100 rounded-xl transition-all"
                  >
                    <X className="w-6 h-6 text-slate-400" />
                  </button>
                  <h3 className="text-xl font-black text-slate-800">
                    {editingNote ? 'নোট এডিট করুন' : 'নতুন নোট যোগ করুন'}
                  </h3>
                </div>
                <button
                  onClick={handleAddNote}
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Check className="w-5 h-5" />
                      সেভ করুন
                    </>
                  )}
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 sm:p-10 custom-scrollbar">
                <div className="h-full flex flex-col space-y-8">
                  {/* Color Picker */}
                  <div className="space-y-4 shrink-0">
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-[0.2em] ml-1">কালার সিলেক্ট করুন</label>
                    <div className="flex flex-wrap gap-3">
                      {COLORS.map((color) => (
                        <button
                          key={color.name}
                          type="button"
                          onClick={() => setNewNote({ ...newNote, color: color.name })}
                          className={cn(
                            "w-12 h-12 rounded-2xl border-4 transition-all flex items-center justify-center",
                            color.bg,
                            newNote.color === color.name ? "border-emerald-500 scale-110 shadow-lg" : "border-transparent"
                          )}
                        >
                          {newNote.color === color.name && <Check className={cn("w-6 h-6", color.text)} />}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Reminder Input */}
                  <div className="space-y-2 shrink-0">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">রিমাইন্ডার (ঐচ্ছিক)</label>
                    <input
                      type="datetime-local"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold text-slate-600 focus:border-emerald-500 focus:bg-white outline-none transition-all shadow-sm"
                      value={newNote.reminderDate}
                      onChange={(e) => setNewNote({ ...newNote, reminderDate: e.target.value })}
                    />
                  </div>

                  {/* Title Input */}
                  <div className="space-y-2 shrink-0">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">শিরোনাম (ঐচ্ছিক)</label>
                    <input
                      type="text"
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-xl font-black text-slate-800 focus:border-emerald-500 focus:bg-white outline-none transition-all placeholder:text-slate-300 shadow-sm"
                      placeholder="নোটের শিরোনাম দিন..."
                      value={newNote.title}
                      onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                    />
                  </div>

                  {/* Content Area */}
                  <div className="space-y-2 flex-1 flex flex-col min-h-[40vh]">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1 shrink-0">বিস্তারিত নোট</label>
                    <textarea
                      required
                      className="flex-1 w-full px-5 py-5 bg-slate-50 border border-slate-100 rounded-3xl text-lg text-slate-600 focus:border-emerald-500 focus:bg-white outline-none transition-all resize-none placeholder:text-slate-300 leading-relaxed shadow-sm"
                      placeholder="আপনার নোটটি এখানে লিখুন..."
                      value={newNote.content}
                      onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={handleDeleteNote}
        title="নোট মুছে ফেলুন"
        message="আপনি কি নিশ্চিত যে আপনি এই নোটটি মুছে ফেলতে চান? এটি আর ফিরে পাওয়া যাবে না।"
        confirmText="মুছে ফেলুন"
        cancelText="বাতিল"
      />

      {/* View Modal */}
      <AnimatePresence>
        {viewingNote && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setViewingNote(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className={cn(
                "relative w-full h-full shadow-2xl overflow-hidden flex flex-col",
                getNoteColor(viewingNote.color).bg
              )}
            >
              <div className="flex items-center justify-between p-6 border-b border-black/5 sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setViewingNote(null)} 
                    className="p-2 hover:bg-black/5 rounded-xl transition-all"
                  >
                    <X className="w-6 h-6 text-slate-400" />
                  </button>
                  <h3 className="text-xl font-black text-slate-800">নোট দেখুন</h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setEditingNote(viewingNote);
                      setNewNote({ title: viewingNote.title, content: viewingNote.content, color: viewingNote.color, reminderDate: viewingNote.reminderDate || '' });
                      setViewingNote(null);
                      setShowAddModal(true);
                    }}
                    className="p-3 bg-white rounded-xl text-slate-600 shadow-sm hover:shadow-md transition-all active:scale-95"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      setConfirmDelete(viewingNote.id);
                      setViewingNote(null);
                    }}
                    className="p-3 bg-rose-50 rounded-xl text-rose-500 shadow-sm hover:shadow-md transition-all active:scale-95"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 sm:p-10 custom-scrollbar">
                <div className="space-y-6">
                  <div className="flex items-center gap-2">
                    <div className={cn("w-3 h-3 rounded-full", getNoteColor(viewingNote.color).dot)} />
                    <h2 className="text-3xl font-black text-slate-800 leading-tight">
                      {viewingNote.title || 'শিরোনামহীন'}
                    </h2>
                  </div>
                  
                  <div className="flex items-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      {new Date(viewingNote.date).toLocaleDateString('bn-BD')}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {new Date(viewingNote.date).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  <div className="h-px bg-black/5 w-full" />

                  <p className="text-xl text-slate-700 leading-[1.8] whitespace-pre-wrap font-medium">
                    {viewingNote.content}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={confirmDeleteAll}
        onClose={() => setConfirmDeleteAll(false)}
        onConfirm={handleDeleteAllNotes}
        title="সব নোট মুছে ফেলুন"
        message="আপনি কি নিশ্চিত যে আপনি আপনার সব নোট মুছে ফেলতে চান? এটি আর ফিরে পাওয়া যাবে না।"
        confirmText="সব মুছুন"
        cancelText="বাতিল"
      />
    </div>
  );
};


