import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  StickyNote, 
  Plus, 
  Search, 
  Trash2, 
  Edit2, 
  X, 
  Check, 
  Calendar,
  Clock,
  MoreVertical,
  AlertCircle,
  Loader2,
  Calculator,
  Settings2,
  Palette,
  User
} from 'lucide-react';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { toast } from 'react-hot-toast';
import { cn } from '../lib/utils';
import { ConfirmModal } from '../components/ConfirmModal';
import { Customer } from '../types';

interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  color: string;
  reminderDate?: string;
  ownerUid: string;
}

const COLORS = [
  { name: 'Emerald', bg: 'bg-emerald-50', border: 'border-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  { name: 'Blue', bg: 'bg-blue-50', border: 'border-blue-100', text: 'text-blue-700', dot: 'bg-blue-500' },
  { name: 'Amber', bg: 'bg-amber-50', border: 'border-amber-100', text: 'text-amber-700', dot: 'bg-amber-500' },
  { name: 'Rose', bg: 'bg-rose-50', border: 'border-rose-100', text: 'text-rose-700', dot: 'bg-rose-500' },
  { name: 'Indigo', bg: 'bg-indigo-50', border: 'border-indigo-100', text: 'text-indigo-700', dot: 'bg-indigo-500' },
  { name: 'Slate', bg: 'bg-slate-50', border: 'border-slate-100', text: 'text-slate-700', dot: 'bg-slate-500' },
];

export const NotesPage: React.FC = () => {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [viewingNote, setViewingNote] = useState<Note | null>(null);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [newNote, setNewNote] = useState({ title: '', content: '', color: COLORS[0].name, reminderDate: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  // Quick Items State
  const [isManagingQuickItems, setIsManagingQuickItems] = useState(false);
  const [newQuickItemName, setNewQuickItemName] = useState('');
  const [newQuickItemPrice, setNewQuickItemPrice] = useState('');

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
  const [activePanel, setActivePanel] = useState<'none' | 'color' | 'reminder' | 'customer'>('none');
  const [splitSelections, setSplitSelections] = useState<Record<number, number>>({});

  const quickItems = user?.quickItemsNotes || [
    'সিগারেট|15',
    'চা|10',
    'পান|5',
    'বিস্কুট|10'
  ];

  const parsedQuickItems = quickItems.map((qi, idx) => {
    const [name, price] = qi.split('|');
    return { name, price: price ? Number(price) : 0, originalIndex: idx };
  });

  const handleUpdateQuickItems = async (newItems: string[]) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        quickItemsNotes: newItems
      });
      toast.success('কুইক আইটেম আপডেট করা হয়েছে');
    } catch (error) {
      console.error(error);
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const calculateTotal = (content: string) => {
    let total = 0;
    const lines = content.split('\n');
    lines.forEach(line => {
      // Matches "= 15 ৳" resulting from Quick Items
      const matchNew = line.match(/= (\d+)\s*৳/); 
      if (matchNew && matchNew[1]) {
        total += parseInt(matchNew[1], 10);
        return;
      }
      // Hand-typed backwards compatibility " - 15 ৳"
      const matchOld = line.match(/- (\d+)\s*৳/); 
      if (matchOld && matchOld[1]) {
        total += parseInt(matchOld[1], 10);
      }
    });
    return total;
  };

  const handleQuickItemTap = (name: string, price: number) => {
    setNewNote(prev => {
      const lines = prev.content ? prev.content.split('\n') : [];
      let found = false;
      const updatedLines = lines.map(line => {
        // match "Name x Qty = Total ৳"
        const regex = new RegExp(`^${name} x (\\d+) = (\\d+) ৳$`);
        const match = line.trim().match(regex);
        if (match) {
          found = true;
          const qty = parseInt(match[1], 10) + 1;
          return `${name} x ${qty} = ${qty * price} ৳`;
        }
        
        // Match backward compatibility "Name - Price ৳"
        if (line.trim() === `${name} - ${price} ৳`) {
          found = true;
          return `${name} x 2 = ${2 * price} ৳`;
        }
        
        return line;
      });

      if (!found) {
        updatedLines.push(`${name} x 1 = ${price} ৳`);
      }

      return {
        ...prev,
        content: updatedLines.filter(l => l.trim()).join('\n')
      };
    });
  };

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notes'), 
      where('ownerUid', '==', user.uid),
      orderBy('date', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setNotes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Note)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'notes'));

    const qCust = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubCust = onSnapshot(qCust, (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'customers'));

    return () => {
      unsubscribe();
      unsubCust();
    };
  }, [user]);

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.content.trim() || !user) return;
    setIsSubmitting(true);

    const isEditing = !!editingNote;
    const noteData = {
      title: newNote.title,
      content: newNote.content,
      color: newNote.color || COLORS[0].name,
      reminderDate: newNote.reminderDate || '',
      date: new Date().toISOString(),
      ownerUid: user.uid
    };

    // Optimistic UI: Close modal and reset state immediately
    setShowAddModal(false);
    setEditingNote(null);
    setNewNote({ title: '', content: '', color: COLORS[0].name, reminderDate: '' });
    setIsSubmitting(false);
    toast.success(isEditing ? 'নোট আপডেট করা হয়েছে' : 'নতুন নোট যোগ করা হয়েছে');

    try {
      if (isEditing && editingNote) {
        await updateDoc(doc(db, 'notes', editingNote.id), noteData);
      } else {
        await addDoc(collection(db, 'notes'), noteData);
      }
    } catch (error) {
      console.error('Note Save Error:', error);
      handleFirestoreError(error, OperationType.WRITE, isEditing ? `notes/${editingNote?.id}` : 'notes');
    }
  };

  const handleDeleteNote = async () => {
    if (!confirmDelete) return;
    const noteId = confirmDelete;
    setConfirmDelete(null);
    try {
      await deleteDoc(doc(db, 'notes', noteId));
      toast.success('নোট মুছে ফেলা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `notes/${noteId}`);
    }
  };

  const handleDeleteAllNotes = async () => {
    if (!user) return;
    setConfirmDeleteAll(false);
    setIsSubmitting(true);
    try {
      const deletePromises = notes.map(note => deleteDoc(doc(db, 'notes', note.id)));
      await Promise.all(deletePromises);
      toast.success('সব নোট মুছে ফেলা হয়েছে');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'notes');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddToCustomerProfile = async () => {
    if (!selectedCustomerId || calculateTotal(newNote.content) === 0 || !user) return;
    setIsSubmitting(true);
    try {
      const customer = customers.find(c => c.id === selectedCustomerId);
      if (!customer) return;

      const hasSelections = Object.keys(splitSelections).length > 0 && Object.values(splitSelections).some(v => v > 0);
      
      let transactionAmount = 0;
      let transactionNote = '';
      let updatedNoteContent = newNote.content;

      if (hasSelections) {
        const lines: (string | null)[] = newNote.content.split('\n');
        const transactionLines: string[] = [];

        lines.forEach((line, index) => {
          if (line === null) return;
          const trimmed = line.trim();
          if (!trimmed) return;
          
          const qtyMatch = trimmed.match(/^(.*?) x (\d+) = (\d+)\s*৳$/);
          const simpleMatch = trimmed.match(/^(.*?)(?: \- |=| = )(\d+)\s*৳$/);
          
          let name = '';
          let originalQty = 0;
          let unitPrice = 0;

          if (qtyMatch) {
            name = qtyMatch[1].trim();
            originalQty = parseInt(qtyMatch[2], 10);
            const total = parseInt(qtyMatch[3], 10);
            unitPrice = originalQty > 0 ? total / originalQty : total;
          } else if (simpleMatch) {
            name = simpleMatch[1].trim() || 'অজানা আইটেম';
            originalQty = 1;
            unitPrice = parseInt(simpleMatch[2], 10);
          }

          if (originalQty > 0) {
            const selectedQty = splitSelections[index] || 0;
            if (selectedQty > 0) {
              const itemTotal = selectedQty * unitPrice;
              transactionAmount += itemTotal;
              transactionLines.push(`${name} x ${selectedQty} = ${itemTotal} ৳`);
              
              const remainingQty = originalQty - selectedQty;
              if (remainingQty > 0) {
                 lines[index] = `${name} x ${remainingQty} = ${remainingQty * unitPrice} ৳`;
              } else {
                 lines[index] = null;
              }
            }
          }
        });

        transactionNote = (newNote.title ? `[${newNote.title}] ` : '') + '\n' + transactionLines.join('\n') + '\n\n(নোট থেকে আংশিক যোগ হলো)';
        updatedNoteContent = lines.filter(l => l !== null).join('\n');
      } else {
        transactionAmount = calculateTotal(newNote.content);
        transactionNote = (newNote.title ? `[${newNote.title}] ` : '') + '\n' + newNote.content + '\n\n(নোট থেকে সম্পূর্ণ যোগ হলো)';
      }

      if (transactionAmount > 0) {
        await addDoc(collection(db, 'transactions'), {
          customerId: selectedCustomerId,
          amount: transactionAmount,
          type: 'baki',
          note: transactionNote,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });

        await updateDoc(doc(db, 'customers', selectedCustomerId), {
          totalBalance: (customer.totalBalance || 0) + transactionAmount,
          updatedAt: new Date().toISOString()
        });

        toast.success(`${customer.name} এর প্রোফাইলে ${transactionAmount}৳ যোগ করা হয়েছে`);
      }
      
      if (hasSelections) {
         setNewNote(prev => ({ ...prev, content: updatedNoteContent }));
         setSplitSelections({});
      }
      
      setSelectedCustomerId('');
      setActivePanel('none');
    } catch (error) {
       handleFirestoreError(error, OperationType.WRITE, 'transactions');
    } finally {
       setIsSubmitting(false);
    }
  };

  const filteredNotes = notes.filter(note => 
    note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    note.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getNoteColor = (colorName: string) => {
    return COLORS.find(c => c.name === colorName) || COLORS[0];
  };

  const splittableItems = React.useMemo(() => {
    const items: any[] = [];
    newNote.content.split('\n').forEach((line, index) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      
      const qtyMatch = trimmed.match(/^(.*?) x (\d+) = (\d+)\s*৳$/);
      const simpleMatch = trimmed.match(/^(.*?)(?: \- |=| = )(\d+)\s*৳$/);
      
      if (qtyMatch) {
         const qty = parseInt(qtyMatch[2], 10);
         const total = parseInt(qtyMatch[3], 10);
         items.push({
            index,
            name: qtyMatch[1].trim(),
            qty,
            unitPrice: qty > 0 ? total / qty : total,
            total
         });
      } else if (simpleMatch) {
         items.push({
            index,
            name: simpleMatch[1].trim() || 'অজানা আইটেম',
            qty: 1,
            unitPrice: parseInt(simpleMatch[2], 10),
            total: parseInt(simpleMatch[2], 10)
         });
      }
    });
    return items;
  }, [newNote.content]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <StickyNote className="w-7 h-7 text-emerald-600" />
            আমার নোটস
          </h2>
          <p className="text-slate-500 text-sm font-medium">গুরুত্বপূর্ণ তথ্য লিখে রাখুন</p>
        </div>
        <div className="flex items-center gap-2">
          {notes.length > 0 && (
            <button
              onClick={() => setConfirmDeleteAll(true)}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-rose-50 text-rose-600 rounded-2xl font-bold hover:bg-rose-100 transition-all active:scale-95"
            >
              <Trash2 className="w-5 h-5" />
              সব মুছুন
            </button>
          )}
          <button
            onClick={() => {
              setEditingNote(null);
              setNewNote({ title: '', content: '', color: COLORS[0].name, reminderDate: '' });
              setShowAddModal(true);
            }}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95"
          >
            <Plus className="w-5 h-5" />
            নতুন নোট
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="নোট খুঁজুন..."
          className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm transition-all"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filteredNotes.length === 0 ? (
        <div className="bg-white rounded-[2.5rem] p-12 text-center border border-slate-100 shadow-sm">
          <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <StickyNote className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-1">কোন নোট পাওয়া যায়নি</h3>
          <p className="text-slate-500 text-sm">নতুন নোট যোগ করতে উপরের বাটনে ক্লিক করুন</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => {
            const color = getNoteColor(note.color);
            return (
              <motion.div
                layout
                key={note.id}
                onClick={() => setViewingNote(note)}
                className={cn(
                  "group relative p-6 rounded-[2rem] border-2 transition-all hover:shadow-xl hover:-translate-y-1 cursor-pointer flex flex-col",
                  color.bg,
                  color.border
                )}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={cn("w-2 h-2 rounded-full", color.dot)} />
                    <h3 className={cn("font-black text-lg truncate pr-16", color.text)}>
                      {note.title || 'শিরোনামহীন'}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1 absolute top-4 right-4" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => {
                        setEditingNote(note);
                        setNewNote({ title: note.title, content: note.content, color: note.color, reminderDate: note.reminderDate || '' });
                        setShowAddModal(true);
                      }}
                      className="p-2 bg-white/50 hover:bg-white rounded-xl transition-all text-slate-600 shadow-sm"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(note.id)}
                      className="p-2 bg-rose-50/50 hover:bg-rose-50 rounded-xl transition-all text-rose-500 shadow-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <p className="text-slate-600 text-sm line-clamp-4 leading-relaxed mb-4 whitespace-pre-wrap flex-1">
                  {note.content}
                </p>
                {calculateTotal(note.content) > 0 && (
                  <div className="mb-4 inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/60 rounded-xl font-bold text-emerald-700 shadow-sm w-max">
                    <Calculator className="w-4 h-4" />
                    মোট: {calculateTotal(note.content)} ৳
                  </div>
                )}
                <div className="flex items-center gap-4 mt-auto pt-4 border-t border-black/5 flex-wrap">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <Calendar className="w-3 h-3" />
                    {new Date(note.date).toLocaleDateString('bn-BD')}
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <Clock className="w-3 h-3" />
                    {new Date(note.date).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  {note.reminderDate && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-rose-500 uppercase tracking-wider bg-rose-50 px-2 py-1 rounded-full">
                      <AlertCircle className="w-3 h-3" />
                      রিমাইন্ডার: {new Date(note.reminderDate).toLocaleString('bn-BD', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className={cn(
                "relative w-full h-full shadow-2xl overflow-hidden flex flex-col transition-colors duration-300",
                getNoteColor(newNote.color).bg
              )}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-black/5 bg-white/20 backdrop-blur-md sticky top-0 z-10 transition-colors duration-300">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setShowAddModal(false)} 
                    className="p-2 hover:bg-black/5 rounded-xl transition-all"
                  >
                    <X className="w-6 h-6 text-slate-500" />
                  </button>
                  <h3 className="text-xl font-black text-slate-800">
                    {editingNote ? 'নোট এডিট করুন' : 'নতুন নোট যোগ করুন'}
                  </h3>
                </div>
                <button
                  onClick={handleAddNote}
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all active:scale-95 disabled:opacity-50 shadow-sm"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Check className="w-5 h-5" />
                      সেভ করুন
                    </>
                  )}
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar">
                <div className="h-full flex flex-col space-y-4">
                  {/* Title Input */}
                  <div className="shrink-0">
                    <input
                      type="text"
                      className="w-full px-4 py-3 bg-white/50 border border-white/40 rounded-2xl text-lg font-black text-slate-800 focus:border-white focus:bg-white outline-none transition-all placeholder:text-slate-500 shadow-sm backdrop-blur-sm"
                      placeholder="কাস্টমার/নোটের শিরোনাম (যেমন: চাচার চায়ের বিল)..."
                      value={newNote.title}
                      onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                    />
                  </div>

                  {/* Action Bar */}
                  <div className="flex flex-wrap gap-2 shrink-0">
                    <button 
                      type="button"
                      onClick={() => setActivePanel(activePanel === 'color' ? 'none' : 'color')} 
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border backdrop-blur-sm",
                        activePanel === 'color' ? "bg-white border-white text-emerald-700 shadow-sm" : "bg-white/40 border-white/40 text-slate-600 hover:bg-white/60"
                      )}
                    >
                      <Palette className={cn("w-4 h-4", activePanel === 'color' ? "text-emerald-500" : "text-slate-500")} />
                      কালার
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActivePanel(activePanel === 'reminder' ? 'none' : 'reminder')} 
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border backdrop-blur-sm",
                        activePanel === 'reminder' ? "bg-white border-white text-blue-700 shadow-sm" : "bg-white/40 border-white/40 text-slate-600 hover:bg-white/60"
                      )}
                    >
                      <Clock className={cn("w-4 h-4", activePanel === 'reminder' ? "text-blue-500" : "text-slate-500")} />
                      রিমাইন্ডার {newNote.reminderDate && <span className="w-1.5 h-1.5 rounded-full bg-blue-500 ml-1" />}
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActivePanel(activePanel === 'customer' ? 'none' : 'customer')} 
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border backdrop-blur-sm",
                        activePanel === 'customer' ? "bg-white border-white text-indigo-700 shadow-sm" : "bg-white/40 border-white/40 text-slate-600 hover:bg-white/60"
                      )}
                    >
                      <User className={cn("w-4 h-4", activePanel === 'customer' ? "text-indigo-500" : "text-slate-500")} />
                      কাস্টমার প্রোফাইল {selectedCustomerId && <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 ml-1" />}
                    </button>
                  </div>

                  {/* ACTIVE PANELS */}
                  <div className="relative z-[100]">
                    <AnimatePresence mode="wait">
                      {/* Color Panel */}
                    {activePanel === 'color' && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0, overflow: 'hidden' }}
                        animate={{ height: 'auto', opacity: 1, transitionEnd: { overflow: 'visible' } }}
                        exit={{ height: 0, opacity: 0, overflow: 'hidden' }}
                        className="shrink-0"
                      >
                        <div className="p-3 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/40 flex flex-wrap gap-2 shadow-sm">
                          <span className="block w-full text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">কালার সিলেক্ট করুন</span>
                          {COLORS.map((color) => (
                            <button
                              key={color.name}
                              type="button"
                              onClick={() => setNewNote({ ...newNote, color: color.name })}
                              className={cn(
                                "w-8 h-8 rounded-xl border-2 transition-all flex items-center justify-center",
                                color.bg,
                                newNote.color === color.name ? "border-emerald-500 scale-110 shadow-sm" : "border-white/50"
                              )}
                            >
                              {newNote.color === color.name && <Check className={cn("w-4 h-4", color.text)} />}
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {/* Reminder Panel */}
                    {activePanel === 'reminder' && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0, overflow: 'hidden' }}
                        animate={{ height: 'auto', opacity: 1, transitionEnd: { overflow: 'visible' } }}
                        exit={{ height: 0, opacity: 0, overflow: 'hidden' }}
                        className="shrink-0"
                      >
                        <div className="p-3 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/40 shadow-sm">
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">রিমাইন্ডার সেট করুন (ঐচ্ছিক)</label>
                          <input
                            type="datetime-local"
                            className="w-full sm:w-auto px-4 py-2 bg-white/60 border border-white/40 rounded-xl text-sm font-bold text-slate-700 focus:border-white focus:bg-white focus:outline-none transition-all accent-emerald-600"
                            value={newNote.reminderDate}
                            onChange={(e) => setNewNote({ ...newNote, reminderDate: e.target.value })}
                          />
                        </div>
                      </motion.div>
                    )}

                    {/* Customer Panel */}
                    {activePanel === 'customer' && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0, overflow: 'hidden' }}
                        animate={{ height: 'auto', opacity: 1, transitionEnd: { overflow: 'visible' } }}
                        exit={{ height: 0, opacity: 0, overflow: 'hidden' }}
                        className="shrink-0 relative z-50"
                      >
                        <div className="bg-white/50 backdrop-blur-sm p-4 rounded-3xl border border-white/40 space-y-3 shadow-sm">
                           <label className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">কাস্টমারের প্রোফাইলে বাকি হিসেবে যোগ করুন</label>
                           
                           {splittableItems.length > 0 && selectedCustomerId && (
                             <div className="mb-3 p-3 bg-white/60 rounded-2xl border border-white/40 shadow-sm space-y-3">
                               <div className="flex items-center justify-between">
                                 <label className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">আইটেম ভাগ করুন (ঐচ্ছিক)</label>
                                 <button 
                                   type="button"
                                   onClick={(e) => {
                                     e.stopPropagation();
                                     const allSelected = splittableItems.every(i => splitSelections[i.index] === i.qty);
                                     if (allSelected) {
                                       setSplitSelections({});
                                     } else {
                                       const newSelections: Record<number, number> = {};
                                       splittableItems.forEach(i => {
                                         newSelections[i.index] = i.qty;
                                       });
                                       setSplitSelections(newSelections);
                                     }
                                   }}
                                   className="text-[10px] font-bold text-indigo-600 bg-indigo-50/80 hover:bg-indigo-100 px-2.5 py-1 rounded-md transition-colors"
                                 >
                                   {splittableItems.every(i => splitSelections[i.index] === i.qty) ? 'সবগুলো বাতিল' : 'সবগুলো নির্বাচন'}
                                 </button>
                               </div>
                               <div className="space-y-2">
                                 {splittableItems.map(item => (
                                   <div key={item.index} className="flex items-center justify-between">
                                      <div className="text-sm font-bold text-slate-700 truncate max-w-[120px] sm:max-w-[150px]">
                                         {item.name} <span className="text-slate-400 text-xs">({item.unitPrice}৳)</span>
                                      </div>
                                      <div className="flex items-center gap-3 bg-white/80 rounded-lg p-1 border border-white/50 shadow-sm">
                                         <button 
                                           disabled={!splitSelections[item.index]}
                                           onClick={() => setSplitSelections(s => ({...s, [item.index]: Math.max(0, (s[item.index] || 0) - 1)}))}
                                           className="w-6 h-6 flex items-center justify-center bg-slate-100 rounded-md text-slate-600 font-bold disabled:opacity-50"
                                         >-</button>
                                         <span className="text-xs font-black min-w-[24px] text-center">{splitSelections[item.index] || 0} / {item.qty}</span>
                                         <button 
                                           disabled={(splitSelections[item.index] || 0) >= item.qty}
                                           onClick={() => setSplitSelections(s => ({...s, [item.index]: Math.min(item.qty, (s[item.index] || 0) + 1)}))}
                                           className="w-6 h-6 flex items-center justify-center bg-slate-100 rounded-md text-slate-600 font-bold disabled:opacity-50"
                                         >+</button>
                                      </div>
                                   </div>
                                 ))}
                               </div>
                             </div>
                           )}

                           <div className="flex flex-col sm:flex-row gap-2 relative overflow-visible">
                             <div className="flex-1 relative">
                               <div 
                                 className="w-full h-[44px] px-4 bg-white/60 border border-white/40 rounded-xl text-sm font-bold text-slate-700 cursor-pointer flex justify-between items-center hover:border-white transition-colors backdrop-blur-sm shadow-sm"
                                 onClick={() => setIsCustomerDropdownOpen(!isCustomerDropdownOpen)}
                               >
                                 {selectedCustomerId ? customers.find(c => c.id === selectedCustomerId)?.name : '-- কাস্টমার সিলেক্ট করুন --'}
                                 <svg className={cn("w-4 h-4 text-slate-400 transition-transform", isCustomerDropdownOpen && "rotate-180")} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                 </svg>
                               </div>
                               
                               <AnimatePresence>
                                 {isCustomerDropdownOpen && (
                                   <motion.div 
                                     initial={{ opacity: 0, y: -10 }}
                                     animate={{ opacity: 1, y: 0 }}
                                     exit={{ opacity: 0, y: -10 }}
                                     className="absolute z-[60] top-full mt-2 w-full bg-white border border-indigo-100 rounded-2xl shadow-xl max-h-60 flex flex-col overflow-hidden"
                                   >
                                     <div className="p-2 border-b border-slate-100 shrink-0">
                                       <div className="relative w-full">
                                          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                          <input 
                                            type="text"
                                            className="w-full pl-9 pr-4 py-2 bg-slate-50 border-none rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-100 font-medium"
                                            placeholder="কাস্টমার খুঁজুন..."
                                            value={customerSearchQuery}
                                            onChange={(e) => setCustomerSearchQuery(e.target.value)}
                                            onClick={(e) => e.stopPropagation()}
                                          />
                                       </div>
                                     </div>
                                     <div className="overflow-y-auto flex-1 custom-scrollbar">
                                       {customers.filter(c => c.name.toLowerCase().includes(customerSearchQuery.toLowerCase())).map(c => (
                                         <div 
                                            key={c.id}
                                            className={cn("px-4 py-3 hover:bg-slate-50 cursor-pointer text-sm font-bold transition-colors", selectedCustomerId === c.id ? "bg-slate-50 text-slate-700" : "text-slate-600")}
                                            onClick={() => {
                                              setSelectedCustomerId(c.id);
                                              setIsCustomerDropdownOpen(false);
                                              setCustomerSearchQuery('');
                                            }}
                                         >
                                            {c.name}
                                         </div>
                                       ))}
                                       {customers.filter(c => c.name.toLowerCase().includes(customerSearchQuery.toLowerCase())).length === 0 && (
                                         <div className="px-4 py-4 text-sm text-slate-500 text-center font-medium">কোন কাস্টমার পাওয়া যায়নি</div>
                                       )}
                                     </div>
                                   </motion.div>
                                 )}
                               </AnimatePresence>
                             </div>
                             <button 
                               type="button"
                               disabled={!selectedCustomerId || calculateTotal(newNote.content) === 0}
                               onClick={handleAddToCustomerProfile}
                               className="px-6 py-2.5 h-[44px] bg-indigo-600 text-white rounded-xl font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-indigo-700 active:scale-95 transition-all whitespace-nowrap shadow-sm flex flex-col justify-center items-center"
                             >
                               <span className="text-sm">প্রোফাইলে লিখুন</span>
                               <span className="text-[10px] opacity-80 mt-[-2px]">{Object.values(splitSelections).some(v => v > 0) ? `(৳${Object.entries(splitSelections).reduce((acc, [idx, qty]) => acc + qty * (splittableItems.find(i => i.index === parseInt(idx))?.unitPrice || 0), 0)})` : `(সম্পূর্ণ বিল)`}</span>
                             </button>
                           </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  </div>

                  {/* Quick Items Area */}
                  <div className="w-full bg-white/40 backdrop-blur-sm p-3 sm:p-4 rounded-3xl border border-white/40 shrink-0 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">কুইক বিল অ্যাড করুন</label>
                      <button
                        type="button"
                        onClick={() => setIsManagingQuickItems(true)}
                        className="text-slate-500 hover:bg-white/50 p-1.5 rounded-lg transition-colors flex items-center justify-center shrink-0 w-8 h-8"
                      >
                        <Settings2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {parsedQuickItems.map((item, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleQuickItemTap(item.name, item.price)}
                          className="px-3 py-2 bg-white/60 border border-white/50 text-slate-700 rounded-xl font-bold shadow-sm hover:shadow-md hover:border-white transition-all active:scale-95 flex items-center gap-1.5 text-sm backdrop-blur-sm"
                        >
                          {item.name} <span className="text-slate-400">|</span> {item.price} ৳
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Text Area */}
                  <div className="flex-1 flex flex-col relative mt-2 min-h-[30vh]">
                    <div className="flex items-end justify-between mx-1 mb-2">
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] shrink-0">বিস্তারিত হিসাব/নোট</label>
                      {calculateTotal(newNote.content) > 0 && (
                        <div className="text-right">
                          <span className="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-0.5">মোট বিল</span>
                          <span className="text-xl font-black text-slate-800">
                            {calculateTotal(newNote.content)} ৳
                          </span>
                        </div>
                      )}
                    </div>
                      <textarea
                        required
                        className="flex-1 w-full px-5 py-5 bg-white/50 border border-white/40 rounded-3xl text-lg text-slate-800 focus:border-white focus:bg-white/60 outline-none transition-all resize-none placeholder:text-slate-500 leading-relaxed shadow-sm min-h-[30vh] backdrop-blur-sm"
                        placeholder="হিসাব বা নোট লিখুন..."
                        value={newNote.content}
                        onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                      />
                    </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Quick Items Management Modal */}
      <AnimatePresence>
        {isManagingQuickItems && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsManagingQuickItems(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-md bg-white rounded-[2rem] shadow-2xl overflow-hidden m-4"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-800">কুইক আইটেম সেটিংস</h3>
                <button 
                  onClick={() => setIsManagingQuickItems(false)}
                  className="p-2 hover:bg-slate-100 rounded-xl transition-all"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="space-y-3">
                  {parsedQuickItems.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3 bg-slate-50 p-3 rounded-2xl">
                      <div className="flex-1 font-bold text-slate-700">{item.name}</div>
                      <div className="font-bold text-emerald-600">{item.price} ৳</div>
                      <button
                        onClick={() => {
                          const newItems = [...quickItems];
                          newItems.splice(item.originalIndex, 1);
                          handleUpdateQuickItems(newItems);
                        }}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-slate-100 space-y-4">
                  <h4 className="text-sm font-bold text-slate-600">নতুন আইটেম যোগ করুন</h4>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      placeholder="নাম (যেমন: চা)"
                      className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      value={newQuickItemName}
                      onChange={(e) => setNewQuickItemName(e.target.value)}
                    />
                    <input
                      type="number"
                      placeholder="দাম (৳)"
                      className="w-24 px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      value={newQuickItemPrice}
                      onChange={(e) => setNewQuickItemPrice(e.target.value)}
                    />
                  </div>
                  <button
                    onClick={() => {
                      if (!newQuickItemName || !newQuickItemPrice) return;
                      const newItem = `${newQuickItemName}|${newQuickItemPrice}`;
                      handleUpdateQuickItems([...quickItems, newItem]);
                      setNewQuickItemName('');
                      setNewQuickItemPrice('');
                    }}
                    className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all active:scale-95"
                  >
                    যোগ করুন
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={handleDeleteNote}
        title="নোট মুছে ফেলুন"
        message="আপনি কি নিশ্চিত যে আপনি এই নোটটি মুছে ফেলতে চান? এটি আর ফিরে পাওয়া যাবে না।"
        confirmText="মুছে ফেলুন"
        cancelText="বাতিল"
      />

      {/* View Modal */}
      <AnimatePresence>
        {viewingNote && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setViewingNote(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className={cn(
                "relative w-full h-full shadow-2xl overflow-hidden flex flex-col",
                getNoteColor(viewingNote.color).bg
              )}
            >
              <div className="flex items-center justify-between p-6 border-b border-black/5 sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setViewingNote(null)} 
                    className="p-2 hover:bg-black/5 rounded-xl transition-all"
                  >
                    <X className="w-6 h-6 text-slate-400" />
                  </button>
                  <h3 className="text-xl font-black text-slate-800">নোট দেখুন</h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setEditingNote(viewingNote);
                      setNewNote({ title: viewingNote.title, content: viewingNote.content, color: viewingNote.color, reminderDate: viewingNote.reminderDate || '' });
                      setViewingNote(null);
                      setShowAddModal(true);
                    }}
                    className="p-3 bg-white rounded-xl text-slate-600 shadow-sm hover:shadow-md transition-all active:scale-95"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      setConfirmDelete(viewingNote.id);
                      setViewingNote(null);
                    }}
                    className="p-3 bg-rose-50 rounded-xl text-rose-500 shadow-sm hover:shadow-md transition-all active:scale-95"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 sm:p-10 custom-scrollbar">
                <div className="space-y-6">
                  <div className="flex items-center gap-2">
                    <div className={cn("w-3 h-3 rounded-full", getNoteColor(viewingNote.color).dot)} />
                    <h2 className="text-3xl font-black text-slate-800 leading-tight">
                      {viewingNote.title || 'শিরোনামহীন'}
                    </h2>
                  </div>
                  
                  <div className="flex items-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      {new Date(viewingNote.date).toLocaleDateString('bn-BD')}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {new Date(viewingNote.date).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  <div className="h-px bg-black/5 w-full" />

                  <p className="text-xl text-slate-700 leading-[1.8] whitespace-pre-wrap font-medium">
                    {viewingNote.content}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={confirmDeleteAll}
        onClose={() => setConfirmDeleteAll(false)}
        onConfirm={handleDeleteAllNotes}
        title="সব নোট মুছে ফেলুন"
        message="আপনি কি নিশ্চিত যে আপনি আপনার সব নোট মুছে ফেলতে চান? এটি আর ফিরে পাওয়া যাবে না।"
        confirmText="সব মুছুন"
        cancelText="বাতিল"
      />
    </div>
  );
};


