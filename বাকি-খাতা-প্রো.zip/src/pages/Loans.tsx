import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  HandCoins, 
  Phone, 
  MapPin, 
  Calendar, 
  FileText, 
  Trash2, 
  X, 
  Check, 
  Loader2,
  ChevronRight,
  UserPlus,
  ArrowLeft,
  Edit2,
  Calculator,
  Download
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  getDocs,
  deleteDoc, 
  doc,
  updateDoc,
  writeBatch,
  increment
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Loaner, LoanTransaction } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import { toast } from 'react-hot-toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export const LoansPage: React.FC = () => {
  const { user } = useAuth();
  const [loaners, setLoaners] = useState<Loaner[]>([]);
  const [selectedLoanerId, setSelectedLoanerId] = useState<string | null>(null);
  const [showAddLoanerModal, setShowAddLoanerModal] = useState(false);
  const [editingLoaner, setEditingLoaner] = useState<Loaner | null>(null);
  const [loading, setLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'loaner', id: string } | null>(null);

  // Form states for new loaner
  const [newLoaner, setNewLoaner] = useState({ name: '', phone: '', address: '', profilePic: '' });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast.error('ছবি ১ মেগাবাইটের কম হতে হবে');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewLoaner(prev => ({ ...prev, profilePic: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'loaners'), where('ownerUid', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setLoaners(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Loaner)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'loaners'));
    return () => unsubscribe();
  }, [user]);

  const handleAddLoaner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLoaner.name || !user) return;

    const isEditing = !!editingLoaner;
    const loanerData = {
      ...newLoaner,
      ownerUid: user.uid
    };

    // Optimistic UI: Close modal and reset state immediately
    setShowAddLoanerModal(false);
    setEditingLoaner(null);
    setNewLoaner({ name: '', phone: '', address: '', profilePic: '' });
    toast.success(isEditing ? 'আপডেট করা হয়েছে' : 'সাপ্লায়ার যোগ করা হয়েছে');

    try {
      if (isEditing && editingLoaner) {
        await updateDoc(doc(db, 'loaners', editingLoaner.id), loanerData);
      } else {
        await addDoc(collection(db, 'loaners'), {
          ...loanerData,
          totalTaken: 0,
          totalPaid: 0
        });
      }
    } catch (error) {
      console.error('Loaner Save Error:', error);
      handleFirestoreError(error, isEditing ? OperationType.UPDATE : OperationType.CREATE, isEditing ? `loaners/${editingLoaner?.id}` : 'loaners');
    }
  };

  const handleEditLoaner = (e: React.MouseEvent, loaner: Loaner) => {
    e.stopPropagation();
    setEditingLoaner(loaner);
    setNewLoaner({ 
      name: loaner.name, 
      phone: loaner.phone, 
      address: loaner.address,
      profilePic: loaner.profilePic || ''
    });
    setShowAddLoanerModal(true);
  };

  const handleDeleteLoaner = (e: React.MouseEvent, loanerId: string) => {
    e.stopPropagation();
    setConfirmDelete({ type: 'loaner', id: loanerId });
  };

  const executeDeleteLoaner = async () => {
    if (!confirmDelete || !confirmDelete.id) return;
    const loanerId = confirmDelete.id;
    
    // Optimistic UI
    setConfirmDelete(null);
    toast.success('সাপ্লায়ার মুছে ফেলা হয়েছে');
    if (selectedLoanerId === loanerId) {
      setSelectedLoanerId(null);
    }

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'loaners', loanerId));
      const q = query(
        collection(db, 'loanTransactions'), 
        where('ownerUid', '==', user.uid),
        where('loanerId', '==', loanerId)
      );
      const snapshot = await getDocs(q);
      snapshot.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  if (selectedLoanerId) {
    return <LoanerDetail loanerId={selectedLoanerId} onBack={() => setSelectedLoanerId(null)} />;
  }

  const totalLoanGiven = loaners.reduce((acc, curr) => acc + (curr.totalTaken - curr.totalPaid), 0);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800 px-1">সাপ্লায়ার হিসাব</h2>

      {/* Summary Card */}
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 flex items-center justify-between group">
        <div className="space-y-1">
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">মোট বাকি (মহাজন)</p>
          <h3 className="text-4xl font-black text-amber-600 tracking-tight">{formatCurrency(totalLoanGiven)}</h3>
        </div>
        <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110">
          <HandCoins className="w-10 h-10" />
        </div>
      </div>

      <button 
        onClick={() => setShowAddLoanerModal(true)}
        className="w-full flex items-center justify-center gap-3 py-3.5 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-2xl font-bold uppercase tracking-wider shadow-lg shadow-emerald-100 hover:shadow-emerald-200 transition-all active:scale-[0.98] group relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        <UserPlus className="w-5 h-5 group-hover:scale-110 transition-transform" />
        নতুন সাপ্লায়ার যোগ করুন
      </button>

      {/* Loaners List */}
      <div className="space-y-4">
        <h4 className="font-bold text-slate-700 px-1">সাপ্লায়ার তালিকা</h4>
        {loaners.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">এখনো কোন সাপ্লায়ার নেই</p>
          </div>
        ) : (
          loaners.map((loaner) => (
            <motion.div
              key={loaner.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedLoanerId(loaner.id)}
              className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center font-bold text-lg overflow-hidden">
                  {loaner.profilePic ? (
                    <img 
                      src={loaner.profilePic} 
                      alt={loaner.name} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <img 
                      src="/icon.png" 
                      alt="App Icon" 
                      className="w-full h-full object-cover opacity-40"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                        const parent = (e.target as HTMLImageElement).parentElement;
                        if (parent) parent.innerText = loaner.name[0];
                      }}
                    />
                  )}
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">{loaner.name}</h5>
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Phone className="w-3 h-3" />
                    {loaner.phone}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <p className="font-bold text-amber-600">{formatCurrency(loaner.totalTaken - loaner.totalPaid)}</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">পাওনা</p>
                </div>
                <div className="flex items-center gap-1 transition-all">
                  <button 
                    onClick={(e) => handleEditLoaner(e, loaner)}
                    className="p-2 text-slate-400 hover:text-amber-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={(e) => handleDeleteLoaner(e, loaner.id)}
                    className="p-2 text-slate-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300" />
              </div>
            </motion.div>
          ))
        )}
      </div>

      <ConfirmModal
        isOpen={confirmDelete?.type === 'loaner'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteLoaner}
        title="সাপ্লায়ার মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই সাপ্লায়ারকে মুছতে চান? তার সকল লেনদেনও মুছে যাবে।"
      />

      <AnimatePresence>
        {showAddLoanerModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddLoanerModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingLoaner ? 'সাপ্লায়ার এডিট' : 'নতুন সাপ্লায়ার'}
                </h3>
                <button onClick={() => {
                  setShowAddLoanerModal(false);
                  setEditingLoaner(null);
                  setNewLoaner({ name: '', phone: '', address: '', profilePic: '' });
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddLoaner} className="space-y-4">
                <div className="flex flex-col items-center gap-4 mb-4">
                  <div className="relative group">
                    <div className="w-24 h-24 bg-slate-100 rounded-[2rem] flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300 group-hover:border-amber-500 transition-all">
                      {newLoaner.profilePic ? (
                        <img src={newLoaner.profilePic} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <UserPlus className="w-8 h-8 text-slate-400" />
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">প্রোফাইল ছবি সেট করুন</p>
                </div>

                <input
                  type="text"
                  placeholder="নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={newLoaner.name}
                  onChange={(e) => setNewLoaner({ ...newLoaner, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন নম্বর"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={newLoaner.phone}
                  onChange={(e) => setNewLoaner({ ...newLoaner, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={newLoaner.address}
                  onChange={(e) => setNewLoaner({ ...newLoaner, address: e.target.value })}
                />

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-amber-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-amber-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      যোগ করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const LoanerDetail: React.FC<{ loanerId: string; onBack: () => void }> = ({ loanerId, onBack }) => {
  const { user } = useAuth();
  const [loaner, setLoaner] = useState<Loaner | null>(null);
  const [transactions, setTransactions] = useState<LoanTransaction[]>([]);
  const [showAddModal, setShowAddModal] = useState<'loan' | 'payment' | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<LoanTransaction | null>(null);
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState('');
  const [showCalculator, setShowCalculator] = useState(false);

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const handleCalculatorSave = (total: number) => {
    setAmount(total.toString());
    closeCalculator();
  };
  const [note, setNote] = useState('');
  const [editLoaner, setEditLoaner] = useState({ name: '', phone: '', address: '' });
  const [confirmDelete, setConfirmDelete] = useState<{ type: 'transaction' | 'all' | 'loaner', transaction?: LoanTransaction } | null>(null);

  useEffect(() => {
    const handleClose = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleClose);
    return () => window.removeEventListener('close-calculator', handleClose);
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    const unsubLoaner = onSnapshot(doc(db, 'loaners', loanerId), (doc) => {
      if (doc.exists()) {
        const data = doc.data() as Loaner;
        setLoaner({ id: doc.id, ...data } as Loaner);
        setEditLoaner({ name: data.name, phone: data.phone, address: data.address });
      }
    }, (error) => {
      console.error('Loaner Detail Snapshot Error:', error);
    });

    const q = query(
      collection(db, 'loanTransactions'),
      where('ownerUid', '==', user.uid),
      where('loanerId', '==', loanerId),
      orderBy('date', 'desc')
    );
    const unsubTrans = onSnapshot(q, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LoanTransaction)));
    }, (error) => {
      console.error('Loan Transactions Snapshot Error:', error);
    });

    return () => {
      unsubLoaner();
      unsubTrans();
    };
  }, [loanerId]);

  const handleTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !user) return;

    setLoading(true);
    const numAmount = Number(amount);
    const type = showAddModal!;
    
    // Optimistic UI
    const isEditing = !!editingTransaction;
    const editingTrans = editingTransaction;
    setShowAddModal(null);
    setEditingTransaction(null);
    setAmount('');
    setNote('');
    setLoading(false);
    toast.success(isEditing ? 'আপডেট করা হয়েছে' : (type === 'loan' ? 'বাকি যোগ করা হয়েছে' : 'পেমেন্ট যোগ করা হয়েছে'));

    try {
      const batch = writeBatch(db);
      
      if (isEditing && editingTrans) {
        const transRef = doc(db, 'loanTransactions', editingTrans.id);
        const diff = numAmount - editingTrans.amount;
        
        batch.update(transRef, {
          amount: numAmount,
          note,
        });

        const loanerRef = doc(db, 'loaners', loanerId);
        if (editingTrans.type === 'loan') {
          batch.update(loanerRef, { totalTaken: increment(diff) });
        } else {
          batch.update(loanerRef, { totalPaid: increment(diff) });
        }
      } else {
        const transRef = doc(collection(db, 'loanTransactions'));
        batch.set(transRef, {
          loanerId,
          amount: numAmount,
          type,
          note,
          date: new Date().toISOString(),
          ownerUid: user.uid
        });

        const loanerRef = doc(db, 'loaners', loanerId);
        if (type === 'loan') {
          batch.update(loanerRef, { totalTaken: increment(numAmount) });
        } else {
          batch.update(loanerRef, { totalPaid: increment(numAmount) });
        }
      }

      await batch.commit();
    } catch (error) {
      console.error('Loan transaction error:', error);
      toast.error('সেভ করতে সমস্যা হয়েছে');
    }
  };

  const handleDeleteTransaction = (transaction: LoanTransaction) => {
    setConfirmDelete({ type: 'transaction', transaction });
  };

  const executeDeleteTransaction = async () => {
    if (!confirmDelete || !confirmDelete.transaction) return;
    const transaction = confirmDelete.transaction;
    
    // Optimistic UI
    setConfirmDelete(null);

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'loanTransactions', transaction.id));
      
      const loanerRef = doc(db, 'loaners', loanerId);
      if (transaction.type === 'loan') {
        batch.update(loanerRef, { totalTaken: increment(-transaction.amount) });
      } else {
        batch.update(loanerRef, { totalPaid: increment(-transaction.amount) });
      }
      
      await batch.commit();
      toast.success('মুছে ফেলা হয়েছে');
    } catch (error) {
      console.error('Delete loan transaction error:', error);
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const handleDeleteAllTransactions = () => {
    setConfirmDelete({ type: 'all' });
  };

  const executeDeleteAllTransactions = async () => {
    if (!confirmDelete) return;
    
    // Optimistic UI
    setConfirmDelete(null);
    toast.success('সকল ইতিহাস মুছে ফেলা হয়েছে');

    try {
      const batch = writeBatch(db);
      transactions.forEach(t => batch.delete(doc(db, 'loanTransactions', t.id)));
      
      const loanerRef = doc(db, 'loaners', loanerId);
      batch.update(loanerRef, { totalTaken: 0, totalPaid: 0 });
      
      await batch.commit();
    } catch (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
    }
  };

  const handleDeleteLoanerProfile = () => {
    setConfirmDelete({ type: 'loaner' });
  };

  const executeDeleteLoanerProfile = async () => {
    if (!confirmDelete) return;
    
    // Optimistic UI
    setConfirmDelete(null);
    toast.success('সাপ্লায়ার মুছে ফেলা হয়েছে');
    onBack();

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'loaners', loanerId));
      const q = query(
        collection(db, 'loanTransactions'), 
        where('ownerUid', '==', user.uid),
        where('loanerId', '==', loanerId)
      );
      const snapshot = await getDocs(q);
      snapshot.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const handleEditTransaction = (transaction: LoanTransaction) => {
    setEditingTransaction(transaction);
    setAmount(transaction.amount.toString());
    setNote(transaction.note || '');
    setShowAddModal(transaction.type);
  };

  const handleEditLoanerProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editLoaner.name || !user) return;
    
    // Optimistic UI
    setShowEditModal(false);
    toast.success('সাপ্লায়ার আপডেট করা হয়েছে');

    try {
      await updateDoc(doc(db, 'loaners', loanerId), editLoaner);
    } catch (error) {
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const downloadPDF = () => {
    if (!loaner || !user) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Add Logo if exists
    if (user.shopLogo) {
      try {
        doc.addImage(user.shopLogo, 'PNG', 10, 10, 20, 20);
      } catch (e) {
        console.error('Error adding logo to PDF:', e);
      }
    }

    // App Name & Shop Name
    doc.setFontSize(20);
    doc.setTextColor(245, 158, 11); // Amber-600
    doc.text(user.shopName || 'বাকি খাতা', user.shopLogo ? 35 : 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('সাপ্লায়ার রিপোর্ট', user.shopLogo ? 35 : 10, 28);

    // Supplier Info
    doc.setDrawColor(240);
    doc.line(10, 35, pageWidth - 10, 35);
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`নাম: ${loaner.name}`, 10, 45);
    doc.text(`ফোন: ${loaner.phone || 'N/A'}`, 10, 52);
    doc.text(`ঠিকানা: ${loaner.address || 'N/A'}`, 10, 59);
    
    const balance = loaner.totalTaken - loaner.totalPaid;
    const balanceText = `বর্তমান পাওনা: ${formatCurrency(Math.abs(balance))}`;
    doc.setFontSize(14);
    doc.setTextColor(245, 158, 11); // Amber-600
    doc.text(balanceText, pageWidth - 10, 45, { align: 'right' });

    // Summary Stats
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`মোট বাকি: ${formatCurrency(loaner.totalTaken)}`, pageWidth - 10, 52, { align: 'right' });
    doc.text(`মোট পরিশোধ: ${formatCurrency(loaner.totalPaid)}`, pageWidth - 10, 59, { align: 'right' });

    // Transactions Table
    const tableData = transactions.map(t => [
      formatDate(t.date),
      t.type === 'loan' ? 'বাকি নিলাম (+)' : 'পরিশোধ করলাম (-)',
      formatCurrency(t.amount),
      t.note || '-'
    ]);

    autoTable(doc, {
      startY: 70,
      head: [['তারিখ', 'ধরন', 'পরিমাণ', 'নোট']],
      body: tableData,
      headStyles: { fillColor: [245, 158, 11], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 251, 235] },
      styles: { font: 'helvetica', fontSize: 10 },
      margin: { top: 70 }
    });

    doc.save(`${loaner.name}_supplier_report.pdf`);
    toast.success('PDF ডাউনলোড হচ্ছে...');
  };

  if (!loaner) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="p-2 hover:bg-white rounded-xl transition-all">
          <ArrowLeft className="w-6 h-6 text-slate-600" />
        </button>
        <div className="flex items-center gap-2">
          <button 
            onClick={downloadPDF}
            className="p-2 text-amber-600 hover:bg-white rounded-xl transition-all"
            title="PDF ডাউনলোড করুন"
          >
            <Download className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setShowEditModal(true)}
            className="p-2 text-slate-400 hover:bg-white rounded-xl transition-all"
          >
            <Edit2 className="w-5 h-5" />
          </button>
          <button 
            onClick={handleDeleteLoanerProfile}
            className="p-2 text-rose-400 hover:bg-rose-50 rounded-xl transition-all"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] p-5 shadow-sm border border-slate-100">
        <div className="flex items-center gap-4 mb-5">
          <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 text-xl font-bold shrink-0 overflow-hidden">
            {loaner.profilePic ? (
              <img 
                src={loaner.profilePic} 
                alt={loaner.name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <img 
                src="/icon.png" 
                alt="App Icon" 
                className="w-full h-full object-cover opacity-40"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  const parent = (e.target as HTMLImageElement).parentElement;
                  if (parent) parent.innerText = loaner.name[0];
                }}
              />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold text-slate-800 truncate">{loaner.name}</h2>
            <p className="text-xs text-slate-400 flex items-center gap-1 truncate">
              <MapPin className="w-3 h-3" /> {loaner.address}
            </p>
          </div>
          
          {loaner.phone && (
            <div className="flex gap-2">
              <a 
                href={`tel:${loaner.phone}`}
                className="w-10 h-10 flex items-center justify-center bg-amber-50 text-amber-600 rounded-xl hover:bg-amber-100 transition-all shadow-sm shadow-amber-100"
                title="কল করুন"
              >
                <Phone className="w-4 h-4" />
              </a>
              <a 
                href={`https://wa.me/${loaner.phone.replace(/\D/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 flex items-center justify-center bg-green-50 text-green-600 rounded-xl hover:bg-green-100 transition-all shadow-sm shadow-green-100"
                title="WhatsApp"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </a>
            </div>
          )}
        </div>

        <div className="bg-slate-50 rounded-3xl p-4 mb-4">
          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mb-0.5 text-center">মোট পাওনা</p>
          <h3 className="text-2xl font-black text-amber-600 text-center">
            {formatCurrency(loaner.totalTaken - loaner.totalPaid)}
          </h3>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-50 p-3 rounded-2xl text-center border border-slate-100">
            <p className="text-[9px] text-slate-400 font-bold uppercase mb-0.5">মোট বাকি</p>
            <p className="font-bold text-slate-700 text-xs">{formatCurrency(loaner.totalTaken)}</p>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl text-center border border-slate-100">
            <p className="text-[9px] text-slate-400 font-bold uppercase mb-0.5">মোট পরিশোধ</p>
            <p className="font-bold text-slate-700 text-xs">{formatCurrency(loaner.totalPaid)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <button 
          onClick={() => setShowAddModal('loan')}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-amber-600 text-white rounded-2xl font-bold shadow-lg shadow-amber-100 active:scale-95 transition-all"
        >
          <Plus className="w-5 h-5" />
          বাকি নিলাম
        </button>
        <button 
          onClick={() => setShowAddModal('payment')}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 active:scale-95 transition-all"
        >
          <Check className="w-5 h-5" />
          পরিশোধ করলাম
        </button>
        <button 
          onClick={(e) => {
            e.stopPropagation();
            setShowCalculator(true);
          }}
          className="flex flex-col items-center justify-center gap-2 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold shadow-lg shadow-slate-100 active:scale-95 transition-all"
        >
          <Calculator className="w-5 h-5" />
          হিসাব
        </button>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">লেনদেনের ইতিহাস</h4>
          {transactions.length > 0 && (
            <button 
              onClick={handleDeleteAllTransactions}
              className="text-rose-500 text-xs font-bold flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              সব মুছুন
            </button>
          )}
        </div>
        {transactions.map((t) => (
          <div key={t.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
            <div className="flex items-center gap-4">
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center",
                t.type === 'loan' ? "bg-amber-50 text-amber-500" : "bg-emerald-50 text-emerald-500"
              )}>
                {t.type === 'loan' ? <Plus className="w-5 h-5" /> : <Check className="w-5 h-5" />}
              </div>
              <div>
                <h5 className="font-bold text-slate-800">{formatCurrency(t.amount)}</h5>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold">
                  <Calendar className="w-3 h-3" />
                  {formatDate(t.date)}
                  {t.note && <span className="flex items-center gap-1 ml-2"><FileText className="w-3 h-3" /> {t.note}</span>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1 transition-all">
              <button 
                onClick={() => handleEditTransaction(t)}
                className="p-2 text-slate-400 hover:text-amber-600"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button 
                onClick={() => handleDeleteTransaction(t)}
                className="p-2 text-slate-400 hover:text-rose-500"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modals */}
      <ConfirmModal
        isOpen={confirmDelete?.type === 'loaner'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteLoanerProfile}
        title="সাপ্লায়ার মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই সাপ্লায়ারকে মুছতে চান? তার সকল লেনদেনও মুছে যাবে।"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'transaction'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteTransaction}
        title="লেনদেন মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই লেনদেনটি মুছতে চান?"
      />

      <ConfirmModal
        isOpen={confirmDelete?.type === 'all'}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteAllTransactions}
        title="সব লেনদেন মুছুন"
        message="আপনি কি নিশ্চিতভাবে সকল লেনদেন মুছতে চান? এতে ব্যালেন্স ০ হয়ে যাবে।"
      />

      <AnimatePresence>
        {showEditModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEditModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">সাপ্লায়ার এডিট করুন</h3>
                <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleEditLoanerProfile} className="space-y-4">
                <input
                  type="text"
                  placeholder="নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={editLoaner.name}
                  onChange={(e) => setEditLoaner({ ...editLoaner, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন নম্বর"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={editLoaner.phone}
                  onChange={(e) => setEditLoaner({ ...editLoaner, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  value={editLoaner.address}
                  onChange={(e) => setEditLoaner({ ...editLoaner, address: e.target.value })}
                />

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-amber-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-amber-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      আপডেট করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-black text-slate-800">
                  {editingTransaction ? 'লেনদেন এডিট' : (showAddModal === 'loan' ? 'বাকি নিলাম' : 'পরিশোধ করলাম')}
                </h3>
                <button onClick={() => {
                  setShowAddModal(null);
                  setEditingTransaction(null);
                  setAmount('');
                  setNote('');
                }} className="p-2 hover:bg-slate-100 rounded-full transition-all">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleTransaction} className="space-y-8">
                <div className="space-y-4">
                  <div className="flex items-center justify-between px-1">
                    <label className="text-sm font-bold text-slate-500">টাকার পরিমাণ</label>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCalculator(true);
                      }}
                      className="flex items-center gap-1.5 text-amber-600 font-bold text-sm hover:opacity-80 transition-all"
                    >
                      <Calculator className="w-4 h-4" />
                      ক্যালকুলেটর
                    </button>
                  </div>
                  
                  <div className={cn(
                    "relative p-1 rounded-[2rem] border-2 transition-all",
                    showAddModal === 'loan' ? "border-amber-500 bg-amber-50/30" : "border-emerald-500 bg-emerald-50/30"
                  )}>
                    <input
                      type="number"
                      placeholder="0.00"
                      autoFocus
                      required
                      className="w-full text-5xl font-black p-6 bg-transparent outline-none text-center text-slate-700 placeholder:text-slate-300"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-bold text-slate-500 px-1">নোট (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    placeholder="নোট লিখুন..."
                    className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 transition-all font-bold text-slate-600"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-5 rounded-2xl text-white font-black text-xl shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95",
                    showAddModal === 'loan' ? "bg-amber-600 shadow-amber-100" : "bg-emerald-600 shadow-emerald-100"
                  )}
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-7 h-7" />
                      নিশ্চিত করুন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
            onSave={handleCalculatorSave} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};
