import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Filter, 
  RefreshCw,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  PieChart as PieChartIcon,
  Activity,
  Wallet,
  Target,
  Sparkles,
  Download
} from 'lucide-react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Customer, CashEntry, Transaction } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as ReTooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area,
  BarChart,
  Bar as ReBar,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { format, subDays, startOfWeek, startOfMonth, startOfYear, isWithinInterval, parseISO } from 'date-fns';
import { bn } from 'date-fns/locale';

export const ReportsPage: React.FC = () => {
  const { user } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [cashEntries, setCashEntries] = useState<CashEntry[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [savings, setSavings] = useState<any[]>([]);
  const [loanTransactions, setLoanTransactions] = useState<any[]>([]);
  const [filterType, setFilterType] = useState<'today' | 'week' | 'month' | 'year' | 'custom'>('week');
  const [dateRange, setDateRange] = useState({
    start: format(subDays(new Date(), 7), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd')
  });
  const [aiInsights, setAiInsights] = useState('আপনার ব্যবসার তথ্য বিশ্লেষণ করা হচ্ছে...');
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    if (!user) return;

    const qCustomers = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubCustomers = onSnapshot(qCustomers, (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'customers'));

    const qCash = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
    const unsubCash = onSnapshot(qCash, (snapshot) => {
      setCashEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));

    const qTrans = query(collection(db, 'transactions'), where('ownerUid', '==', user.uid));
    const unsubTrans = onSnapshot(qTrans, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'transactions'));

    const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
    const unsubSavings = onSnapshot(qSavings, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));

    const qLoans = query(collection(db, 'loanTransactions'), where('ownerUid', '==', user.uid));
    const unsubLoans = onSnapshot(qLoans, (snapshot) => {
      setLoanTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'loanTransactions'));

    return () => {
      unsubCustomers();
      unsubCash();
      unsubTrans();
      unsubSavings();
      unsubLoans();
    };
  }, [user]);

  // Handle Quick Filters
  useEffect(() => {
    const now = new Date();
    let start = now;
    let end = now;

    switch (filterType) {
      case 'today':
        start = now;
        break;
      case 'week':
        start = startOfWeek(now, { weekStartsOn: 6 }); // Saturday in BD
        break;
      case 'month':
        start = startOfMonth(now);
        break;
      case 'year':
        start = startOfYear(now);
        break;
      case 'custom':
        return;
    }

    setDateRange({
      start: format(start, 'yyyy-MM-dd'),
      end: format(end, 'yyyy-MM-dd')
    });
  }, [filterType]);

  const filteredData = useMemo(() => {
    const start = parseISO(dateRange.start);
    const end = parseISO(dateRange.end + 'T23:59:59');

    const isDateInRange = (dateStr: string) => {
      const date = parseISO(dateStr);
      return isWithinInterval(date, { start, end });
    };

    const cash = cashEntries.filter(e => isDateInRange(e.date));
    const trans = transactions.filter(t => isDateInRange(t.date));
    const sav = savings.filter(s => isDateInRange(s.date));
    const loans = loanTransactions.filter(l => isDateInRange(l.date));

    return { cash, trans, sav, loans };
  }, [cashEntries, transactions, savings, loanTransactions, dateRange]);

  const totals = useMemo(() => {
    const baki = filteredData.trans.filter(t => t.type === 'baki').reduce((acc, curr) => acc + curr.amount, 0);
    const joma = filteredData.trans.filter(t => t.type === 'joma').reduce((acc, curr) => acc + curr.amount, 0);
    const income = filteredData.cash.filter(e => e.type === 'income').reduce((acc, curr) => acc + curr.amount, 0);
    const expense = filteredData.cash.filter(e => e.type === 'expense').reduce((acc, curr) => acc + curr.amount, 0);
    const savingsTotal = filteredData.sav.reduce((acc, curr) => acc + curr.amount, 0);

    return { baki, joma, income, expense, savingsTotal };
  }, [filteredData]);

  // Chart Data Preparation
  const trendData = useMemo(() => {
    const days: Record<string, { date: string, income: number, expense: number, baki: number, joma: number }> = {};
    
    // Fill days in range
    let current = parseISO(dateRange.start);
    const end = parseISO(dateRange.end);
    while (current <= end) {
      const d = format(current, 'yyyy-MM-dd');
      days[d] = { date: format(current, 'dd MMM', { locale: bn }), income: 0, expense: 0, baki: 0, joma: 0 };
      current = new Date(current.setDate(current.getDate() + 1));
    }

    filteredData.cash.forEach(e => {
      const d = format(new Date(e.date), 'yyyy-MM-dd');
      if (days[d]) {
        if (e.type === 'income') days[d].income += e.amount;
        else days[d].expense += e.amount;
      }
    });

    filteredData.trans.forEach(t => {
      const d = format(new Date(t.date), 'yyyy-MM-dd');
      if (days[d]) {
        if (t.type === 'baki') days[d].baki += t.amount;
        else days[d].joma += t.amount;
      }
    });

    return Object.values(days);
  }, [filteredData, dateRange]);

  const pieData = [
    { name: 'বাকি', value: totals.baki, color: '#f43f5e' },
    { name: 'জমা', value: totals.joma, color: '#10b981' },
    { name: 'আয়', value: totals.income, color: '#6366f1' },
    { name: 'খরচ', value: totals.expense, color: '#f59e0b' },
  ].filter(d => d.value > 0);

  const topCustomers = useMemo(() => {
    return customers
      .filter(c => c.totalBalance > 0)
      .sort((a, b) => b.totalBalance - a.totalBalance)
      .slice(0, 5)
      .map(c => ({ name: c.name, baki: c.totalBalance }));
  }, [customers]);

  const generateSmartInsights = () => {
    const insights = [];
    const { baki, joma, income, expense, savingsTotal } = totals;
    
    if (baki > joma * 1.5) {
      insights.push('আপনার বাকি আদায়ের পরিমাণ জমার চেয়ে অনেক বেশি। বকেয়া টাকা তোলার দিকে নজর দিন।');
    }
    
    if (expense > income && income > 0) {
      insights.push('আপনার খরচ আয়ের চেয়ে বেশি হচ্ছে। অপ্রয়োজনীয় খরচ কমানোর চেষ্টা করুন।');
    }
    
    const riskyCount = customers.filter(c => c.totalBalance > (user?.debtLimits?.red || 10000)).length;
    if (riskyCount > 0) {
      insights.push(`${riskyCount} জন কাস্টমারের বাকি লিমিট অতিক্রম করেছে। তাদের সাথে দ্রুত যোগাযোগ করুন।`);
    }
    
    if (savingsTotal < (income * 0.1) && income > 0) {
      insights.push('আপনার সঞ্চয়ের পরিমাণ আয়ের তুলনায় কম। প্রতি মাসে অন্তত ১০% সঞ্চয় করার চেষ্টা করুন।');
    }

    if (joma > baki && baki > 0) {
      insights.push('আপনার ব্যবসায় জমার পরিমাণ বাকির চেয়ে ভালো। এটি একটি ইতিবাচক দিক।');
    }

    if (insights.length === 0) {
      insights.push('আপনার ব্যবসার অবস্থা স্থিতিশীল। নিয়মিত হিসাব রাখুন এবং কাস্টমারদের সাথে সুসম্পর্ক বজায় রাখুন।');
    }

    setAiInsights(insights.join('\n\n'));
    setLoadingAi(false);
  };

  const downloadPDF = () => {
    if (!user) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Add Logo if exists
    if (user.shopLogo) {
      try {
        doc.addImage(user.shopLogo, 'PNG', 10, 10, 20, 20);
      } catch (e) {
        console.error('Error adding logo to PDF:', e);
      }
    }

    // App Name & Shop Name
    doc.setFontSize(20);
    doc.setTextColor(16, 185, 129); // Emerald-600
    doc.text(user.shopName || 'বাকি খাতা প্রো', user.shopLogo ? 35 : 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('বিজনেস রিপোর্ট', user.shopLogo ? 35 : 10, 28);
    doc.text(`তারিখ: ${formatDate(dateRange.start)} থেকে ${formatDate(dateRange.end)}`, user.shopLogo ? 35 : 10, 35);

    // Summary Stats
    doc.setDrawColor(240);
    doc.line(10, 45, pageWidth - 10, 45);
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`মোট বাকি: ${formatCurrency(totals.baki)}`, 10, 55);
    doc.text(`মোট জমা: ${formatCurrency(totals.joma)}`, 10, 62);
    doc.text(`মোট আয়: ${formatCurrency(totals.income)}`, pageWidth - 10, 55, { align: 'right' });
    doc.text(`মোট ব্যয়: ${formatCurrency(totals.expense)}`, pageWidth - 10, 62, { align: 'right' });

    // Transactions Table
    const tableData: any[] = [];

    filteredData.cash.forEach(e => {
      tableData.push([
        formatDate(e.date),
        e.type === 'income' ? 'আয়' : 'ব্যয়',
        e.category,
        formatCurrency(e.amount),
        e.note || '-'
      ]);
    });

    filteredData.trans.forEach(t => {
      const customer = customers.find(c => c.id === t.customerId);
      tableData.push([
        formatDate(t.date),
        t.type === 'baki' ? 'বাকি' : 'জমা',
        customer?.name || 'Unknown',
        formatCurrency(t.amount),
        t.note || '-'
      ]);
    });

    // Sort table data by date
    tableData.sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime());

    autoTable(doc, {
      startY: 70,
      head: [['তারিখ', 'ধরন', 'ক্যাটাগরি/কাস্টমার', 'পরিমাণ', 'নোট']],
      body: tableData,
      headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 253, 250] },
      styles: { font: 'helvetica', fontSize: 8 },
      margin: { top: 70 }
    });

    // Footer with App Name
    const pageCount = (doc as any).internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text('Generated by বাকি খাতা প্রো', pageWidth / 2, doc.internal.pageSize.getHeight() - 10, { align: 'center' });
    }

    doc.save(`business_report_${dateRange.start}_to_${dateRange.end}.pdf`);
  };

  useEffect(() => {
    if (customers.length > 0 || cashEntries.length > 0) {
      setLoadingAi(true);
      const timer = setTimeout(() => {
        generateSmartInsights();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [customers.length, cashEntries.length, totals]);

  return (
    <div className="space-y-6 pb-10">
      {/* Header & Filters */}
      <div className="flex flex-col gap-4 px-1">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-800">রিপোর্ট ও এনালাইসিস</h2>
          <div className="flex gap-2">
            <button 
              onClick={downloadPDF}
              className="px-3 py-2 bg-emerald-50 text-emerald-600 rounded-xl flex items-center gap-2 text-xs font-bold hover:bg-emerald-100 transition-all"
            >
              <Download className="w-4 h-4" />
              PDF ডাউনলোড
            </button>
            <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Quick Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {[
            { id: 'today', label: 'আজ' },
            { id: 'week', label: 'সপ্তাহ' },
            { id: 'month', label: 'মাস' },
            { id: 'year', label: 'বছর' },
            { id: 'custom', label: 'তারিখ' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id as any)}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all",
                filterType === f.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
                  : "bg-white text-slate-500 border border-slate-100 hover:bg-slate-50"
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Date Range Picker (Only if custom or just to show) */}
        <div className={cn(
          "flex items-center gap-2 bg-white p-3 rounded-2xl border border-slate-100 shadow-sm transition-all",
          filterType !== 'custom' && "opacity-60 pointer-events-none"
        )}>
          <div className="flex-1 flex items-center gap-2 px-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input 
              type="date" 
              className="text-xs font-bold text-slate-600 outline-none bg-transparent w-full"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
            />
          </div>
          <div className="w-px h-4 bg-slate-200" />
          <div className="flex-1 flex items-center gap-2 px-2">
            <input 
              type="date" 
              className="text-xs font-bold text-slate-600 outline-none bg-transparent w-full"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
            />
          </div>
        </div>
      </div>

      {/* Smart Insights - MOVED TO TOP */}
      <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-[2.5rem] p-8 text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl" />
        <div className="flex items-center justify-between mb-6 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-md">
              <Sparkles className={cn("w-6 h-6", loadingAi && "animate-spin")} />
            </div>
            <h4 className="font-bold text-lg">স্মার্ট ইনসাইটস</h4>
          </div>
          <button 
            onClick={generateSmartInsights}
            disabled={loadingAi}
            className="text-xs font-bold bg-white/20 px-3 py-1.5 rounded-full hover:bg-white/30 transition-all border border-white/10"
          >
            রিফ্রেশ
          </button>
        </div>
        <div className="space-y-4 relative z-10">
          <p className="text-sm text-indigo-100 leading-relaxed whitespace-pre-wrap italic">
            "{aiInsights || 'আপনার ব্যবসার তথ্য বিশ্লেষণ করা হচ্ছে...'}"
          </p>
        </div>
      </div>

      {/* Summary Grid */}
      <div className="grid grid-cols-2 gap-4">
        {[
          { label: 'মোট বাকি', value: totals.baki, color: 'text-rose-600', icon: TrendingDown, bg: 'bg-rose-50' },
          { label: 'মোট জমা', value: totals.joma, color: 'text-emerald-600', icon: TrendingUp, bg: 'bg-emerald-50' },
          { label: 'মোট আয়', value: totals.income, color: 'text-indigo-600', icon: ArrowUpRight, bg: 'bg-indigo-50' },
          { label: 'মোট ব্যয়', value: totals.expense, color: 'text-amber-600', icon: ArrowDownRight, bg: 'bg-amber-50' },
        ].map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden group"
          >
            <div className={cn("absolute -right-2 -top-2 w-12 h-12 rounded-full opacity-10 group-hover:scale-110 transition-transform", item.bg)} />
            <div className="flex items-center gap-2 mb-2">
              <item.icon className={cn("w-3 h-3", item.color)} />
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{item.label}</p>
            </div>
            <p className={cn("text-xl font-black", item.color)}>{formatCurrency(item.value)}</p>
          </motion.div>
        ))}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm col-span-2 flex items-center justify-between"
        >
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">মোট সঞ্চয়</p>
            <p className="text-2xl font-black text-emerald-600">{formatCurrency(totals.savingsTotal)}</p>
          </div>
          <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center">
            <Wallet className="w-6 h-6 text-emerald-600" />
          </div>
        </motion.div>
      </div>

      {/* Trend Chart */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h4 className="font-bold text-slate-700 flex items-center gap-2">
            <Activity className="w-4 h-4 text-indigo-500" />
            আয় বনাম ব্যয়
          </h4>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-indigo-500" />
              <span className="text-[10px] font-bold text-slate-400">আয়</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-amber-500" />
              <span className="text-[10px] font-bold text-slate-400">ব্যয়</span>
            </div>
          </div>
        </div>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="date" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }}
                dy={10}
              />
              <YAxis hide />
              <ReTooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px', fontWeight: 'bold' }}
              />
              <Area type="monotone" dataKey="income" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
              <Area type="monotone" dataKey="expense" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorExpense)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Transaction Breakdown Chart */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h4 className="font-bold text-slate-700 flex items-center gap-2">
            <PieChartIcon className="w-4 h-4 text-emerald-500" />
            লেনদেনের ধরন
          </h4>
        </div>
        <div className="grid grid-cols-2 gap-6 items-center">
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={60}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <ReTooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3">
            {pieData.map((item, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-xs font-bold text-slate-500">{item.name}</span>
                </div>
                <span className="text-xs font-black text-slate-700">{formatCurrency(item.value)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Cash vs Credit Progress Bar */}
        <div className="mt-8 pt-6 border-t border-slate-100">
          <div className="flex items-center justify-between mb-3">
            <h5 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5 text-slate-400" />
              নগদ আয় বনাম বাকি
            </h5>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Cash vs Credit</span>
          </div>
          
          <div className="flex items-center justify-between text-xs font-black mb-2">
            <span className="text-indigo-600">নগদ আয়: {totals.income + totals.baki > 0 ? Math.round((totals.income / (totals.income + totals.baki)) * 100) : 0}%</span>
            <span className="text-rose-600">বাকি: {totals.income + totals.baki > 0 ? Math.round((totals.baki / (totals.income + totals.baki)) * 100) : 0}%</span>
          </div>
          
          <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex">
            <div 
              className="h-full bg-indigo-500 transition-all duration-1000" 
              style={{ width: `${totals.income + totals.baki > 0 ? (totals.income / (totals.income + totals.baki)) * 100 : 0}%` }} 
            />
            <div 
              className="h-full bg-rose-500 transition-all duration-1000" 
              style={{ width: `${totals.income + totals.baki > 0 ? (totals.baki / (totals.income + totals.baki)) * 100 : 0}%` }} 
            />
          </div>
        </div>
      </div>

      {/* Top Customers Chart */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <h4 className="font-bold text-slate-700 mb-6 flex items-center gap-2">
          <Target className="w-4 h-4 text-rose-500" />
          শীর্ষ ৫ বকেয়া কাস্টমার
        </h4>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topCustomers} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
              <XAxis type="number" hide />
              <YAxis 
                dataKey="name" 
                type="category" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: '#64748b', fontWeight: 700 }}
                width={80}
              />
              <ReTooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <ReBar dataKey="baki" radius={[0, 10, 10, 0]}>
                {topCustomers.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 0 ? '#f43f5e' : '#fda4af'} />
                ))}
              </ReBar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Risky Customers List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h4 className="font-bold text-slate-700">ঝুঁকিপূর্ণ কাস্টমার</h4>
          <div className="px-2 py-1 bg-rose-50 text-rose-600 rounded-lg text-[10px] font-black uppercase tracking-wider">
            সতর্কতা
          </div>
        </div>
        {customers.filter(c => c.totalBalance > (user?.debtLimits?.red || 10000)).length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-dashed border-slate-200">
            <p className="text-slate-400 text-sm">সব কাস্টমার নিরাপদ সীমার মধ্যে আছেন</p>
          </div>
        ) : (
          customers
            .filter(c => c.totalBalance > (user?.debtLimits?.red || 10000))
            .map(c => (
              <div key={c.id} className="bg-white p-4 rounded-2xl border border-rose-100 shadow-sm flex items-center justify-between group hover:bg-rose-50/30 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center font-bold shadow-sm">
                    {c.name[0]}
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-800 text-sm">{c.name}</h5>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">{c.phone}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-rose-600">{formatCurrency(c.totalBalance)}</p>
                  <p className="text-[10px] text-rose-400 font-bold uppercase">বাকি</p>
                </div>
              </div>
            ))
        )}
      </div>
    </div>
  );
};
