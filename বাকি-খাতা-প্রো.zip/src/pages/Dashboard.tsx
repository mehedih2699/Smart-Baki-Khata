import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Filter, 
  Eye, 
  EyeOff, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw,
  UserPlus,
  Phone,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Plus,
  Minus,
  X,
  Loader2,
  Check,
  Edit2,
  Trash2,
  Bell,
  Calculator,
  MapPin,
  Calendar,
  ArrowUpDown
} from 'lucide-react';
import { collection, query, where, onSnapshot, orderBy, limit, addDoc, serverTimestamp, getDocs, updateDoc, doc, writeBatch, deleteField } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Customer, Transaction, CashEntry } from '../types';
import { formatCurrency, cn, formatDate, parseNumber } from '../lib/utils';
import { APP_VERSION } from '../constants';
import { toast } from 'react-hot-toast';
import { getGeminiAI } from '../lib/gemini';
import { ConfirmModal } from '../components/ConfirmModal';
import { SmartCalculator } from '../components/SmartCalculator';
import { AIAdvisorBanner } from '../components/AIAdvisorBanner';
import { BusinessData } from '../services/aiAdvisor';


export const Dashboard: React.FC<{ onSelectCustomer: (id: string, action?: 'baki' | 'joma') => void }> = ({ onSelectCustomer }) => {
  const { user, systemSettings, isAdmin } = useAuth();
  const [showUpdateBanner, setShowUpdateBanner] = useState(true);
  const [showBalance, setShowBalance] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [isStatsExpanded, setIsStatsExpanded] = useState(false);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [monthlyTransactions, setMonthlyTransactions] = useState<Transaction[]>([]);
  const [cashEntries, setCashEntries] = useState<CashEntry[]>([]);
  const [savings, setSavings] = useState<any[]>([]);
  const [loanTransactions, setLoanTransactions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [activeSort, setActiveSort] = useState<'recent' | 'highest' | 'lowest'>('recent');
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleShowBalance = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setShowBalance(true);
    timerRef.current = setTimeout(() => {
      setShowBalance(false);
    }, 4000);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: showCalculator } 
    }));
  }, [showCalculator]);

  useEffect(() => {
    const handleCloseCalc = () => setShowCalculator(false);
    window.addEventListener('close-calculator', handleCloseCalc);
    return () => window.removeEventListener('close-calculator', handleCloseCalc);
  }, []);

  const isUpdateAvailable = systemSettings?.latestVersion && (() => {
    const latest = systemSettings.latestVersion.split('.').map(Number);
    const current = APP_VERSION.split('.').map(Number);
    for (let i = 0; i < Math.max(latest.length, current.length); i++) {
      const v1 = latest[i] || 0;
      const v2 = current[i] || 0;
      if (v1 > v2) return true;
      if (v1 < v2) return false;
    }
    return false;
  })();
  const isForceUpdate = systemSettings?.forceUpdate && isUpdateAvailable && !isAdmin;

  useEffect(() => {
    if (!user) return;

    const qCustomers = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubscribeCustomers = onSnapshot(qCustomers, (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'customers'));

    const qTransactions = query(collection(db, 'transactions'), where('ownerUid', '==', user.uid), orderBy('date', 'desc'), limit(10));
    const unsubscribeTransactions = onSnapshot(qTransactions, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'transactions'));

    const firstDayOfMonth = new Date();
    firstDayOfMonth.setDate(1);
    firstDayOfMonth.setHours(0, 0, 0, 0);

    const qMonthly = query(
      collection(db, 'transactions'),
      where('ownerUid', '==', user.uid),
      where('date', '>=', firstDayOfMonth.toISOString()),
      orderBy('date', 'desc')
    );
    const unsubscribeMonthly = onSnapshot(qMonthly, (snapshot) => {
      setMonthlyTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'monthly-transactions'));

    const qCash = query(collection(db, 'cashEntries'), where('ownerUid', '==', user.uid));
    const unsubscribeCash = onSnapshot(qCash, (snapshot) => {
      setCashEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashEntry)));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cashEntries'));

    const qSavings = query(collection(db, 'savings'), where('ownerUid', '==', user.uid));
    const unsubscribeSavings = onSnapshot(qSavings, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'savings'));

    const qLoans = query(collection(db, 'loanTransactions'), where('ownerUid', '==', user.uid));
    const unsubscribeLoans = onSnapshot(qLoans, (snapshot) => {
      setLoanTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'loanTransactions'));

    const handleOpenAddCustomer = () => setShowAddCustomer(true);
    window.addEventListener('open-add-customer', handleOpenAddCustomer);

    return () => {
      unsubscribeCustomers();
      unsubscribeTransactions();
      unsubscribeMonthly();
      unsubscribeCash();
      unsubscribeSavings();
      unsubscribeLoans();
      window.removeEventListener('open-add-customer', handleOpenAddCustomer);
    };
  }, [user]);

  const totalBaki = customers.reduce((acc, curr) => acc + (curr.totalBalance > 0 ? curr.totalBalance : 0), 0);
  const totalJoma = customers.reduce((acc, curr) => acc + (curr.totalBalance < 0 ? Math.abs(curr.totalBalance) : 0), 0);
  
  const now = new Date();
  
  const isToday = (dateString: string) => {
    const d = new Date(dateString);
    return d.getDate() === now.getDate() &&
           d.getMonth() === now.getMonth() &&
           d.getFullYear() === now.getFullYear();
  };
  
  const todayTransactions = transactions.filter(t => isToday(t.date));
  const todayBaki = todayTransactions.filter(t => t.type === 'baki').reduce((acc, curr) => acc + curr.amount, 0);
  const todayJoma = todayTransactions.filter(t => t.type === 'joma').reduce((acc, curr) => acc + curr.amount, 0);

  const todayCash = cashEntries.filter(e => isToday(e.date));
  const todayIncome = todayCash.filter(e => e.type === 'income').reduce((acc, curr) => acc + curr.amount, 0);
  const todayExpense = todayCash.filter(e => e.type === 'expense').reduce((acc, curr) => acc + curr.amount, 0);

  const todaySavings = savings.filter(s => isToday(s.date)).reduce((acc, curr) => acc + curr.amount, 0);
  
  const todayLoanTrans = loanTransactions.filter(l => isToday(l.date));
  const todayLoanGiven = todayLoanTrans.filter(l => l.type === 'loan').reduce((acc, curr) => acc + curr.amount, 0);
  const todayLoanPaid = todayLoanTrans.filter(l => l.type === 'payment').reduce((acc, curr) => acc + curr.amount, 0);

  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [showBudgetModal, setShowBudgetModal] = useState(false);
  const [editBudget, setEditBudget] = useState({ amount: '', date: '' });
  const [newCustomer, setNewCustomer] = useState({ 
    name: '', 
    phone: '', 
    address: '', 
    tag: user?.customerCategories?.[0] || 'New', 
    profilePic: '' 
  });
  const [addingCustomer, setAddingCustomer] = useState(false);
  const [displayLimit, setDisplayLimit] = useState(50);

  // Reset display limit when search or filter changes
  useEffect(() => {
    setDisplayLimit(50);
  }, [searchQuery, activeFilter, activeSort]);

  const currentMonth = new Date().toISOString().slice(0, 7);
  const monthlyExpense = cashEntries
    .filter(e => e.type === 'expense' && e.category !== 'ট্রান্সফার' && e.category !== 'সঞ্চয়' && e.date.startsWith(currentMonth))
    .reduce((acc, curr) => acc + curr.amount, 0);
  const budgetProgress = user?.monthlyBudget ? (monthlyExpense / user.monthlyBudget) * 100 : 0;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast.error('ছবি ১ মেগাবাইটের কম হতে হবে');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewCustomer(prev => ({ ...prev, profilePic: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (editingCustomer) {
      setNewCustomer({
        name: editingCustomer.name || '',
        phone: editingCustomer.phone || '',
        address: editingCustomer.address || '',
        tag: editingCustomer.tag,
        profilePic: editingCustomer.profilePic || ''
      });
    } else {
      setNewCustomer({ 
        name: '', 
        phone: '', 
        address: '', 
        tag: user?.customerCategories?.[0] || 'New', 
        profilePic: '' 
      });
    }
  }, [editingCustomer, user?.customerCategories]);

  const updateProfile = async (data: any) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), data);
    } catch (error) {
      console.error('Update Profile Error:', error);
      throw error;
    }
  };

  const handleSaveBudget = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const updates: any = {};
      if (editBudget.amount) updates.monthlyBudget = Number(editBudget.amount);
      else updates.monthlyBudget = deleteField();
      
      if (editBudget.date) updates.monthlyBudgetDate = editBudget.date;
      else updates.monthlyBudgetDate = deleteField();

      await updateProfile(updates);
      toast.success('মাসিক বাজেট আপডেট করা হয়েছে');
      setShowBudgetModal(false);
    } catch {
      toast.error('বাজেট আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handleAddCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.name || !user) return;
    
    const isEditing = !!editingCustomer;
    const customerData = {
      name: newCustomer.name || '',
      phone: newCustomer.phone || '',
      address: newCustomer.address || '',
      tag: newCustomer.tag || user?.customerCategories?.[0] || 'New',
      profilePic: newCustomer.profilePic || '',
      ownerUid: user.uid,
      createdAt: isEditing ? editingCustomer.createdAt : new Date().toISOString()
    };

    // Optimistic UI: Close modal and reset state immediately
    setShowAddCustomer(false);
    setEditingCustomer(null);
    setNewCustomer({ 
      name: '', 
      phone: '', 
      address: '', 
      tag: user?.customerCategories?.[0] || 'New', 
      profilePic: '' 
    });
    toast.success(isEditing ? 'কাস্টমার আপডেট করা হয়েছে' : 'কাস্টমার যোগ করা হয়েছে');

    try {
      if (isEditing && editingCustomer) {
        await updateDoc(doc(db, 'customers', editingCustomer.id), customerData);
      } else {
        await addDoc(collection(db, 'customers'), {
          ...customerData,
          totalBalance: 0
        });
      }
    } catch (error) {
      console.error('Customer Save Error:', error);
      handleFirestoreError(error, OperationType.WRITE, isEditing ? `customers/${editingCustomer?.id}` : 'customers');
    }
  };

  const handleDeleteCustomer = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setConfirmDelete(id);
  };

  const executeDeleteCustomer = async () => {
    if (!confirmDelete) return;
    const id = confirmDelete;
    
    // Optimistic UI
    setConfirmDelete(null);
    toast.success('কাস্টমার মুছে ফেলা হয়েছে');

    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'customers', id));
      
      const q = query(
        collection(db, 'transactions'), 
        where('ownerUid', '==', user.uid),
        where('customerId', '==', id)
      );
      const snapshot = await getDocs(q);
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `customers/${id}`);
    }
  };

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = String(c.name || '').toLowerCase().includes(searchQuery.toLowerCase()) || String(c.phone || '').includes(searchQuery);
    const matchesFilter = activeFilter === 'All' || c.tag === activeFilter;
    return matchesSearch && matchesFilter;
  }).sort((a, b) => {
    if (activeSort === 'highest') return b.totalBalance - a.totalBalance;
    if (activeSort === 'lowest') return a.totalBalance - b.totalBalance;
    // recent
    const aTime = a.updatedAt ? new Date(a.updatedAt).getTime() : a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const bTime = b.updatedAt ? new Date(b.updatedAt).getTime() : b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return bTime - aTime;
  });

  const closeCalculator = React.useCallback(() => {
    setShowCalculator(false);
  }, []);

  const businessData: BusinessData = {
    totalBaki,
    totalJoma,
    todayIncome,
    todayExpense,
    todayBaki,
    todayJoma,
    monthlyExpense,
    monthlyBudget: user?.monthlyBudget || 0,
    customerCount: customers.length
  };

  const getDaysRemainingText = (dateString?: string) => {
    if (!dateString) return null;
    const target = new Date(dateString);
    target.setHours(23, 59, 59, 999);
    const now = new Date();
    const diff = target.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    
    if (days > 0) return `${days} দিন বাকি`;
    if (days === 0) return `আজ শেষ দিন`;
    return `${Math.abs(days)} দিন পেরিয়েছে`;
  };

  return (
    <div className="space-y-6">
      {/* Global Announcement */}
      <AnimatePresence>
        {systemSettings?.announcement && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-2xl flex items-start gap-3 shadow-sm mb-2 overflow-hidden"
          >
            <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4 text-amber-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold text-amber-900">সিস্টেম নোটিশ</p>
              <p className="text-xs text-amber-700 mt-0.5">{systemSettings.announcement}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Update Banner */}
      <AnimatePresence>
        {isUpdateAvailable && showUpdateBanner && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-emerald-600 text-white p-4 rounded-2xl flex items-center justify-between shadow-lg shadow-emerald-100 mb-2 overflow-hidden"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                <RefreshCw className="w-5 h-5 animate-spin" />
              </div>
              <div>
                <p className="text-sm font-bold">নতুন আপডেট পাওয়া গেছে! (v{systemSettings.latestVersion})</p>
                <p className="text-[10px] text-emerald-100 line-clamp-1">{systemSettings.updateMessage || 'অ্যাপটি আপডেট করে নতুন ফিচারগুলো উপভোগ করুন।'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <a 
                href={systemSettings.updateLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-4 py-2 bg-white text-emerald-600 rounded-xl text-xs font-bold hover:bg-emerald-50 transition-all"
              >
                আপডেট করুন
              </a>
              {!isForceUpdate && (
                <button 
                  onClick={() => setShowUpdateBanner(false)}
                  className="p-2 hover:bg-white/20 rounded-xl transition-all"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Force Update Modal */}
      <AnimatePresence>
        {isForceUpdate && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white w-full max-w-md rounded-[2.5rem] p-8 text-center shadow-2xl"
            >
              <div className="w-20 h-20 bg-emerald-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <RefreshCw className="w-10 h-10 text-emerald-600 animate-spin" />
              </div>
              <h3 className="text-2xl font-black text-slate-800 mb-2">আপডেট প্রয়োজন!</h3>
              <p className="text-slate-500 mb-8 font-medium">
                অ্যাপটির নতুন ভার্সন (v{systemSettings.latestVersion}) রিলিজ হয়েছে। অ্যাপটি ব্যবহার চালিয়ে যেতে অবশ্যই আপডেট করতে হবে।
              </p>
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 mb-8 text-left">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">নতুন কি কি আছে:</p>
                <p className="text-sm text-slate-600 leading-relaxed">{systemSettings.updateMessage || 'পারফরম্যান্স ইমপ্রুভমেন্ট এবং বাগ ফিক্স করা হয়েছে।'}</p>
              </div>
              <button
                onClick={() => window.open(systemSettings.updateLink, '_blank')}
                className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-6 h-6" />
                এখনই আপডেট করুন
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <motion.div 
        id="tour-balance-card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden bg-white/30 backdrop-blur-3xl rounded-[2.5rem] p-6 sm:p-8 text-slate-800 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] border border-white/40"
      >
        {/* iPhone Style Glassmorphism Background Elements */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-gradient-to-br from-emerald-400/20 to-teal-400/20 rounded-full blur-[60px]" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-gradient-to-tr from-blue-400/20 to-indigo-400/20 rounded-full blur-[60px]" />
        
        <div className="relative z-10 space-y-6">
          {/* Main Balance Header */}
          <div className="flex items-center justify-between gap-4">
            <div className="space-y-1 flex-1">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                <p className="text-slate-600 text-xs font-black uppercase tracking-[0.1em]">মোট পাওনা (বাকি)</p>
              </div>
              <div className="flex items-center gap-4">
                <div 
                  onClick={handleShowBalance}
                  className="relative h-10 w-48 bg-white/40 backdrop-blur-md rounded-full flex items-center p-1 cursor-pointer overflow-hidden shadow-sm border border-white/40 group"
                >
                  {/* The sliding coin/icon */}
                  <motion.div
                    animate={{ x: showBalance ? 148 : 0 }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    className="absolute z-10 w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center shadow-lg"
                  >
                    <span className="text-white font-black text-sm">৳</span>
                  </motion.div>
                  
                  {/* The text/balance area */}
                  <div className="flex-1 flex items-center justify-center">
                    <AnimatePresence mode="wait">
                      {showBalance ? (
                        <motion.div
                          key="balance"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="flex flex-col items-center"
                        >
                          <span className="text-emerald-800 font-black text-base tracking-tight">
                            {formatCurrency(totalBaki)}
                          </span>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="tap"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex flex-col items-center ml-4"
                        >
                          <span className="text-emerald-700 font-black text-sm tracking-tight whitespace-nowrap">
                            ব্যালেন্স দেখতে ট্যাপ করুন
                          </span>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowCalculator(true);
                    }}
                    className="p-2 bg-white/40 hover:bg-white/60 rounded-xl transition-all backdrop-blur-md border border-white/40 group shadow-sm"
                    title="ক্যালকুলেটর"
                  >
                    <Calculator className="w-5 h-5 text-slate-600 transition-colors" />
                  </button>
                  <button 
                    onClick={() => setIsStatsExpanded(!isStatsExpanded)}
                    className="p-2 bg-white/40 hover:bg-white/60 rounded-xl transition-all backdrop-blur-md border border-white/40 group shadow-sm"
                  >
                    {isStatsExpanded ? (
                      <ChevronUp className="w-5 h-5 text-slate-600" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-600" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Grid Inside Card */}
          <AnimatePresence>
            {isStatsExpanded && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: 'easeInOut' }}
                className="overflow-hidden"
              >
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4 pt-2">
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-emerald-700 transition-colors">আজকের বাকি</p>
                    <p className="text-sm sm:text-base font-black text-emerald-700">+{formatCurrency(todayBaki)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-blue-700 transition-colors">আজকের জমা</p>
                    <p className="text-sm sm:text-base font-black text-blue-700">-{formatCurrency(todayJoma)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-amber-700 transition-colors">আজকের আয়</p>
                    <p className="text-sm sm:text-base font-black text-amber-700">{formatCurrency(todayIncome)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-rose-700 transition-colors">আজকের ব্যয়</p>
                    <p className="text-sm sm:text-base font-black text-rose-700">{formatCurrency(todayExpense)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-teal-700 transition-colors">আজকের সঞ্চয়</p>
                    <p className="text-sm sm:text-base font-black text-teal-700">{formatCurrency(todaySavings)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-indigo-700 transition-colors">মোট জমা</p>
                    <p className="text-sm sm:text-base font-black text-indigo-700">{formatCurrency(totalJoma)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-orange-700 transition-colors">আজ বাকি নেওয়া</p>
                    <p className="text-sm sm:text-base font-black text-orange-700">{formatCurrency(todayLoanGiven)}</p>
                  </div>
                  <div className="bg-white/40 rounded-2xl p-3 border border-white/40 backdrop-blur-md hover:bg-white/60 transition-all group shadow-sm">
                    <p className="text-slate-600 text-[10px] uppercase font-black tracking-wider mb-1 group-hover:text-emerald-700 transition-colors">বাকি পরিশোধ</p>
                    <p className="text-sm sm:text-base font-black text-emerald-700">{formatCurrency(todayLoanPaid)}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {/* Monthly Budget Progress */}
          {user?.monthlyBudget ? (
            <div className="pt-4 border-t border-slate-200/50 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 font-black uppercase tracking-wider">মাসিক বাজেট প্রগ্রেস</p>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-black text-slate-800">{formatCurrency(monthlyExpense)} / {formatCurrency(user.monthlyBudget)}</p>
                  <button onClick={() => {
                        setEditBudget({ amount: user.monthlyBudget?.toString() || '', date: user.monthlyBudgetDate || '' });
                        setShowBudgetModal(true);
                  }} className="p-1.5 hover:bg-slate-200 rounded-lg transition-colors">
                     <Edit2 className="w-3.5 h-3.5 text-slate-500" />
                  </button>
                </div>
              </div>
              <div className="h-2 bg-slate-200/50 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(budgetProgress, 100)}%` }}
                  className={cn(
                    "h-full rounded-full transition-all",
                    budgetProgress > 90 ? "bg-rose-500" : budgetProgress > 70 ? "bg-amber-500" : "bg-emerald-500"
                  )}
                />
              </div>
              <div className="flex justify-between items-center text-xs font-black">
                <p className={budgetProgress > 100 ? "text-rose-500" : "text-slate-500"}>
                  {budgetProgress > 100 ? 'আপনি বাজেট ছাড়িয়ে গেছেন!' : `${(100 - budgetProgress).toFixed(1)}% বাজেট বাকি আছে`}
                </p>
                {user?.monthlyBudgetDate && (
                   <div className="text-right flex flex-col items-end">
                     <p className="text-emerald-600 flex items-center gap-1">
                       <Calendar className="w-3 h-3" />
                       {formatDate(user.monthlyBudgetDate)}
                     </p>
                     <p className={cn(
                        "mt-0.5 text-[10px]",
                        (getDaysRemainingText(user.monthlyBudgetDate)?.includes('পেরিয়েছে') || getDaysRemainingText(user.monthlyBudgetDate)?.includes('শেষ')) 
                          ? "text-rose-500" 
                          : "text-slate-500"
                     )}>
                       {getDaysRemainingText(user.monthlyBudgetDate)}
                     </p>
                   </div>
                )}
              </div>
            </div>
          ) : (
            <div className="pt-4 border-t border-slate-200/50">
               <button onClick={() => {
                  setEditBudget({ amount: '', date: '' });
                  setShowBudgetModal(true);
               }} className="w-full py-2 bg-emerald-50 text-emerald-600 rounded-xl font-bold text-xs uppercase tracking-wider flex justify-center items-center gap-1.5 border border-emerald-100 hover:bg-emerald-100 transition-colors">
                 <Edit2 className="w-3.5 h-3.5" />
                 মাসিক বাজেট সেট করুন
               </button>
            </div>
          )}
        </div>
      </motion.div>

      {/* AI Advisor Banner */}
      <div id="tour-ai-advisor">
        <AIAdvisorBanner data={businessData} />
      </div>

      {/* Search & Filter */}
      <div id="tour-search-bar" className="space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="কাস্টমার খুঁজুন (নাম বা ফোন)"
            className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {['All', ...(user?.customerCategories || ['New', 'VIP', 'Regular', 'Risky'])].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all",
                activeFilter === filter 
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-100" 
                  : "bg-white text-slate-600 border border-slate-200 hover:border-emerald-200"
              )}
            >
              {filter === 'All' ? 'সব' : filter}
            </button>
          ))}
        </div>
      </div>

      {/* Customer List */}
      <div id="tour-customer-list" className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <h4 className="font-bold text-slate-700">কাস্টমার তালিকা ({filteredCustomers.length})</h4>
            <div className="relative">
              <button 
                onClick={() => setShowSortMenu(!showSortMenu)}
                className="p-1.5 hover:bg-slate-200 rounded-lg transition-colors text-slate-500"
                title="সাজান"
              >
                <ArrowUpDown className="w-4 h-4" />
              </button>
              {showSortMenu && (
                <>
                   <div className="fixed inset-0 z-40" onClick={() => setShowSortMenu(false)}></div>
                   <div className="absolute top-full left-0 mt-1 w-40 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50">
                     <button
                       onClick={() => { setActiveSort('recent'); setShowSortMenu(false); }}
                       className={cn("w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50", activeSort === 'recent' && "font-bold text-emerald-600 bg-emerald-50/50")}
                     >রিসেন্ট ব্যবহৃত</button>
                     <button
                       onClick={() => { setActiveSort('highest'); setShowSortMenu(false); }}
                       className={cn("w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50", activeSort === 'highest' && "font-bold text-emerald-600 bg-emerald-50/50")}
                     >বেশি বকেয়া</button>
                     <button
                       onClick={() => { setActiveSort('lowest'); setShowSortMenu(false); }}
                       className={cn("w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50", activeSort === 'lowest' && "font-bold text-emerald-600 bg-emerald-50/50")}
                     >কম বকেয়া</button>
                   </div>
                </>
              )}
            </div>
          </div>
          <button 
            onClick={() => setShowAddCustomer(true)}
            className="flex items-center gap-2.5 px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-100 hover:shadow-emerald-200 transition-all active:scale-95 group relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <UserPlus className="w-4 h-4 group-hover:scale-110 transition-transform" />
            <span className="uppercase tracking-wide">কাস্টমার যোগ করুন</span>
          </button>
        </div>

        {filteredCustomers.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-200">
            <p className="text-slate-400">কোন কাস্টমার পাওয়া যায়নি</p>
          </div>
        ) : (
          <>
            {filteredCustomers.slice(0, displayLimit).map((customer) => (
              <motion.div
                key={customer.id}
                whileTap={{ scale: 0.98 }}
                onClick={() => onSelectCustomer(customer.id)}
                className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 group cursor-pointer"
              >
                {/* avatar and name container */}
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-12 h-12 shrink-0 rounded-xl flex items-center justify-center font-bold text-lg relative overflow-hidden",
                    customer.totalBalance > (user?.debtLimits?.red || 1000) ? "bg-rose-50 text-rose-600" : 
                    customer.totalBalance > (user?.debtLimits?.orange || 1500) ? "bg-amber-50 text-amber-600" : 
                    customer.totalBalance > (user?.debtLimits?.green || 500) ? "bg-emerald-50 text-emerald-600" : "bg-slate-50 text-slate-600"
                  )}>
                    {customer.profilePic ? (
                      <img 
                        src={customer.profilePic} 
                        alt={customer.name} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <img 
                        src="/icon.png" 
                        alt="App Icon" 
                        className="w-full h-full object-cover opacity-40"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                          const parent = (e.target as HTMLImageElement).parentElement;
                          if (parent) parent.innerText = customer.name[0];
                        }}
                      />
                    )}
                    {customer.tag && systemSettings?.features?.customerTags !== false && (
                      <div className={cn(
                        "absolute -top-1 -right-1 px-1.5 py-0.5 rounded-md text-[8px] font-black uppercase tracking-tighter border-2 border-white",
                        customer.tag === 'VIP' ? "bg-amber-400 text-white" :
                        customer.tag === 'Risky' || customer.totalBalance > (user?.debtLimits?.red || 1000) ? "bg-rose-500 text-white" : 
                        customer.tag === 'New' ? "bg-blue-500 text-white" : "bg-emerald-500 text-white"
                      )}>
                        {customer.totalBalance > (user?.debtLimits?.red || 1000) ? 'Risky' : customer.tag}
                      </div>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                       <h5 className="font-bold text-slate-800 truncate">{customer.name}</h5>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-600 font-medium truncate">
                      <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="truncate">{customer.phone}</span>
                    </div>
                    {customer.dueDate && (
                      <div className="flex items-center gap-1 text-[10px] font-bold mt-1 text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full w-fit">
                        <Calendar className="w-3 h-3" />
                        পরিশোধ: {formatDate(customer.dueDate)}
                      </div>
                    )}
                  </div>
                </div>

                {/* balance and buttons container */}
                <div className="flex items-center justify-between sm:justify-end gap-2 sm:gap-4 border-t sm:border-0 border-slate-100 pt-3 sm:pt-0">
                  <div className="text-left sm:text-right">
                    <p className={cn(
                      "font-black text-lg",
                      customer.totalBalance > 0 ? "text-rose-700" : "text-emerald-700"
                    )}>
                      {formatCurrency(Math.abs(customer.totalBalance))}
                    </p>
                    <p className="text-xs text-slate-600 uppercase tracking-wider font-black">
                      {customer.totalBalance > 0 ? 'বাকি' : 'জমা'}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 transition-all">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectCustomer(customer.id, 'baki');
                      }}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                      title="বাকি যোগ করুন"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectCustomer(customer.id, 'joma');
                      }}
                      className="p-1.5 text-emerald-500 hover:bg-emerald-50 rounded-lg transition-all"
                      title="জমা নিন"
                    >
                      <Minus className="w-5 h-5" />
                    </button>
                    <div className="w-px h-6 bg-slate-200 mx-1"></div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingCustomer(customer);
                        setShowAddCustomer(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
                      title="এডিট"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={(e) => handleDeleteCustomer(e, customer.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                      title="ডিলিট"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
            
            {filteredCustomers.length > displayLimit && (
              <button 
                onClick={() => setDisplayLimit(prev => prev + 50)}
                className="w-full py-3 mt-2 bg-slate-100 text-slate-500 rounded-xl font-bold text-sm hover:bg-slate-200 transition-colors"
               >
                 আরও দেখুন ({filteredCustomers.length - displayLimit} জন বাকি আছে)
              </button>
            )}
          </>
        )}
      </div>

      {/* Add Customer Modal */}
      <ConfirmModal
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={executeDeleteCustomer}
        title="কাস্টমার মুছুন"
        message="আপনি কি নিশ্চিতভাবে এই কাস্টমারকে মুছতে চান? তার সকল লেনদেনও মুছে যাবে।"
      />

      <AnimatePresence>
        {showAddCustomer && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddCustomer(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] p-6 sm:p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">
                  {editingCustomer ? 'কাস্টমার এডিট করুন' : 'নতুন কাস্টমার যোগ করুন'}
                </h3>
                <button onClick={() => {
                  setShowAddCustomer(false);
                  setEditingCustomer(null);
                }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddCustomer} className="space-y-4">
                <div className="flex flex-col items-center gap-4 mb-4">
                  <div className="relative group">
                    <div className="w-24 h-24 bg-slate-100 rounded-[2rem] flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300 group-hover:border-emerald-500 transition-all">
                      {newCustomer.profilePic ? (
                        <img src={newCustomer.profilePic} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <UserPlus className="w-8 h-8 text-slate-400" />
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">প্রোফাইল ছবি সেট করুন</p>
                </div>

                <input
                  type="text"
                  placeholder="কাস্টমারের নাম"
                  required
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ফোন নম্বর"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={newCustomer.phone}
                  onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={newCustomer.address}
                  onChange={(e) => setNewCustomer({ ...newCustomer, address: e.target.value })}
                />

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">ক্যাটাগরি সিলেক্ট করুন</label>
                  <div className="flex flex-wrap gap-2">
                    {(user?.customerCategories || ['New', 'VIP', 'Regular', 'Risky']).map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setNewCustomer({ ...newCustomer, tag: cat })}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-bold border transition-all",
                          newCustomer.tag === cat 
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-100" 
                            : "bg-slate-50 text-slate-600 border-slate-100 hover:bg-slate-100"
                        )}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={addingCustomer}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  {addingCustomer ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      {editingCustomer ? 'আপডেট করুন' : 'যোগ করুন'}
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Budget Modal */}
      <AnimatePresence>
        {showBudgetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowBudgetModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-slate-800">মাসিক বাজেট সেট করুন</h3>
                <button onClick={() => setShowBudgetModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSaveBudget} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">লক্ষ্যমাত্রা (৳)</label>
                  <input
                    type="number"
                    placeholder="বাজেট (উদা: ১০০০০)"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-medium"
                    value={editBudget.amount}
                    onChange={(e) => setEditBudget({ ...editBudget, amount: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">কত তারিখের মধ্যে? (ঐচ্ছিক)</label>
                  <input
                    type="date"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-medium"
                    value={editBudget.date}
                    onChange={(e) => setEditBudget({ ...editBudget, date: e.target.value })}
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const updates: any = {};
                        updates.monthlyBudget = deleteField();
                        updates.monthlyBudgetDate = deleteField();
                        await updateProfile(updates);
                        toast.success('বাজেট মুছে ফেলা হয়েছে!');
                        setShowBudgetModal(false);
                      } catch {
                         toast.error('মুছতে সমস্যা হয়েছে');
                      }
                    }}
                    className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
                  >
                    মুছে ফেলুন
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-200 transition-all"
                  >
                    সেভ করুন
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCalculator && (
          <SmartCalculator 
            onClose={closeCalculator} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};

