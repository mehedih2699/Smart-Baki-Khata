export interface UserProfile {
  uid: string;
  ownerName: string;
  shopName: string;
  shopAddress: string;
  email: string;
  pin?: string;
  pinEnabled?: boolean;
  shopLogo?: string;
  incomeCategories?: string[];
  expenseCategories?: string[];
  monthlyBudget?: number;
  monthlyBudgetDate?: string;
  savingsGoal?: number;
  savingsGoalDate?: string;
  quickButtons?: number[];
  quickItems?: string[];
  quickItemsCustomer?: string[];
  quickItemsCash?: string[];
  quickItemsSupplier?: string[];
  quickItemsCalculator?: string[];
  quickItemsNotes?: string[];
  inventoryNames?: string[];
  customerCategories?: string[];
  showInventory?: boolean;
  darkMode?: boolean;
  debtLimits?: {
    green: number;
    orange: number;
    red: number;
  };
  blocked?: boolean;
  role?: string;
  hasSeenTour?: boolean;
  createdAt?: string;
}

export interface AppConfig {
  report: boolean;
  settings: boolean;
  notes: boolean;
  privacy: boolean;
  feedback: boolean;
  cash: boolean;
  savings: boolean;
  loan: boolean;
}

export interface AppUpdate {
  version: string;
  message: string;
  link: string;
  enabled: boolean;
}

export interface AppNotice {
  id: string;
  message: string;
  enabled: boolean;
  date: string;
}

export interface AdminContact {
  link: string;
  message: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  tag: string;
  totalBalance: number;
  ownerUid: string;
  createdAt?: string;
  updatedAt?: string;
  profilePic?: string;
  dueDate?: string;
  dueAmount?: number;
}

export interface Transaction {
  id: string;
  customerId: string;
  amount: number;
  type: 'baki' | 'joma';
  category?: string;
  note: string;
  date: string;
  ownerUid: string;
  linkedItemId?: string;
  linkedStockRemoved?: number;
  linkedProfitEarned?: number;
}

export interface CashEntry {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  categoryIcon?: string;
  paymentMethod: 'Cash' | 'Bank' | 'Mobile Banking' | 'Personal';
  note: string;
  voucherNo?: string;
  date: string;
  ownerUid: string;
  linkedItemId?: string;
  linkedStockRemoved?: number;
  linkedProfitEarned?: number;
}

export interface Savings {
  id: string;
  amount: number;
  note: string;
  date: string;
  ownerUid: string;
}

export interface Loaner {
  id: string;
  name: string;
  phone: string;
  address: string;
  totalTaken: number;
  totalPaid: number;
  dueDate?: string;
  dueAmount?: number;
  ownerUid: string;
  profilePic?: string;
}

export interface LoanTransaction {
  id: string;
  loanerId: string;
  amount: number;
  type: 'loan' | 'payment';
  category?: string;
  note: string;
  date: string;
  ownerUid: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  reminderDate?: string;
  ownerUid: string;
}

export interface Feedback {
  id: string;
  content: string;
  date: string;
  userEmail: string;
  ownerUid: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  purchasePrice: number;
  sellingPrice: number;
  stockQuantity: number;
  unit: string;
  lowStockAlert: number;
  ownerUid: string;
  updatedAt: string;
  
  // Packaging Details
  isPackaged?: boolean;
  packageUnit?: string;
  piecesPerPackage?: number;
  looseUnit?: string;
  looseSellingPrice?: number;

  // Lifetime Tracking
  totalSoldQty?: number;
  totalSoldAmount?: number;
  totalProfitEarned?: number;
}
