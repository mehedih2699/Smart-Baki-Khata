import { auth } from '../firebase';
import { toast } from 'react-hot-toast';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  
  let userFriendlyMessage = 'একটি ত্রুটি হয়েছে, দয়া করে আবার চেষ্টা করুন।';
  if (errorMessage.includes('permission-denied') || errorMessage.includes('Missing or insufficient permissions')) {
    userFriendlyMessage = 'আপনার এই কাজটি করার অনুমতি নেই।';
  } else if (errorMessage.toLowerCase().includes('nan') || errorMessage.includes('Invalid number')) {
    userFriendlyMessage = 'সঠিক সংখ্যা প্রদান করুন। (বাংলা সংখ্যাও গ্রহণযোগ্য)';
  } else if (errorMessage.includes('offline')) {
    userFriendlyMessage = 'ইন্টারনেট সংযোগ বিচ্ছিন্ন। সংযোগ চেক করুন।';
  }
  
  toast.error(userFriendlyMessage);
  
  // The directive says to throw the JSON string.
  throw new Error(JSON.stringify(errInfo));
}
