import React, { useState, useEffect, Suspense } from 'react';
import { Toaster } from 'react-hot-toast';
import { motion, AnimatePresence } from 'motion/react';
import { AuthProvider, useAuth } from './AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { MainLayout } from './components/MainLayout';
import { Dashboard } from './pages/Dashboard';
import { CashFlow } from './pages/CashFlow';
import { ReportsPage as Reports } from './pages/Reports';
import { SettingsPage as Settings } from './pages/Settings';
import { AdminPage as Admin } from './pages/Admin';
import { SavingsPage as Savings } from './pages/Savings';
import { LoansPage as Loans } from './pages/Loans';
import { NotesPage as Notes } from './pages/Notes';
import { InventoryPage as Inventory } from './pages/Inventory';
import { CustomerProfile } from './pages/CustomerProfile';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MaintenanceScreen } from './components/MaintenanceScreen';
import { BlockedScreen } from './components/BlockedScreen';
import { PinLock } from './components/PinLock';
import { ConnectionStatus } from './components/ConnectionStatus';
import { UpdateModal } from './components/UpdateModal';
import { ProductTour } from './components/ProductTour';
import { NotificationEngine } from './components/NotificationEngine';
import { Loader2 } from 'lucide-react';
import { APP_VERSION } from './constants';

const AppContent: React.FC = () => {
  const { user, firebaseUser, loading, systemSettings, isAdmin } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [selectedCustomerAction, setSelectedCustomerAction] = useState<'baki' | 'joma' | null>(null);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showUpdateBanner, setShowUpdateBanner] = useState(true);

  const isUpdateAvailable = systemSettings?.latestVersion && (() => {
    const latest = systemSettings.latestVersion.split('.').map(Number);
    const current = APP_VERSION.split('.').map(Number);
    for (let i = 0; i < Math.max(latest.length, current.length); i++) {
      const v1 = latest[i] || 0;
      const v2 = current[i] || 0;
      if (v1 > v2) return true;
      if (v1 < v2) return false;
    }
    return false;
  })();

  // Handle back button for mobile (Android/Capacitor & Web)
  useEffect(() => {
    // Web History back button handling
    const handleBackButton = (e: PopStateEvent) => {
      if (selectedCustomerId) {
        setSelectedCustomerId(null);
        setSelectedCustomerAction(null);
        // Push state again so next back press also gets caught if not on dashboard
        if (currentPage !== 'dashboard') {
          window.history.pushState({ page: currentPage }, '', '');
        }
      } else if (currentPage !== 'dashboard') {
        setCurrentPage('dashboard');
      }
    };

    window.addEventListener('popstate', handleBackButton);
    
    // Capacitor hardware back button handling
    let backButtonListener: any;
    import('@capacitor/app').then(({ App: CapacitorApp }) => {
      backButtonListener = CapacitorApp.addListener('backButton', ({ canGoBack }) => {
        if (selectedCustomerId) {
          setSelectedCustomerId(null);
          setSelectedCustomerAction(null);
        } else if (currentPage !== 'dashboard') {
          setCurrentPage('dashboard');
        } else {
          CapacitorApp.exitApp();
        }
      });
    }).catch(() => {
      // Capacitor not available, ignore
    });

    return () => {
      window.removeEventListener('popstate', handleBackButton);
      if (backButtonListener) {
        backButtonListener.remove();
      }
    };
  }, [selectedCustomerId, currentPage]);

  // Push history state when navigating forward in web
  useEffect(() => {
    window.history.pushState({ page: currentPage, customer: selectedCustomerId }, '', '');
  }, [currentPage, selectedCustomerId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-emerald-600 rounded-3xl flex items-center justify-center shadow-xl shadow-emerald-100 mb-6 animate-bounce overflow-hidden">
          <img 
            src="/icon.png" 
            alt="Logo" 
            className="w-12 h-12" 
            referrerPolicy="no-referrer" 
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
              const parent = (e.target as HTMLImageElement).parentElement;
              if (parent) {
                const text = document.createElement('span');
                text.innerText = 'ব';
                text.className = 'text-white text-4xl font-black';
                parent.appendChild(text);
              }
            }}
          />
        </div>
        <Loader2 className="w-8 h-8 text-emerald-600 animate-spin mb-4" />
        <h2 className="text-xl font-black text-slate-800 mb-1">বাকি খাতা প্রো</h2>
        <p className="text-sm text-slate-400 font-bold uppercase tracking-widest">লোড হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...</p>
      </div>
    );
  }

  if (systemSettings?.maintenanceMode && !isAdmin) {
    return <MaintenanceScreen />;
  }

  if (!firebaseUser) {
    return <AuthScreen />;
  }

  if (user?.blocked) {
    return <BlockedScreen />;
  }

  if (user?.pinEnabled && !isUnlocked) {
    return <PinLock correctPin={user.pin || ''} onSuccess={() => setIsUnlocked(true)} />;
  }

  const renderPage = () => {
    if (selectedCustomerId) {
      return (
        <CustomerProfile 
          customerId={selectedCustomerId} 
          onBack={() => {
            setSelectedCustomerId(null);
            setSelectedCustomerAction(null);
          }} 
          initialAddModal={selectedCustomerAction}
        />
      );
    }

    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onSelectCustomer={(id, action) => {
          setSelectedCustomerId(id);
          if (action) {
            setSelectedCustomerAction(action);
          } else {
            setSelectedCustomerAction(null);
          }
        }} />;
      case 'cash':
        return <CashFlow />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      case 'admin':
        return <Admin />;
      case 'savings':
        return <Savings />;
      case 'loans':
        return <Loans />;
      case 'inventory':
        return <Inventory />;
      case 'notes':
        return <Notes />;
      default:
        return <Dashboard onSelectCustomer={setSelectedCustomerId} />;
    }
  };

  return (
    <MainLayout currentPage={currentPage} onPageChange={setCurrentPage}>
      <Suspense fallback={
        <div className="flex items-center justify-center p-12">
          <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
        </div>
      }>
        {renderPage()}
      </Suspense>
      
      <AnimatePresence>
        {isUpdateAvailable && showUpdateBanner && systemSettings && (
          <UpdateModal 
            settings={systemSettings} 
            onClose={() => setShowUpdateBanner(false)} 
          />
        )}
      </AnimatePresence>
      <ConnectionStatus />
      {!user?.hasSeenTour && <ProductTour />}
    </MainLayout>
  );
};

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AppContent />
        <NotificationEngine />
        <Toaster position="top-center" reverseOrder={false} />
      </AuthProvider>
    </ErrorBoundary>
  );
};

export default App;
