import React, { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  sendPasswordResetEmail,
  User
} from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from './lib/firestore-errors';
import { auth, db } from './firebase';
import { toast } from 'react-hot-toast';
import { UserProfile } from './types';

export interface ContactInfo {
  label: string;
  value: string;
}

export interface SystemSettings {
  announcement?: string;
  latestVersion?: string;
  updateLink?: string;
  updateMessage?: string;
  forceUpdate?: boolean;
  maintenanceMode?: boolean;
  appName?: string;
  appLogo?: string;
  contactPhone?: string;
  contactEmail?: string;
  supportLink?: string;
  contacts?: ContactInfo[];
  privacyPolicy?: string;
  features: {
    savings: boolean;
    loans: boolean;
    notes: boolean;
    calculator: boolean;
    reports: boolean;
    feedback: boolean;
    aiQuotes?: boolean;
    customerTags?: boolean;
    pinLock?: boolean;
    notifications?: boolean;
  };
}

interface AuthContextType {
  user: UserProfile | null;
  firebaseUser: User | null;
  isAdmin: boolean;
  loading: boolean;
  isOnline: boolean;
  systemSettings: SystemSettings | null;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

export const AuthContext = React.createContext<AuthContextType>({
  user: null,
  firebaseUser: null,
  isAdmin: false,
  loading: true,
  isOnline: true,
  systemSettings: null,
  logout: async () => {},
  refreshUser: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [systemSettings, setSystemSettings] = useState<SystemSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    let unsubProfile: (() => void) | undefined;

    // Online/Offline Status Detection
    const handleOnline = () => {
      setIsOnline(true);
      toast.success('আপনি এখন অনলাইনে আছেন', { id: 'online-toast', icon: '🌐' });
    };
    const handleOffline = () => {
      setIsOnline(false);
      toast.error('আপনি এখন অফলাইনে আছেন', { id: 'offline-toast', icon: '📡' });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial Status Check
    if (!navigator.onLine) {
      setIsOnline(false);
      // Use a unique ID to prevent duplicate toasts
      setTimeout(() => {
        toast.error('আপনি অফলাইনে আছেন। ডাটা এন্ট্রি অফলাইনে সেভ হবে।', { 
          id: 'initial-offline-toast',
          icon: '📡',
          duration: 5000 
        });
      }, 1000);
    }

    // Fetch System Settings
    const unsubSettings = onSnapshot(doc(db, 'system', 'settings'), (doc) => {
      if (doc.exists()) {
        setSystemSettings(doc.data() as SystemSettings);
      } else {
        console.warn('System settings document not found');
        // Set default settings if missing to avoid blocking the app
        setSystemSettings({
          features: {
            savings: true,
            loans: true,
            notes: true,
            calculator: true,
            reports: true,
            feedback: true,
            customerTags: true,
            pinLock: true
          }
        } as SystemSettings);
      }
    }, (error) => {
      console.error('Error fetching system settings:', error);
      // Still set some default settings so the app can load
      setSystemSettings({
        features: {
          savings: true,
          loans: true,
          notes: true,
          calculator: true,
          reports: true,
          feedback: true,
          customerTags: true,
          pinLock: true
        }
      } as SystemSettings);
    });

    const unsubscribe = onAuthStateChanged(auth, async (fUser) => {
      setFirebaseUser(fUser);
      if (fUser) {
        unsubProfile = onSnapshot(doc(db, 'users', fUser.uid), (doc) => {
          if (doc.exists()) {
            const data = doc.data() as UserProfile;
            const localLogo = localStorage.getItem(`bakikhata_logo_${fUser.uid}`);
            
            // If firestore has logo, update local
            if (data.shopLogo) {
              localStorage.setItem(`bakikhata_logo_${fUser.uid}`, data.shopLogo);
            } 
            
            setUser({ 
              uid: fUser.uid, 
              ...data,
              customerCategories: data.customerCategories || ['New', 'VIP', 'Regular', 'Risky'],
              quickItems: data.quickItems || ['সিগারেট', 'চা পাতা', 'পান', 'বিস্কুট'],
              shopLogo: data.shopLogo || localLogo || undefined
            } as UserProfile);
          } else {
            setUser(null);
          }
          setLoading(false);
        }, (error) => {
          console.error('User profile snapshot error:', error);
          // If we are offline, we might still have user data in cache
          // but if it fails, we should still stop loading
          setLoading(false);
        });
      } else {
        setUser(null);
        if (unsubProfile) unsubProfile();
        setLoading(false);
      }
    });

    // Safety timeout to ensure loading state is cleared even if Firebase is slow
    const safetyTimeout = setTimeout(() => {
      if (loading) {
        console.warn('Auth state check timed out, clearing loading state');
        setLoading(false);
      }
    }, 2000); // Reduced to 2 seconds for better UX

    return () => {
      unsubscribe();
      unsubSettings();
      clearTimeout(safetyTimeout);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const logout = async () => {
    await signOut(auth);
  };

  const refreshUser = async () => {
    if (auth.currentUser) {
      try {
        const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
        if (userDoc.exists()) {
          setUser({ uid: auth.currentUser.uid, ...userDoc.data() } as UserProfile);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser.uid}`);
      }
    }
  };

  const isAdmin = firebaseUser?.email === 'mehedih0127@gmail.com' || user?.role === 'admin';

  return (
    <AuthContext.Provider value={{ user, firebaseUser, isAdmin, loading, isOnline, systemSettings, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => React.useContext(AuthContext);
