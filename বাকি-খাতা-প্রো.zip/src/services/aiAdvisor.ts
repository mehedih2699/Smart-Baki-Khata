import { GoogleGenAI } from "@google/genai";

export interface BusinessData {
  totalBaki: number;
  totalJoma: number;
  todayIncome: number;
  todayExpense: number;
  todayBaki: number;
  todayJoma: number;
  monthlyExpense: number;
  monthlyBudget: number;
  customerCount: number;
}

export async function getBusinessAdvice(data: BusinessData, type: 'morning' | 'evening'): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'dummy_key' || apiKey === 'YOUR_GEMINI_API_KEY') {
    return "এআই পরামর্শের জন্য একটি ভ্যালিড এপিআই কি (API Key) প্রয়োজন। আপনার গিটহাব সিক্রেটস-এ GEMINI_API_KEY সেট করুন।";
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = `
    You are a professional business advisor for a small retail shop owner in Bangladesh.
    Analyze the following business data and provide a short, encouraging, and actionable advice in Bengali.
    
    Data:
    - Total Due (Baki): ${data.totalBaki} BDT
    - Total Advance (Joma): ${data.totalJoma} BDT
    - Today's Income: ${data.todayIncome} BDT
    - Today's Expense: ${data.todayExpense} BDT
    - Today's New Due: ${data.todayBaki} BDT
    - Today's Collection: ${data.todayJoma} BDT
    - Monthly Expense so far: ${data.monthlyExpense} BDT
    - Monthly Budget: ${data.monthlyBudget} BDT
    - Total Customers: ${data.customerCount}
    
    Context: ${type === 'morning' ? 'Morning update (start of the day)' : 'Evening update (end of the day)'}
    
    Requirements:
    1. Language: Bengali (Standard/Formal but friendly).
    2. Length: Max 2-3 sentences.
    3. Focus: 
       - If morning: Focus on goals, collection targets, or inventory check.
       - If evening: Focus on summary, savings, or planning for tomorrow.
    4. Tone: Positive and professional.
    
    Output only the Bengali advice text.
  `;

  if (!navigator.onLine) {
    return "পরামর্শ লোড করতে সমস্যা হয়েছে। (আপনার ইন্টারনেট কানেকশন নেই)";
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "দুঃখিত, এই মুহূর্তে কোনো পরামর্শ পাওয়া যাচ্ছে না।";
  } catch (error: any) {
    console.error("AI Advisor Error:", error);
    
    // Check for common network errors
    if (error?.message?.includes('Failed to fetch') || error?.message?.includes('NetworkError')) {
      return "পরামর্শ লোড করতে সমস্যা হয়েছে। (সার্ভারের সাথে কানেক্ট করা যাচ্ছে না)";
    }
    
    if (error?.message?.includes('API_KEY_INVALID')) {
      return "আপনার এপিআই কি (API Key) সঠিক নয়। দয়া করে গিটহাব সিক্রেটস-এ সঠিক কি সেট করুন।";
    }
    
    if (error?.message?.includes('quota') || error?.message?.includes('429')) {
      return "পরামর্শ লোড করতে সমস্যা হয়েছে। (এপিআই কোটা শেষ হয়ে গেছে)";
    }

    return `পরামর্শ লোড করতে সমস্যা হয়েছে। (Error: ${error?.message?.slice(0, 50)}...)`;
  }
}
