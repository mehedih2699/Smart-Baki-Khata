import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X } from 'lucide-react';
import { cn } from '../lib/utils';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  variant?: 'danger' | 'warning' | 'info';
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'নিশ্চিত করুন',
  cancelText = 'বাতিল',
  variant = 'danger'
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-8 shadow-2xl max-h-[95vh] overflow-y-auto no-scrollbar"
          >
            <div className={cn(
              "w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-6",
              variant === 'danger' ? "bg-rose-50 text-rose-500" :
              variant === 'warning' ? "bg-amber-50 text-amber-500" : "bg-blue-50 text-blue-500"
            )}>
              <AlertTriangle className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold text-slate-800 text-center mb-2">{title}</h3>
            <p className="text-slate-500 text-center text-sm mb-8 leading-relaxed">
              {message}
            </p>

            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  onConfirm();
                  onClose();
                }}
                className={cn(
                  "w-full py-4 rounded-2xl text-white font-bold shadow-lg transition-all active:scale-95",
                  variant === 'danger' ? "bg-rose-500 shadow-rose-100" :
                  variant === 'warning' ? "bg-amber-500 shadow-amber-100" : "bg-blue-500 shadow-blue-100"
                )}
              >
                {confirmText}
              </button>
              <button
                onClick={onClose}
                className="w-full py-4 bg-slate-50 text-slate-500 rounded-2xl font-bold hover:bg-slate-100 transition-all active:scale-95"
              >
                {cancelText}
              </button>
            </div>

            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 hover:bg-slate-100 rounded-full transition-all"
            >
              <X className="w-5 h-5 text-slate-400" />
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
