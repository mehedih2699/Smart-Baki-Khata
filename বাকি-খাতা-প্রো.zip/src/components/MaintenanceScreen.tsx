import React from 'react';
import { motion } from 'motion/react';
import { Settings, AlertTriangle, MessageCircle, Phone } from 'lucide-react';

interface MaintenanceScreenProps {
  appName?: string;
  contactEmail?: string;
  contactPhone?: string;
}

export const MaintenanceScreen: React.FC<MaintenanceScreenProps> = ({ 
  appName = 'Baki Khata', 
  contactEmail, 
  contactPhone 
}) => {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white rounded-[3rem] p-10 text-center shadow-2xl shadow-slate-200 border border-slate-100"
      >
        <div className="relative w-24 h-24 mx-auto mb-8">
          <div className="absolute inset-0 bg-amber-100 rounded-[2rem] animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center">
            <Settings className="w-12 h-12 text-amber-600 animate-[spin_4s_linear_infinite]" />
          </div>
          <div className="absolute -top-2 -right-2 bg-rose-500 text-white p-2 rounded-xl shadow-lg">
            <AlertTriangle className="w-4 h-4" />
          </div>
        </div>

        <h1 className="text-3xl font-black text-slate-800 mb-4 tracking-tight">
          রক্ষণাবেক্ষণ চলছে
        </h1>
        
        <p className="text-slate-500 mb-10 leading-relaxed font-medium">
          {appName} অ্যাপটি বর্তমানে আপডেট বা রক্ষণাবেক্ষণের জন্য সাময়িকভাবে বন্ধ আছে। আমরা শীঘ্রই ফিরে আসছি!
        </p>

        <div className="space-y-4">
          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">সহযোগিতার জন্য যোগাযোগ করুন</p>
            <div className="flex flex-col gap-3">
              {contactPhone && (
                <a 
                  href={`tel:${contactPhone}`}
                  className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-slate-100 hover:border-emerald-200 transition-all group"
                >
                  <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                    <Phone className="w-5 h-5" />
                  </div>
                  <span className="font-bold text-slate-700">{contactPhone}</span>
                </a>
              )}
              {contactEmail && (
                <a 
                  href={`mailto:${contactEmail}`}
                  className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-slate-100 hover:border-blue-200 transition-all group"
                >
                  <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <span className="font-bold text-slate-700">{contactEmail}</span>
                </a>
              )}
            </div>
          </div>
        </div>

        <p className="mt-10 text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em]">
          ধৈর্য ধরার জন্য ধন্যবাদ
        </p>
      </motion.div>
    </div>
  );
};
