import { useEffect, useRef } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { InventoryItem, Customer, Loaner, Note, CashEntry } from '../types';
import { toast } from 'react-hot-toast';

export const NotificationEngine = () => {
  const { user } = useAuth();
  
  // Ref to track if we've already notified an event in this session
  // To avoid spamming on hot reloads or fast renders
  const notifiedKeys = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!user) return;
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, [user]);

  const triggerNotification = (id: string, title: string, body: string) => {
    if (!('Notification' in window)) return;
    
    const storageKey = `notified_${id}`;
    const lastNotified = localStorage.getItem(storageKey);
    const now = Date.now();
    
    // Cooldown: 12 hours check (12 * 60 * 60 * 1000 = 43200000 ms)
    if (!lastNotified || now - Number(lastNotified) > 43200000) {
      if (Notification.permission === 'granted') {
        try {
          new Notification(title, {
            body,
            icon: '/vite.svg', // Default icon
            tag: id // prevent duplicate popups grouped by tag
          });
        } catch(e) {
          console.error('Notification API Error:', e);
        }
      } else {
        // Fallback to in-app toast if permission is not granted but we want to notify
        toast(title + "\n" + body, { icon: '🔔', duration: 5000 });
      }
      
      localStorage.setItem(storageKey, String(now));
    }
  };

  useEffect(() => {
    if (!user) return;

    // 1. Inventory Check (Low Stock & Out of Stock)
    const qInv = query(collection(db, 'inventory'), where('ownerUid', '==', user.uid));
    const unsubInv = onSnapshot(qInv, (snap) => {
      snap.forEach(doc => {
        const item = doc.data() as InventoryItem;
        if (item.stockQuantity <= 0) {
          triggerNotification(`inv_out_${doc.id}`, 'স্টক আউট!', `${item.name} এর স্টক সম্পূর্ণ শেষ হয়ে গেছে।`);
        } else if (item.stockQuantity <= (item.lowStockAlert || 5)) {
          triggerNotification(`inv_low_${doc.id}`, 'স্টক অ্যালার্ট', `${item.name} এর স্টক কমে গেছে (আর মাত্র ${item.stockQuantity} ${item.unit} আছে)।`);
        }
      });
    });

    // 2. Customer Dues / Limit
    const qCust = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubCust = onSnapshot(qCust, (snap) => {
      snap.forEach(doc => {
        const cust = doc.data() as Customer;
        if (cust.totalBalance > 0) {
          // Check Risk Limit
          const redLimit = user?.debtLimits?.red || 1000;
          if (cust.totalBalance > redLimit) {
            triggerNotification(`cust_limit_${doc.id}`, 'বকেয়া অ্যালার্ট', `${cust.name} এর বকেয়া লিমিট ক্রস করেছে (${cust.totalBalance} ৳)।`);
          }
          // Check Due Date
          if (cust.dueDate) {
            const dueTs = new Date(cust.dueDate).getTime();
            const nowTs = Date.now();
            if (dueTs <= nowTs + 86400000 && dueTs > nowTs - 86400000) { // Due within 24 hours
              triggerNotification(`cust_due_${doc.id}`, 'পেমেন্ট ডেট', `আজ ${cust.name} এর বকেয়া পরিশোধ করার কথা।`);
            } else if (dueTs < nowTs) {
               triggerNotification(`cust_due_past_${doc.id}`, 'পেমেন্ট ওভারডিউ', `${cust.name} এর বকেয়া পরিশোধের ডেট পার হয়ে গেছে।`);
            }
          }
        }
      });
    });

    // 3. Supplier (Loaner) Dues
    const qLoan = query(collection(db, 'loaners'), where('ownerUid', '==', user.uid));
    const unsubLoan = onSnapshot(qLoan, (snap) => {
      snap.forEach(doc => {
        const loaner = doc.data() as Loaner;
        const dueAmount = loaner.totalTaken - loaner.totalPaid;
        if (dueAmount > 0 && loaner.dueDate) {
          const dueTs = new Date(loaner.dueDate).getTime();
          const nowTs = Date.now();
          if (dueTs <= nowTs + 86400000 && dueTs > nowTs - 86400000) {
            triggerNotification(`loan_due_${doc.id}`, 'দেনা পরিশোধ', `আজ ${loaner.name} কে পেমেন্ট করার কথা।`);
          } else if (dueTs < nowTs) {
            triggerNotification(`loan_due_past_${doc.id}`, 'দেনা ওভারডিউ', `${loaner.name} কে পেমেন্ট করার ডেট পার হয়ে গেছে।`);
          }
        }
      });
    });

    // 4. Notes Reminder Check
    const qNotes = query(collection(db, 'notes'), where('ownerUid', '==', user.uid));
    const unsubNotes = onSnapshot(qNotes, (snap) => {
      snap.forEach(doc => {
        const note = doc.data() as Note;
        if (note.reminderDate) {
          const remTs = new Date(note.reminderDate).getTime();
          const nowTs = Date.now();
          if (remTs <= nowTs + 86400000 && remTs > nowTs - 86400000) {
            triggerNotification(`note_rem_${doc.id}`, 'রিমাইন্ডার!', note.title);
          }
        }
      });
    });

    // 5. Monthly Budget Tracking
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0,0,0,0);
        
    const qExpense = query(
      collection(db, 'cashEntries'), 
      where('ownerUid', '==', user.uid),
      where('type', '==', 'expense'),
      where('date', '>=', startOfMonth.toISOString())
    );
    const unsubExp = onSnapshot(qExpense, (snap) => {
      if (!user.monthlyBudget) return;
      let totalExpense = 0;
      snap.forEach(doc => {
        const entry = doc.data() as CashEntry;
        totalExpense += entry.amount;
      });
      
      const budget = Number(user.monthlyBudget);
      if (totalExpense > budget) {
         triggerNotification(`budget_exceeded_${startOfMonth.getMonth()}`, 'বাজেট অ্যালার্ট', `আপনার বর্তমান মাসের বাজেট ক্রস হয়ে গেছে!`);
      } else if (totalExpense > budget * 0.8) {
         triggerNotification(`budget_warning_${startOfMonth.getMonth()}`, 'বাজেট অ্যালার্ট', `আপনার এ মাসের বাজেটের ৮০% খরচ হয়ে গেছে। সাবধানে খরচ করুন।`);
      }
    });

    return () => {
      unsubInv();
      unsubCust();
      unsubLoan();
      unsubNotes();
      unsubExp();
    }
  }, [user]);

  return null;
}
