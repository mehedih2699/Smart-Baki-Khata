import { useEffect, useRef, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { InventoryItem, Customer, Loaner, Note, CashEntry } from '../types';
import { toast } from 'react-hot-toast';
import { Bell, BellRing, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

// Generate a numeric hash for string IDs (Capacitor requires numeric IDs)
const hashStringId = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash = hash & hash;
  }
  return Math.abs(hash);
};

export const NotificationEngine = () => {
  const { user } = useAuth();
  
  const [permission, setPermission] = useState<string>('denied');
  const [showPrompt, setShowPrompt] = useState(false);

  const notifiedKeys = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!user) return;
    
    const checkPermissions = async () => {
      if (Capacitor.isNativePlatform()) {
        const status = await LocalNotifications.checkPermissions();
        if (status.display !== 'granted') {
          setShowPrompt(true);
        } else {
          setPermission('granted');
        }
      } else {
        if ('Notification' in window && Notification.permission === 'default') {
          setShowPrompt(true);
        } else {
          setPermission('Notification' in window ? Notification.permission : 'denied');
        }
      }
    };
    
    checkPermissions();
  }, [user]);

  const requestPermission = async () => {
    try {
      if (Capacitor.isNativePlatform()) {
        const status = await LocalNotifications.requestPermissions();
        setPermission(status.display);
        setShowPrompt(false);
        if (status.display === 'granted') {
          toast.success('নোটিফিকেশন চালু করা হয়েছে!');
          await LocalNotifications.schedule({
            notifications: [{
              title: 'স্বাগতম!',
              body: 'এখন থেকে আপনি গুরুত্বপূর্ণ আপডেটগুলো নোটিফিকেশন হিসেবে পাবেন।',
              id: 1,
              schedule: { at: new Date(Date.now() + 100) }
            }]
          });
        } else {
          toast.error('নোটিফিকেশন পারমিশন দেওয়া হয়নি।');
        }
      } else if ('Notification' in window) {
        const p = await Notification.requestPermission();
        setPermission(p);
        setShowPrompt(false);
        if (p === 'granted') {
          toast.success('নোটিফিকেশন চালু করা হয়েছে!');
          new Notification('স্বাগতম!', { body: 'এখন থেকে আপনি গুরুত্বপূর্ণ আপডেটগুলো নোটিফিকেশন হিসেবে পাবেন।', icon: '/vite.svg' });
        } else {
          toast.error('নোটিফিকেশন পারমিশন দেওয়া হয়নি।');
        }
      }
    } catch (error) {
      console.error("Error requesting notification permission", error);
    }
  };

  const triggerNotification = async (id: string, title: string, body: string) => {
    const storageKey = `notified_${id}`;
    const lastNotified = localStorage.getItem(storageKey);
    const now = Date.now();
    
    // Cooldown: 12 hours check (12 * 60 * 60 * 1000 = 43200000 ms)
    if (!lastNotified || now - Number(lastNotified) > 43200000) {
      if (Capacitor.isNativePlatform()) {
        const status = await LocalNotifications.checkPermissions();
        if (status.display === 'granted') {
          try {
            await LocalNotifications.schedule({
              notifications: [{
                title,
                body,
                id: hashStringId(id),
                schedule: { at: new Date(Date.now() + 100) }
              }]
            });
          } catch(e) {
            console.error('Capacitor Notification Error:', e);
          }
        } else {
          toast.success(title + "\n" + body, { icon: '🔔', duration: 5000 });
        }
      } else {
        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification(title, {
              body,
              icon: '/vite.svg',
              tag: id
            });
          } catch(e) {
            console.error('Web Notification API Error:', e);
          }
        } else {
          // Fallback to in-app toast
          toast.success(title + "\n" + body, { icon: '🔔', duration: 5000 });
        }
      }
      
      localStorage.setItem(storageKey, String(now));
    }
  };

  useEffect(() => {
    if (!user) return;

    // 1. Inventory Check (Low Stock & Out of Stock)
    const qInv = query(collection(db, 'inventory'), where('ownerUid', '==', user.uid));
    const unsubInv = onSnapshot(qInv, (snap) => {
      snap.forEach(doc => {
        const item = doc.data() as InventoryItem;
        if (item.stockQuantity <= 0) {
          triggerNotification(`inv_out_${doc.id}`, 'স্টক আউট!', `${item.name} এর স্টক সম্পূর্ণ শেষ হয়ে গেছে।`);
        } else if (item.stockQuantity <= (item.lowStockAlert || 5)) {
          triggerNotification(`inv_low_${doc.id}`, 'স্টক অ্যালার্ট', `${item.name} এর স্টক কমে গেছে (আর মাত্র ${item.stockQuantity} ${item.unit} আছে)।`);
        }
      });
    });

    // 2. Customer Dues / Limit
    const qCust = query(collection(db, 'customers'), where('ownerUid', '==', user.uid));
    const unsubCust = onSnapshot(qCust, (snap) => {
      snap.forEach(doc => {
        const cust = doc.data() as Customer;
        if (cust.totalBalance > 0) {
          // Check Risk Limit
          const redLimit = user?.debtLimits?.red || 1000;
          if (cust.totalBalance > redLimit) {
            triggerNotification(`cust_limit_${doc.id}`, 'বকেয়া অ্যালার্ট', `${cust.name} এর বকেয়া লিমিট ক্রস করেছে (${cust.totalBalance} ৳)।`);
          }
          // Check Due Date
          if (cust.dueDate) {
            const dueTs = new Date(cust.dueDate).getTime();
            const nowTs = Date.now();
            if (dueTs <= nowTs + 86400000 && dueTs > nowTs - 86400000) { // Due within 24 hours
              triggerNotification(`cust_due_${doc.id}`, 'পেমেন্ট ডেট', `আজ ${cust.name} এর বকেয়া পরিশোধ করার কথা।`);
            } else if (dueTs < nowTs) {
               triggerNotification(`cust_due_past_${doc.id}`, 'পেমেন্ট ওভারডিউ', `${cust.name} এর বকেয়া পরিশোধের ডেট পার হয়ে গেছে।`);
            }
          }
        }
      });
    });

    // 3. Supplier (Loaner) Dues
    const qLoan = query(collection(db, 'loaners'), where('ownerUid', '==', user.uid));
    const unsubLoan = onSnapshot(qLoan, (snap) => {
      snap.forEach(doc => {
        const loaner = doc.data() as Loaner;
        const dueAmount = loaner.totalTaken - loaner.totalPaid;
        if (dueAmount > 0 && loaner.dueDate) {
          const dueTs = new Date(loaner.dueDate).getTime();
          const nowTs = Date.now();
          if (dueTs <= nowTs + 86400000 && dueTs > nowTs - 86400000) {
            triggerNotification(`loan_due_${doc.id}`, 'দেনা পরিশোধ', `আজ ${loaner.name} কে পেমেন্ট করার কথা।`);
          } else if (dueTs < nowTs) {
            triggerNotification(`loan_due_past_${doc.id}`, 'দেনা ওভারডিউ', `${loaner.name} কে পেমেন্ট করার ডেট পার হয়ে গেছে।`);
          }
        }
      });
    });

    // 4. Notes Reminder Check
    const qNotes = query(collection(db, 'notes'), where('ownerUid', '==', user.uid));
    const unsubNotes = onSnapshot(qNotes, (snap) => {
      snap.forEach(doc => {
        const note = doc.data() as Note;
        if (note.reminderDate) {
          const remTs = new Date(note.reminderDate).getTime();
          const nowTs = Date.now();
          if (remTs <= nowTs + 86400000 && remTs > nowTs - 86400000) {
            triggerNotification(`note_rem_${doc.id}`, 'রিমাইন্ডার!', note.title);
          }
        }
      });
    });

    // 5. Monthly Budget Tracking
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0,0,0,0);
        
    const qExpense = query(
      collection(db, 'cashEntries'), 
      where('ownerUid', '==', user.uid),
      where('type', '==', 'expense'),
      where('date', '>=', startOfMonth.toISOString())
    );
    const unsubExp = onSnapshot(qExpense, (snap) => {
      if (!user.monthlyBudget) return;
      let totalExpense = 0;
      snap.forEach(doc => {
        const entry = doc.data() as CashEntry;
        totalExpense += entry.amount;
      });
      
      const budget = Number(user.monthlyBudget);
      if (totalExpense > budget) {
         triggerNotification(`budget_exceeded_${startOfMonth.getMonth()}`, 'বাজেট অ্যালার্ট', `আপনার বর্তমান মাসের বাজেট ক্রস হয়ে গেছে!`);
      } else if (totalExpense > budget * 0.8) {
         triggerNotification(`budget_warning_${startOfMonth.getMonth()}`, 'বাজেট অ্যালার্ট', `আপনার এ মাসের বাজেটের ৮০% খরচ হয়ে গেছে। সাবধানে খরচ করুন।`);
      }
    });

    return () => {
      unsubInv();
      unsubCust();
      unsubLoan();
      unsubNotes();
      unsubExp();
    }
  }, [user]);

  return (
    <AnimatePresence>
      {showPrompt && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          className="fixed bottom-24 left-4 right-4 z-50 md:left-auto md:right-4 md:w-96"
        >
          <div className="bg-white rounded-3xl p-5 shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-slate-100 flex items-start gap-4">
            <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center shrink-0">
              <BellRing className="w-6 h-6 text-emerald-600 animate-bounce" />
            </div>
            <div className="flex-1 pt-1">
              <h3 className="text-sm font-bold text-slate-800 mb-1">নোটিফিকেশন চালু করুন</h3>
              <p className="text-xs text-slate-500 mb-3 leading-relaxed">স্টক অ্যালার্ট, বকেয়া এবং অন্যান্য রিমাইন্ডার পেতে নোটিফিকেশন চালু করুন।</p>
              <div className="flex gap-2">
                <button
                  onClick={requestPermission}
                  className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-600 transition-all flex-1"
                >
                  চালু করুন
                </button>
                <button
                  onClick={() => setShowPrompt(false)}
                  className="bg-slate-100 text-slate-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-slate-200 transition-all"
                >
                  পরে
                </button>
              </div>
            </div>
            <button 
              onClick={() => setShowPrompt(false)}
              className="absolute top-2 right-2 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
