import React from 'react';
import { ErrorBoundary as ReactErrorBoundary } from 'react-error-boundary';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ErrorFallbackProps {
  error: Error;
  resetErrorBoundary: () => void;
}

const ErrorFallback: React.FC<ErrorFallbackProps> = ({ error, resetErrorBoundary }) => {
  let errorMessage = 'কিছু একটা সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।';
  let isFirestoreError = false;

  try {
    if (error?.message) {
      const parsed = JSON.parse(error.message);
      if (parsed.error && parsed.operationType) {
        isFirestoreError = true;
        if (parsed.error.includes('insufficient permissions')) {
          errorMessage = 'আপনার এই কাজটি করার অনুমতি নেই। অনুগ্রহ করে লগইন চেক করুন।';
        } else if (parsed.error.includes('quota exceeded')) {
          errorMessage = 'সার্ভার কোটা শেষ হয়ে গেছে। অনুগ্রহ করে পরে চেষ্টা করুন।';
        }
      }
    }
  } catch (e) {
    // Not a JSON error message
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 text-center">
        <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">দুঃখিত!</h2>
        <p className="text-slate-600 mb-8">{errorMessage}</p>
        
        {isFirestoreError && (
          <div className="text-left bg-slate-100 p-4 rounded-xl mb-8 overflow-auto max-h-40">
            <p className="text-[10px] font-mono text-slate-500 break-all">
              {error?.message}
            </p>
          </div>
        )}

        {!isFirestoreError && error?.message && (
          <div className="text-left bg-rose-50 border border-rose-100 p-4 rounded-xl mb-8 overflow-auto max-h-40">
            <p className="text-[11px] font-mono text-rose-800 break-all">
              <b>System Error:</b> {error.message}
            </p>
          </div>
        )}

        <button
          onClick={() => {
            resetErrorBoundary();
            window.location.reload();
          }}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-200 transition-all flex items-center justify-center gap-2"
        >
          <RefreshCw className="w-5 h-5" />
          আবার চেষ্টা করুন
        </button>
      </div>
    </div>
  );
};

export const ErrorBoundary: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <ReactErrorBoundary FallbackComponent={ErrorFallback}>
      {children}
    </ReactErrorBoundary>
  );
};
