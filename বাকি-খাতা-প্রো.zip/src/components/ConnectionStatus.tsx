import React, { useState } from 'react';
import { useAuth } from '../AuthContext';
import { Wifi, WifiOff, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ConnectionStatus: React.FC = () => {
  const { isOnline } = useAuth();
  const [dismissed, setDismissed] = useState(false);
  const [showOnline, setShowOnline] = useState(false);
  const prevStatus = React.useRef(isOnline);

  // Reset dismissed state when status changes
  React.useEffect(() => {
    if (isOnline && !prevStatus.current) {
      // Just reconnected
      setShowOnline(true);
      const timer = setTimeout(() => setShowOnline(false), 3000);
      return () => clearTimeout(timer);
    }
    prevStatus.current = isOnline;
    setDismissed(false);
  }, [isOnline]);

  if (dismissed && !showOnline) return null;

  return (
    <AnimatePresence>
      {!isOnline && !dismissed && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -100, opacity: 0 }}
          className="fixed top-4 left-4 right-4 z-[100] pointer-events-none"
        >
          <div className="max-w-md mx-auto bg-slate-900/90 backdrop-blur-md text-white px-4 py-3 rounded-2xl shadow-2xl border border-white/10 flex items-center justify-between gap-3 pointer-events-auto">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-rose-500/20 rounded-full flex items-center justify-center text-rose-400">
                <WifiOff className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-bold leading-none mb-1">আপনি অফলাইনে আছেন</p>
                <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">ডাটা অফলাইনে সেভ হবে</p>
              </div>
            </div>
            <button 
              onClick={() => setDismissed(true)}
              className="p-1.5 hover:bg-white/10 rounded-lg transition-all"
            >
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </motion.div>
      )}
      
      {isOnline && showOnline && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -100, opacity: 0 }}
          className="fixed top-4 left-4 right-4 z-[100] pointer-events-none"
        >
          <div className="max-w-md mx-auto bg-emerald-600/90 backdrop-blur-md text-white px-4 py-3 rounded-2xl shadow-2xl border border-white/10 flex items-center justify-between gap-3 pointer-events-auto">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-white">
                <Wifi className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-bold leading-none mb-1">আপনি এখন অনলাইনে আছেন</p>
                <p className="text-[10px] text-emerald-100/80 font-medium uppercase tracking-wider">ডাটা সিঙ্ক হচ্ছে...</p>
              </div>
            </div>
            <button 
              onClick={() => setShowOnline(false)}
              className="p-1.5 hover:bg-white/10 rounded-lg transition-all"
            >
              <X className="w-4 h-4 text-white/60" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
