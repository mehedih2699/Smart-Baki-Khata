import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, LogOut, Phone, Mail } from 'lucide-react';
import { useAuth } from '../AuthContext';

interface BlockedScreenProps {
  contactEmail?: string;
  contactPhone?: string;
}

export const BlockedScreen: React.FC<BlockedScreenProps> = ({ contactEmail, contactPhone }) => {
  const { logout } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white rounded-[2.5rem] shadow-xl shadow-rose-100/50 border border-rose-100 overflow-hidden"
      >
        <div className="bg-rose-500 p-10 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10">
            <ShieldAlert className="w-64 h-64 -translate-x-1/2 -translate-y-1/2 absolute top-1/2 left-1/2" />
          </div>
          <div className="relative z-10">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl flex items-center justify-center mx-auto mb-6 border border-white/30">
              <ShieldAlert className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-black text-white mb-2">অ্যাকাউন্ট ব্লকড!</h1>
            <p className="text-rose-100 font-medium">আপনার অ্যাকাউন্টটি সাময়িকভাবে স্থগিত করা হয়েছে</p>
          </div>
        </div>

        <div className="p-8 space-y-8">
          <div className="space-y-4">
            <p className="text-slate-600 text-center leading-relaxed">
              নিরাপত্তা জনিত কারণে বা সিস্টেমের নিয়ম ভঙ্গের কারণে আপনার অ্যাকাউন্টটি ব্লক করা হয়েছে। বিস্তারিত জানতে অ্যাডমিনের সাথে যোগাযোগ করুন।
            </p>
          </div>

          {(contactEmail || contactPhone) && (
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest text-center">যোগাযোগ করুন</p>
              <div className="grid grid-cols-1 gap-3">
                {contactPhone && (
                  <a href={`tel:${contactPhone}`} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 text-slate-700 font-bold hover:border-emerald-500 hover:text-emerald-600 transition-all">
                    <Phone className="w-5 h-5 text-emerald-500" />
                    {contactPhone}
                  </a>
                )}
                {contactEmail && (
                  <a href={`mailto:${contactEmail}`} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 text-slate-700 font-bold hover:border-emerald-500 hover:text-emerald-600 transition-all">
                    <Mail className="w-5 h-5 text-emerald-500" />
                    {contactEmail}
                  </a>
                )}
              </div>
            </div>
          )}

          <button
            onClick={() => logout()}
            className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
          >
            <LogOut className="w-5 h-5" />
            লগ আউট করুন
          </button>
        </div>
      </motion.div>
    </div>
  );
};
