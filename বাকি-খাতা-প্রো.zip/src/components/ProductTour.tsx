import React from 'react';
import { Joyride, Step, STATUS } from 'react-joyride';
import { useAuth } from '../AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export const ProductTour: React.FC = () => {
  const { user } = useAuth();
  const [run, setRun] = React.useState(false);

  // Check if tour should be shown (Global for this device/installation)
  const [hasSeen, setHasSeen] = React.useState(() => {
    return localStorage.getItem('bakikhata_tour_v1_seen') === 'true';
  });

  const tourStartedRef = React.useRef(false);

  React.useEffect(() => {
    if (!hasSeen && user && !tourStartedRef.current) {
      tourStartedRef.current = true;
      
      // Small delay to ensure all target elements are in the DOM
      const timer = setTimeout(() => {
        setRun(true);
        // Mark as seen immediately when it starts to be safe
        localStorage.setItem('bakikhata_tour_v1_seen', 'true');
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [hasSeen, user]);

  if (hasSeen && !run) return null;

  const steps: any[] = [
    {
      target: 'body',
      disableBeacon: true,
      disableOverlayClose: true,
      hideCloseButton: true,
      spotlightClicks: false,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">স্বাগতম! 👋</h3>
          <p className="text-slate-600">বাকি খাতা প্রো অ্যাপে আপনাকে স্বাগতম। চলুন অ্যাপটির গুরুত্বপূর্ণ ফিচারগুলো এক নজরে দেখে নেই।</p>
        </div>
      ),
      placement: 'center',
    },
    {
      target: '#tour-profile-logo',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">আপনার প্রোফাইল</h3>
          <p className="text-slate-600">এখানে আপনার দোকানের নাম এবং লোগো দেখা যাবে। সেটিংস থেকে আপনি এগুলো পরিবর্তন করতে পারবেন।</p>
        </div>
      ),
    },
    {
      target: '#tour-balance-card',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">ব্যালেন্স কার্ড</h3>
          <p className="text-slate-600">এখানে আপনি আপনার দোকানের মোট বাকি এবং জমার হিসাব দেখতে পাবেন। বিস্তারিত দেখতে কার্ডের ডানদিকের অ্যারো বাটনে ক্লিক করুন।</p>
        </div>
      ),
    },
    {
      target: '#tour-ai-advisor',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">এআই এডভাইজার</h3>
          <p className="text-slate-600">আপনার ব্যবসার ডাটা অ্যানালাইসিস করে প্রতিদিন সকালে এবং সন্ধ্যায় আমাদের এআই আপনাকে গুরুত্বপূর্ণ পরামর্শ দেবে।</p>
        </div>
      ),
    },
    {
      target: '#tour-mobile-add',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">নতুন কাস্টমার</h3>
          <p className="text-slate-600">নতুন কোনো কাস্টমার যোগ করতে এই প্লাস (+) বাটনে ক্লিক করুন।</p>
        </div>
      ),
    },
    {
      target: '#tour-search-bar',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">সার্চ এবং ফিল্টার</h3>
          <p className="text-slate-600">নাম বা ফোন নম্বর দিয়ে খুব সহজে কাস্টমার খুঁজে বের করুন। এছাড়াও ক্যাটাগরি অনুযায়ী ফিল্টার করতে পারবেন।</p>
        </div>
      ),
    },
    {
      target: '#tour-customer-list',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">কাস্টমার লিস্ট</h3>
          <p className="text-slate-600">এখানে আপনার সব কাস্টমারের তালিকা থাকবে। কাস্টমারের ওপর ক্লিক করে তার লেনদেনের বিস্তারিত দেখতে পারবেন।</p>
        </div>
      ),
    },
    {
      target: window.innerWidth < 1024 ? '#tour-nav-cash-mobile' : '#tour-nav-cash',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">ক্যাশ ম্যানেজমেন্ট</h3>
          <p className="text-slate-600">দোকানের প্রতিদিনের আয়-ব্যয়ের হিসাব রাখতে এই অপশনটি ব্যবহার করুন।</p>
        </div>
      ),
    },
    {
      target: window.innerWidth < 1024 ? '#tour-nav-notes-mobile' : '#tour-nav-notes',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">নোটস</h3>
          <p className="text-slate-600">গুরুত্বপূর্ণ কোনো তথ্য বা হিসাব লিখে রাখতে নোটস ব্যবহার করুন।</p>
        </div>
      ),
    },
    {
      target: window.innerWidth < 1024 ? '#tour-nav-loans-mobile' : '#tour-nav-loans',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">সাপ্লায়ার ম্যানেজমেন্ট</h3>
          <p className="text-slate-600">পাইকারি বিক্রেতা বা মহাজনদের কাছ থেকে কত টাকার মাল বাকিতে এনেছেন এবং কত টাকা পরিশোধ করেছেন তার হিসাব এখানে রাখতে পারবেন।</p>
        </div>
      ),
    },
    {
      target: window.innerWidth < 1024 ? '#tour-mobile-menu' : '#tour-nav-reports',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">{window.innerWidth < 1024 ? 'মেনু অপশন' : 'রিপোর্ট এবং গ্রাফ'}</h3>
          <p className="text-slate-600">
            {window.innerWidth < 1024 
              ? 'রিপোর্ট, সেটিংস এবং অন্যান্য অপশনগুলো এই মেনুর ভেতরে পাবেন।' 
              : 'আপনার ব্যবসার সাপ্তাহিক বা মাসিক রিপোর্ট এবং গ্রাফ দেখতে এখানে যান।'}
          </p>
        </div>
      ),
    },
    {
      target: window.innerWidth < 1024 ? '#tour-mobile-menu' : '#tour-nav-settings',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">সেটিংস</h3>
          <p className="text-slate-600">দোকানের নাম, লোগো, পিন লক এবং অন্যান্য কনফিগারেশন এখান থেকে পরিবর্তন করুন।</p>
        </div>
      ),
    },
    {
      target: 'body',
      disableBeacon: true,
      hideCloseButton: true,
      content: (
        <div className="text-left">
          <h3 className="text-lg font-bold text-emerald-700 mb-2">সব সেট! ✅</h3>
          <p className="text-slate-600">আপনি এখন অ্যাপটি ব্যবহার করার জন্য তৈরি। কোনো সাহায্য লাগলে মেনু থেকে আমাদের সাথে যোগাযোগ করতে পারেন।</p>
        </div>
      ),
      placement: 'center',
    },
  ];

  const handleJoyrideCallback = (data: any) => {
    const { status, action, type } = data;
    const finishedStatuses: string[] = [STATUS.FINISHED, STATUS.SKIPPED];
    const closeActions: string[] = ['close', 'skip'];

    // Mark as seen globally for this device as soon as it starts or any interaction happens
    if (type === 'tour:start' || type === 'step:after' || finishedStatuses.includes(status)) {
      localStorage.setItem('bakikhata_tour_v1_seen', 'true');
      setHasSeen(true);
    }

    if (finishedStatuses.includes(status) || closeActions.includes(action)) {
      setRun(false);
      localStorage.setItem('bakikhata_tour_v1_seen', 'true');
      setHasSeen(true);
    }
  };

  return (
    <Joyride
      {...({
        run: run,
        callback: handleJoyrideCallback,
        steps: steps,
        continuous: true,
        showProgress: true,
        showSkipButton: true,
        disableOverlayClose: true,
        disableCloseOnEsc: true,
        hideCloseButton: true,
        spotlightClicks: false,
        disableScrolling: true,
        disableBeacon: true,
        styles: {
          options: {
            primaryColor: '#059669',
            zIndex: 10000,
            arrowColor: '#fff',
            backgroundColor: '#fff',
            overlayColor: 'rgba(0, 0, 0, 0.6)',
            textColor: '#334155',
          },
          beacon: {
            display: 'none',
            visibility: 'hidden',
            opacity: 0,
            pointerEvents: 'none',
          },
          beaconInner: {
            display: 'none',
          },
          beaconOuter: {
            display: 'none',
          },
          buttonNext: {
            borderRadius: '12px',
            fontWeight: 'bold',
            padding: '10px 20px',
            backgroundColor: '#059669',
            fontSize: '14px',
          },
          buttonBack: {
            marginRight: '10px',
            fontWeight: 'bold',
            color: '#64748b',
            fontSize: '14px',
          },
          buttonSkip: {
            color: '#94a3b8',
            fontWeight: 'bold',
            fontSize: '14px',
          },
          tooltip: {
            borderRadius: '24px',
            padding: '20px',
          },
          tooltipContainer: {
            textAlign: 'left',
          },
        } as any,
        locale: {
          back: 'পিছনে',
          close: 'বন্ধ',
          last: 'শেষ',
          next: 'পরবর্তী',
          skip: 'স্কিপ',
        },
      } as any)}
    />
  );
};
