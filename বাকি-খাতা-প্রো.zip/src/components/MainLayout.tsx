import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Wallet, 
  Plus, 
  PiggyBank, 
  HandCoins, 
  Menu, 
  X, 
  Settings, 
  FileText, 
  BarChart3, 
  LogOut,
  MessageSquare,
  Info,
  Trash2,
  Loader2,
  Check,
  Shield,
  Phone,
  Mail,
  HelpCircle,
  BookOpen,
  StickyNote
} from 'lucide-react';
import { useAuth } from '../AuthContext';
import { cn } from '../lib/utils';
import { collection, addDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { db } from '../firebase';
import { toast } from 'react-hot-toast';

import { APP_VERSION } from '../constants';

interface MainLayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children, currentPage, onPageChange }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user, firebaseUser, isAdmin, systemSettings, logout } = useAuth();
  
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [feedbackContent, setFeedbackContent] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  const appName = systemSettings?.appName || 'বাকি খাতা প্রো';
  const appLogo = systemSettings?.appLogo;

  const handleLogout = () => {
    setShowLogoutConfirm(true);
  };

  const confirmLogout = () => {
    logout();
    setShowLogoutConfirm(false);
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackContent.trim() || !user) return;

    setSubmittingFeedback(true);
    // Optimistic UI: Close modal and show success immediately
    const content = feedbackContent;
    setFeedbackContent('');
    setShowFeedbackModal(false);
    toast.success('আপনার ফিডব্যাক জমা দেওয়া হয়েছে। ধন্যবাদ!');

    try {
      await addDoc(collection(db, 'feedback'), {
        content: content,
        date: new Date().toISOString(),
        userEmail: user.email,
        ownerUid: user.uid
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'feedback');
    } finally {
      setSubmittingFeedback(false);
    }
  };

  const navItems = [
    { id: 'notes', label: 'নোটস', icon: StickyNote },
    { id: 'cash', label: 'ক্যাশ', icon: Wallet },
    { id: 'dashboard', label: 'হোম', icon: Home },
    ...(systemSettings?.features?.loans !== false ? [{ id: 'loans', label: 'সাপ্লায়ার', icon: HandCoins }] : []),
    { id: 'reports', label: 'রিপোর্ট', icon: BarChart3 },
  ];

  const sidebarItems = [
    { id: 'settings', label: 'সেটিংস', icon: Settings },
    ...(isAdmin ? [{ id: 'admin', label: 'এডমিন', icon: Shield }] : []),
  ];

  return (
    <div className="min-h-screen bg-slate-50 pb-24 lg:pb-0 lg:pl-64">
      {/* Sidebar for Desktop */}
      <aside className="hidden lg:flex flex-col fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-slate-200 p-6 z-40">
        <div id="tour-profile-logo" className="mb-10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl border-2 border-emerald-100 overflow-hidden shadow-lg shadow-emerald-100 flex items-center justify-center">
            {user?.shopLogo ? (
              <img src={user.shopLogo} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : firebaseUser?.photoURL ? (
              <img src={firebaseUser.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : appLogo ? (
              <img src={appLogo} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-full h-full bg-emerald-600 flex items-center justify-center text-white font-bold text-xl">
                {user?.shopName?.[0] || 'A'}
              </div>
            )}
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-800 tracking-tight leading-none mb-1">{user?.shopName || appName}</h1>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">স্মার্ট বিজনেস লেজার</p>
          </div>
        </div>

        <nav className="space-y-2 flex-1">
          {navItems.map((item) => (
            <button
              id={`tour-nav-${item.id}`}
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                currentPage === item.id ? "bg-emerald-50 text-emerald-600 font-semibold" : "text-slate-600 hover:bg-slate-50"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
          <div className="h-px bg-slate-100 my-4" />
          {sidebarItems.map((item) => (
            <button
              id={`tour-nav-${item.id}`}
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                currentPage === item.id ? "bg-emerald-50 text-emerald-600 font-semibold" : "text-slate-600 hover:bg-slate-50"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
          {systemSettings?.features?.feedback !== false && (
            <button 
              onClick={() => setShowFeedbackModal(true)}
              className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl transition-all"
            >
              <MessageSquare className="w-5 h-5" />
              ফিডব্যাক
            </button>
          )}
          <button 
            onClick={() => setShowContactModal(true)}
            className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl transition-all"
          >
            <Phone className="w-5 h-5" />
            কন্টাক্ট ইনফো
          </button>
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-100">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-rose-600 hover:bg-rose-50 rounded-xl transition-all mb-2"
          >
            <LogOut className="w-5 h-5" />
            লগআউট
          </button>
          <div className="px-4 py-2 text-[10px] font-bold text-slate-300 uppercase tracking-widest text-center">
            Version {APP_VERSION} | Copyright 2026
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="lg:hidden sticky top-0 z-30 bg-[#0a5c36] p-4 flex items-center gap-3 shadow-lg">
        <button 
          id="tour-mobile-menu"
          onClick={() => setIsSidebarOpen(true)} 
          className="p-2 -ml-2 text-white active:scale-95 transition-all"
        >
          <Menu className="w-6 h-6" />
        </button>
        
        <div id="tour-profile-logo-mobile" className="w-10 h-10 rounded-full border-2 border-white/20 overflow-hidden shadow-md shrink-0">
          {user?.shopLogo ? (
            <img src={user.shopLogo} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : firebaseUser?.photoURL ? (
            <img src={firebaseUser.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-full h-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-lg">
              {user?.shopName?.[0] || 'B'}
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h1 className="text-base font-black text-white tracking-tight leading-tight uppercase truncate">{user?.shopName || appName}</h1>
          <p className="text-[10px] text-emerald-100/80 font-bold">স্বাগতম</p>
        </div>
      </header>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="fixed left-0 top-0 bottom-0 w-72 bg-white z-50 p-6 flex flex-col lg:hidden"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full border-2 border-emerald-100 overflow-hidden">
                    {user?.shopLogo ? (
                      <img src={user.shopLogo} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : firebaseUser?.photoURL ? (
                      <img src={firebaseUser.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-full h-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-xl">
                        {user?.shopName?.[0] || 'B'}
                      </div>
                    )}
                  </div>
                  <div>
                    <h1 className="text-lg font-black text-slate-800 tracking-tight leading-none mb-1">{user?.shopName || appName}</h1>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">প্রোফাইল মেনু</p>
                  </div>
                </div>
                <button onClick={() => setIsSidebarOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                  <X className="w-6 h-6 text-slate-600" />
                </button>
              </div>

              <nav className="space-y-1 flex-1">
                {sidebarItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      onPageChange(item.id);
                      setIsSidebarOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                      currentPage === item.id ? "bg-emerald-50 text-emerald-600 font-semibold" : "text-slate-600 hover:bg-slate-50"
                    )}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </button>
                ))}
                <div className="h-px bg-slate-100 my-4" />
                {systemSettings?.features?.feedback !== false && (
                  <button 
                    onClick={() => setShowFeedbackModal(true)}
                    className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl transition-all"
                  >
                    <MessageSquare className="w-5 h-5" />
                    ফিডব্যাক
                  </button>
                )}
                <button 
                  onClick={() => setShowContactModal(true)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl transition-all"
                >
                  <Phone className="w-5 h-5" />
                  কন্টাক্ট ইনফো
                </button>
                <button 
                  onClick={() => setShowPrivacyModal(true)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl transition-all"
                >
                  <Info className="w-5 h-5" />
                  প্রাইভেসি পলিসি
                </button>
              </nav>

              <div className="mt-auto pt-6 border-t border-slate-100">
                <button 
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-3 text-rose-600 hover:bg-rose-50 rounded-xl transition-all mb-2"
                >
                  <LogOut className="w-5 h-5" />
                  লগআউট
                </button>
                <div className="px-4 py-2 text-[10px] font-bold text-slate-300 uppercase tracking-widest text-center">
                  Version {APP_VERSION} | Copyright 2026
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="p-4 lg:p-8 max-w-5xl mx-auto">
        {children}
      </main>

      {/* Feedback Modal */}
      <AnimatePresence>
        {showFeedbackModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFeedbackModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">আপনার ফিডব্যাক দিন</h3>
                <button onClick={() => setShowFeedbackModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleFeedbackSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500 ml-1">আপনার মতামত লিখুন</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="অ্যাপটি কেমন লাগছে বা কি কি উন্নতি করা প্রয়োজন?"
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none"
                    value={feedbackContent}
                    onChange={(e) => setFeedbackContent(e.target.value)}
                  />
                </div>

                <button
                  type="submit"
                  disabled={submittingFeedback}
                  className="w-full py-4 bg-emerald-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                >
                  {submittingFeedback ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                    <>
                      <Check className="w-6 h-6" />
                      জমা দিন
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Contact Info Modal */}
      <AnimatePresence>
        {showContactModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowContactModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-[2.5rem] p-8 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800 tracking-tight">যোগাযোগ করুন</h3>
                <button onClick={() => setShowContactModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <div className="space-y-4">
                {systemSettings?.contacts && systemSettings.contacts.length > 0 ? (
                  systemSettings.contacts.map((contact, index) => (
                    <div 
                      key={index}
                      className="flex items-center gap-4 p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-emerald-200 transition-all group"
                    >
                      <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                        <Info className="w-6 h-6" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5 truncate">{contact.label || 'যোগাযোগ'}</p>
                        <p className="text-lg font-black text-slate-800 break-all">{contact.value}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <>
                    <a 
                      href={`tel:${systemSettings?.contactPhone || '+8801700000000'}`}
                      className="flex items-center gap-4 p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-emerald-200 transition-all group"
                    >
                      <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                        <Phone className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">কল করুন</p>
                        <p className="text-lg font-black text-slate-800">{systemSettings?.contactPhone || '+৮৮০ ১৭০০-০০০০০০'}</p>
                      </div>
                    </a>

                    <a 
                      href={`mailto:${systemSettings?.contactEmail || 'support@bakikhata.com'}`}
                      className="flex items-center gap-4 p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-blue-200 transition-all group"
                    >
                      <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <Mail className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">ইমেইল করুন</p>
                        <p className="text-lg font-black text-slate-800">{systemSettings?.contactEmail || 'support@bakikhata.com'}</p>
                      </div>
                    </a>

                    {systemSettings?.supportLink && (
                      <a 
                        href={systemSettings.supportLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-4 p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-amber-200 transition-all group"
                      >
                        <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-all">
                          <HelpCircle className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">সাপোর্ট লিংক</p>
                          <p className="text-lg font-black text-slate-800">অনলাইন সাপোর্ট</p>
                        </div>
                      </a>
                    )}
                  </>
                )}
              </div>

              <p className="mt-8 text-center text-xs text-slate-400 font-medium">
                আমাদের সাপোর্ট টিম ২৪/৭ আপনার সেবায় নিয়োজিত।
              </p>

              <button
                onClick={() => setShowContactModal(false)}
                className="w-full mt-6 py-4 bg-slate-800 rounded-2xl text-white font-bold text-lg transition-all active:scale-95"
              >
                বন্ধ করুন
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Privacy Policy Modal */}
      <AnimatePresence>
        {showPrivacyModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[32px] w-full max-w-lg overflow-hidden shadow-2xl"
            >
              <div className="bg-emerald-600 p-6 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                    <Info className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-bold">প্রাইভেসি পলিসি</h2>
                </div>
                <button 
                  onClick={() => setShowPrivacyModal(false)}
                  className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 max-h-[60vh] overflow-y-auto">
                {systemSettings?.privacyPolicy ? (
                  <div className="prose prose-slate max-w-none">
                    <div className="whitespace-pre-wrap text-slate-600 leading-relaxed">
                      {systemSettings.privacyPolicy}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Info className="w-8 h-8 text-slate-300" />
                    </div>
                    <p className="text-slate-400 font-medium">কোনো প্রাইভেসি পলিসি সেট করা নেই।</p>
                  </div>
                )}
              </div>

              <div className="p-6 bg-slate-50 border-t border-slate-100">
                <button
                  onClick={() => setShowPrivacyModal(false)}
                  className="w-full py-4 bg-slate-800 rounded-2xl text-white font-bold text-lg transition-all active:scale-95"
                >
                  বন্ধ করুন
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogoutConfirm(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-8 shadow-2xl text-center"
            >
              <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4 text-rose-600">
                <LogOut className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">লগআউট করতে চান?</h3>
              <p className="text-sm text-slate-400 mb-6">
                আপনি কি নিশ্চিত যে আপনি আপনার অ্যাকাউন্ট থেকে লগআউট করতে চান?
              </p>
              
              <div className="flex flex-col gap-3">
                <button
                  onClick={confirmLogout}
                  className="w-full py-4 bg-rose-600 rounded-2xl text-white font-bold text-lg shadow-lg shadow-rose-100 transition-all active:scale-95"
                >
                  হ্যাঁ, লগআউট করুন
                </button>
                <button
                  onClick={() => setShowLogoutConfirm(false)}
                  className="w-full py-4 bg-slate-100 rounded-2xl text-slate-600 font-bold text-lg transition-all active:scale-95"
                >
                  না, ফিরে যান
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Bottom Navigation for Mobile */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-2 h-20 flex items-center justify-around z-30 shadow-[0_-4px_20px_rgba(0,0,0,0.03)]">
        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          
          if (item.id === 'dashboard') {
            return (
              <button
                id={`tour-nav-${item.id}-mobile`}
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className="relative -top-4 flex flex-col items-center"
              >
                <div className={cn(
                  "w-14 h-14 rounded-full flex items-center justify-center shadow-xl transition-all active:scale-90",
                  isActive 
                    ? "bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-emerald-200" 
                    : "bg-white text-slate-400 border-4 border-slate-50 shadow-slate-200"
                )}>
                  <item.icon className="w-7 h-7" />
                </div>
                <span className={cn(
                  "text-[10px] font-black mt-1 uppercase tracking-wider",
                  isActive ? "text-emerald-600" : "text-slate-400"
                )}>{item.label}</span>
              </button>
            );
          }

          return (
            <button
              id={`tour-nav-${item.id}-mobile`}
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className={cn(
                "flex flex-col items-center gap-1 p-2 min-w-[64px] transition-all",
                isActive ? "text-emerald-600" : "text-slate-400"
              )}
            >
              <item.icon className={cn("w-6 h-6", isActive && "fill-emerald-50")} />
              <span className="text-[10px] font-bold">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
