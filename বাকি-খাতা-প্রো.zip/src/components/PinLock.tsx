import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Delete, Check, Lock } from 'lucide-react';
import { cn } from '../lib/utils';

interface PinLockProps {
  correctPin: string;
  onSuccess: () => void;
  title?: string;
}

export const PinLock: React.FC<PinLockProps> = ({ correctPin, onSuccess, title = "পিন লিখুন" }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleNumber = (num: string) => {
    if (pin.length < 4) {
      const newPin = pin + num;
      setPin(newPin);
      if (newPin.length === 4) {
        if (newPin === correctPin) {
          onSuccess();
        } else {
          setError(true);
          setTimeout(() => {
            setPin('');
            setError(false);
          }, 500);
        }
      }
    }
  };

  const handleBackspace = () => {
    setPin(pin.slice(0, -1));
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900 text-white p-6">
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="mb-8 text-center"
      >
        <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/20">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold mb-2">{title}</h2>
        <p className="text-slate-400">আপনার ৪ ডিজিটের পিনটি দিন</p>
      </motion.div>

      <div className="flex gap-4 mb-12">
        {[0, 1, 2, 3].map((i) => (
          <motion.div
            key={i}
            animate={error ? { x: [0, -10, 10, -10, 10, 0] } : {}}
            className={cn(
              "w-4 h-4 rounded-full border-2 border-emerald-500 transition-all duration-200",
              pin.length > i ? "bg-emerald-500 scale-125" : "bg-transparent",
              error && "border-rose-500 bg-rose-500"
            )}
          />
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6 max-w-xs w-full">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
          <button
            key={num}
            onClick={() => handleNumber(num)}
            className="w-16 h-16 rounded-full bg-slate-800 hover:bg-slate-700 active:scale-95 transition-all text-2xl font-semibold flex items-center justify-center mx-auto"
          >
            {num}
          </button>
        ))}
        <div />
        <button
          onClick={() => handleNumber('0')}
          className="w-16 h-16 rounded-full bg-slate-800 hover:bg-slate-700 active:scale-95 transition-all text-2xl font-semibold flex items-center justify-center mx-auto"
        >
          0
        </button>
        <button
          onClick={handleBackspace}
          className="w-16 h-16 rounded-full bg-slate-800/50 hover:bg-slate-700 active:scale-95 transition-all text-xl flex items-center justify-center mx-auto"
        >
          <Delete className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
