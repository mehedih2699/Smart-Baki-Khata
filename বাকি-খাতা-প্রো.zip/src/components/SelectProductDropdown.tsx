import React, { useState, useRef, useEffect } from 'react';
import { InventoryItem } from '../types';
import { formatCurrency } from '../lib/utils';
import { Search } from 'lucide-react';

interface Props {
  items: InventoryItem[];
  selectedId: string;
  onSelect: (id: string) => void;
  placeholder?: string;
  allowClear?: boolean;
}

export const SelectProductDropdown: React.FC<Props> = ({ 
  items, 
  selectedId, 
  onSelect,
  placeholder = "-- পণ্য সিলেক্ট করুন --",
  allowClear = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedItem = items.find(i => i.id === selectedId);
  const availableItems = items.filter(i => i.stockQuantity > 0);
  
  const filteredItems = availableItems.filter(i => 
    i.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="relative" ref={wrapperRef}>
      <div 
        onClick={() => {
          setIsOpen(!isOpen);
          setSearchQuery('');
        }}
        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus-within:ring-2 focus-within:ring-emerald-500 flex items-center justify-between cursor-pointer"
      >
        <span className={selectedItem ? "text-slate-800 font-medium" : "text-slate-400"}>
          {selectedItem 
            ? `${selectedItem.name} - ${formatCurrency(selectedItem.sellingPrice)}` 
            : placeholder}
        </span>
        <div className="text-slate-400">
          <svg className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>

      {isOpen && (
        <div className="absolute z-50 w-full mt-2 bg-white border border-slate-200 rounded-xl shadow-xl max-h-80 overflow-y-auto no-scrollbar left-0">
          <div className="sticky top-0 bg-white p-2 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                placeholder="পণ্যের নাম খুঁজুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
              />
            </div>
          </div>
          
          <div className="p-1">
            {allowClear && (
               <button
                type="button"
                onClick={() => {
                  onSelect('');
                  setIsOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-sm text-slate-600 hover:bg-slate-50 rounded-lg outline-none font-medium transition-all"
               >
                 {placeholder}
               </button>
            )}

            {filteredItems.length === 0 ? (
              <div className="p-4 text-center text-sm text-slate-400">
                কোন পণ্য পাওয়া যায়নি
              </div>
            ) : (
              filteredItems.map(item => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onSelect(item.id);
                    setIsOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-sm rounded-lg outline-none transition-all flex justify-between items-center ${
                    selectedId === item.id ? 'bg-emerald-50 text-emerald-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div>
                    <span className="block">{item.name}</span>
                    <span className="text-[10px] text-slate-400 font-normal">স্টক: {item.stockQuantity} {item.unit}</span>
                  </div>
                  <span className="font-medium">{formatCurrency(item.sellingPrice)}</span>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
