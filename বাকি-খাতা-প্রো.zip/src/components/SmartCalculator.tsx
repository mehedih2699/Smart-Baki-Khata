import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Delete, Divide, Minus, Plus, X as Multiply, Equal, List, Trash2, History, Check, Calculator, Edit2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuth } from '../AuthContext';
import { updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { toast } from 'react-hot-toast';

interface SmartCalculatorProps {
  onClose: () => void;
  onSave?: (value: number, note?: string) => void;
}

interface CalcItem {
  id: string;
  title: string;
  value: number;
  selected: boolean;
  equation?: string;
}

export const SmartCalculator: React.FC<SmartCalculatorProps> = ({ onClose, onSave }) => {
  const { user } = useAuth();
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [isResult, setIsResult] = useState(false);
  const [itemTitle, setItemTitle] = useState('');
  const [items, setItems] = useState<CalcItem[]>(() => {
    try {
      const saved = localStorage.getItem('calc_items');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [history, setHistory] = useState<{id: string, equation: string, result: string, timestamp: number}[]>(() => {
    try {
      const saved = localStorage.getItem('calc_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const quickItems = user?.quickItemsCalculator || user?.quickItems || ['সিগারেট', 'চা পাতা', 'পান', 'বিস্কুট'];
  const [isEditingQuickItems, setIsEditingQuickItems] = useState(false);
  const [newQuickItemName, setNewQuickItemName] = useState('');

  const handleUpdateQuickItems = async (newItems: string[]) => {
    if (!user?.uid) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        quickItemsCalculator: newItems
      });
    } catch (error) {
      toast.error('কুইক আইটেম আপডেট করতে সমস্যা হয়েছে');
    }
  };

  useEffect(() => {
    // Dispatch state change for App.tsx
    window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
      detail: { isOpen: true } 
    }));

    const handleCloseEvent = () => {
      onClose();
    };

    window.addEventListener('close-calculator', handleCloseEvent);
    
    return () => {
      window.dispatchEvent(new CustomEvent('calculator-state-changed', { 
        detail: { isOpen: false } 
      }));
      window.removeEventListener('close-calculator', handleCloseEvent);
    };
  }, [onClose]);

  useEffect(() => {
    localStorage.setItem('calc_items', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('calc_history', JSON.stringify(history));
  }, [history]);

  const [view, setView] = useState<'list' | 'history'>('list');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [items, view]);

  const handleNumber = (num: string) => {
    if (display === '0' || isResult) {
      setDisplay(num);
      setIsResult(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (op: string) => {
    if (isResult) {
      setEquation(display + ' ' + op + ' ');
      setIsResult(false);
      setDisplay('0');
    } else if (display === '0' && equation !== '') {
      // Switch operator: replace the last operator in the equation
      const parts = equation.trim().split(' ');
      if (parts.length >= 2) {
        parts[parts.length - 1] = op;
        setEquation(parts.join(' ') + ' ');
      } else if (parts.length === 1) {
        // If only one number, add the operator
        setEquation(parts[0] + ' ' + op + ' ');
      }
    } else {
      // Accumulate: add current display and operator to equation
      setEquation(prev => prev + display + ' ' + op + ' ');
      setDisplay('0');
    }
  };

  const calculate = () => {
    if (!equation && !isResult) return;
    
    const fullEquation = equation + display;
    try {
      // Simple evaluation logic
      const parts = fullEquation.trim().split(' ');
      if (parts.length < 3) return;

      let result = parseFloat(parts[0]);
      
      for (let i = 1; i < parts.length; i += 2) {
        const operator = parts[i];
        const nextNum = parseFloat(parts[i + 1]);
        
        if (isNaN(nextNum)) continue;

        if (operator === '+') result += nextNum;
        if (operator === '-') result -= nextNum;
        if (operator === '×') result *= nextNum;
        if (operator === '÷') result /= nextNum;
      }
      
      const finalResult = Number(result.toFixed(2));
      setDisplay(finalResult.toString());
      setEquation('');
      setIsResult(true);

      // Add to history
      setHistory(prev => [{
        id: Math.random().toString(36).substr(2, 9),
        equation: fullEquation,
        result: finalResult.toString(),
        timestamp: Date.now()
      }, ...prev].slice(0, 20));
    } catch (error) {
      setDisplay('Error');
    }
  };

  const clear = () => {
    setDisplay('0');
    setEquation('');
    setIsResult(false);
    setItemTitle('');
  };

  const addItem = () => {
    const val = parseFloat(display);
    if (isNaN(val) || val === 0) return;

    const newItem: CalcItem = {
      id: Math.random().toString(36).substr(2, 9),
      title: itemTitle || 'আইটেম',
      value: val,
      selected: true,
      equation: equation ? equation + display : undefined
    };

    setItems([...items, newItem]);
    setItemTitle('');
    setDisplay('0');
    setEquation('');
    setIsResult(false);
    setView('list');
  };

  const toggleItem = (id: string) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, selected: !item.selected } : item
    ));
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const clearList = () => {
    setItems([]);
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const handleSave = () => {
    if (onSave) {
      const selectedItems = items.filter(item => item.selected);
      const total = selectedItems.reduce((acc, item) => acc + item.value, 0);
      
      const calcNote = selectedItems.length > 0 
        ? selectedItems.map(item => `${item.title ? item.title : 'আইটেম'} ${item.value}`).join(', ')
        : undefined;
      
      if (items.length === 0) {
        onSave(parseFloat(display));
      } else {
        onSave(total, calcNote);
      }
      onClose();
    }
  };

  const totalSelected = items
    .filter(item => item.selected)
    .reduce((acc, item) => acc + item.value, 0);

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6"
      onClick={(e) => e.stopPropagation()}
    >
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full sm:max-w-md md:max-w-lg bg-[#1e293b] sm:rounded-[2rem] shadow-2xl overflow-hidden flex flex-col h-full sm:h-[95vh] sm:max-h-[850px] border-x sm:border border-slate-700"
      >
        {/* Header - Fixed Height */}
        <div className="flex-shrink-0 flex items-center justify-between p-2.5 sm:p-4 border-b border-slate-800/50">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <div className="w-6 h-6 sm:w-8 sm:h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center">
              <Calculator className="w-3.5 h-3.5 sm:w-5 sm:h-5 text-emerald-500" />
            </div>
            <h3 className="text-xs sm:text-base font-black text-emerald-500">স্মার্ট ক্যালকুলেটর</h3>
          </div>
          <div className="flex items-center gap-1 sm:gap-1.5">
            <button 
              onClick={() => setView('history')}
              className={cn(
                "p-1 sm:p-1.5 rounded-lg transition-all",
                view === 'history' ? "bg-emerald-500 text-white" : "text-slate-400 hover:text-white"
              )}
            >
              <History className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
            <div className="relative">
              <button 
                onClick={() => setView('list')}
                className={cn(
                  "p-1 sm:p-1.5 rounded-lg transition-all",
                  view === 'list' ? "bg-emerald-500 text-white" : "text-slate-400 hover:text-white"
                )}
              >
                <List className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 bg-emerald-500 text-white text-[5px] sm:text-[7px] font-bold rounded-full flex items-center justify-center border border-[#1e293b]">
                {items.length}
              </span>
            </div>
            <button onClick={onClose} className="p-1 sm:p-1.5 text-slate-400 hover:text-rose-500 transition-colors">
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* Dynamic Content - Flexible Height (This is the only part that shrinks) */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-2 space-y-1.5 custom-scrollbar bg-slate-900/10 min-h-[50px]"
        >
          <div className="flex items-center justify-between mb-1 px-1">
            <p className="text-[8px] sm:text-[9px] font-black text-slate-500 uppercase tracking-widest">
              {view === 'list' ? 'আইটেম লিস্ট' : 'হিস্টরি'}
            </p>
            {((view === 'list' && items.length > 0) || (view === 'history' && history.length > 0)) && (
              <button 
                onClick={view === 'list' ? clearList : clearHistory}
                className="flex items-center gap-1 text-[8px] sm:text-[9px] font-black text-rose-500 hover:text-rose-400 transition-colors"
              >
                <Trash2 className="w-2 h-2 sm:w-2.5 sm:h-2.5" />
                মুছুন
              </button>
            )}
          </div>
          {view === 'list' ? (
            items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-30 py-4">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-slate-800 rounded-full flex items-center justify-center mb-1.5">
                  <List className="w-4 h-4 sm:w-5 sm:h-5 text-slate-500" />
                </div>
                <p className="text-slate-400 font-bold text-[9px] sm:text-[10px]">লিস্টে কোনো আইটেম নেই</p>
              </div>
            ) : (
              items.map((item) => (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={item.id}
                  className={cn(
                    "flex items-center gap-2 sm:gap-3 p-1.5 sm:p-2 rounded-xl border transition-all",
                    item.selected 
                      ? "bg-emerald-500/5 border-emerald-500/20" 
                      : "bg-slate-800/20 border-transparent opacity-60"
                  )}
                >
                  <button 
                    onClick={() => toggleItem(item.id)}
                    className={cn(
                      "w-4 h-4 sm:w-5 sm:h-5 rounded-md border-2 flex items-center justify-center transition-all",
                      item.selected ? "bg-emerald-500 border-emerald-500" : "border-slate-600"
                    )}
                  >
                    {item.selected && <Check className="w-2.5 h-2.5 sm:w-3 h-3 text-white" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] sm:text-xs font-black text-white truncate">{item.title}</p>
                    {item.equation && (
                      <p className="text-[8px] sm:text-[9px] text-slate-500 font-bold">{item.equation}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="text-[11px] sm:text-xs font-black text-emerald-500">{item.value} ৳</p>
                    <button 
                      onClick={() => removeItem(item.id)}
                      className="text-rose-500/50 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                    </button>
                  </div>
                </motion.div>
              ))
            )
          ) : (
            history.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-30 py-6">
                <p className="text-slate-400 font-bold text-xs">হিস্টরি খালি</p>
              </div>
            ) : (
              history.map((h) => (
                <button 
                  key={h.id}
                  className="w-full text-left p-2 sm:p-3 rounded-xl bg-slate-800/20 border border-slate-700/50 space-y-0.5 sm:space-y-1 hover:bg-slate-800/40 transition-all"
                  onClick={() => {
                    setDisplay(h.result);
                    setIsResult(true);
                  }}
                >
                  <p className="text-[9px] sm:text-[10px] text-slate-500 font-bold">{h.equation} =</p>
                  <p className="text-base sm:text-lg font-black text-white">{h.result} ৳</p>
                </button>
              ))
            )
          )}
        </div>

        {/* Display - Fixed Height */}
        <div className="flex-shrink-0 p-2 sm:p-3 text-right bg-slate-900/50 border-y border-slate-800/30">
          <p className="text-[8px] sm:text-[10px] text-slate-500 font-bold h-3 mb-0.5 tracking-wider truncate">{equation}</p>
          <p className="text-2xl sm:text-4xl font-black text-white truncate leading-none">{display}</p>
        </div>

        {/* Input Area - Fixed Height */}
        <div className="flex-shrink-0 p-2 sm:p-3 bg-slate-900/50 border-t border-slate-800/50 space-y-2 sm:space-y-3">
          {/* Quick Item Buttons */}
          <div className="flex gap-1 sm:gap-1.5 overflow-x-auto pb-1 custom-scrollbar no-scrollbar items-center">
            {quickItems.map((item, idx) => (
              <div key={idx} className="relative group shrink-0">
                <button
                  disabled={isEditingQuickItems}
                  onClick={() => setItemTitle(item)}
                  className={cn(
                    "px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[9px] sm:text-[10px] font-bold whitespace-nowrap transition-all h-full",
                    itemTitle === item && !isEditingQuickItems
                      ? "bg-emerald-500 text-white" 
                      : "bg-slate-800 text-slate-400",
                    !isEditingQuickItems && "hover:bg-slate-700",
                    isEditingQuickItems && "opacity-50"
                  )}
                >
                  {item}
                </button>
                {isEditingQuickItems && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUpdateQuickItems(quickItems.filter((_, i) => i !== idx));
                    }}
                    className="absolute -top-1 -right-1 bg-rose-500 text-white rounded-full p-0.5 shadow-md hover:scale-110 transition-transform z-10"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                )}
              </div>
            ))}
            {isEditingQuickItems ? (
              <div className="flex items-center gap-1 shrink-0">
                <input 
                  type="text"
                  placeholder="নতুন..."
                  value={newQuickItemName}
                  onChange={(e) => setNewQuickItemName(e.target.value)}
                  className="bg-slate-800 border-none rounded-full px-2 py-1 text-[9px] text-white font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500 w-16 h-[22px] sm:h-[26px]"
                />
                <button
                  onClick={() => {
                    if (!newQuickItemName.trim()) return;
                    if (!quickItems.includes(newQuickItemName.trim())) {
                      handleUpdateQuickItems([...quickItems, newQuickItemName.trim()]);
                    }
                    setNewQuickItemName('');
                  }}
                  className="bg-emerald-600 text-white p-1 rounded-full flex items-center justify-center h-[22px] w-[22px] sm:h-[26px] sm:w-[26px]"
                >
                  <Plus className="w-3 h-3" />
                </button>
                <button
                  onClick={() => setIsEditingQuickItems(false)}
                  className="bg-slate-700 text-white px-2 py-1 rounded-full text-[9px] font-bold h-[22px] sm:h-[26px]"
                >
                  সম্পন্ন
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditingQuickItems(true)}
                className="shrink-0 px-2 py-1 rounded-full bg-slate-800/50 text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition-colors flex items-center justify-center h-[22px] sm:h-[26px]"
              >
                <Edit2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
              </button>
            )}
          </div>

          <div className="flex gap-1.5 sm:gap-2">
            <input
              type="text"
              placeholder="আইটেমের নাম (ঐচ্ছিক)"
              className="flex-1 bg-slate-800/50 border border-slate-700 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2 sm:py-2.5 text-xs sm:text-sm text-white font-bold outline-none focus:border-emerald-500 transition-all placeholder:text-slate-600"
              value={itemTitle}
              onChange={(e) => setItemTitle(e.target.value)}
            />
            <button 
              onClick={addItem}
              className="px-3 sm:px-4 bg-emerald-600 text-white rounded-lg sm:rounded-xl font-black text-xs sm:text-sm flex items-center gap-1 sm:gap-1.5 hover:bg-emerald-700 transition-all active:scale-95 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              যোগ
            </button>
          </div>
        </div>

        {/* Keypad - Fixed Height */}
        <div className="flex-shrink-0 p-1 sm:p-1.5 grid grid-cols-4 gap-1 bg-slate-900/40">
          <button onClick={clear} className="p-2 sm:p-2.5 bg-rose-500/10 text-rose-500 rounded-lg font-black hover:bg-rose-500/20 transition-all text-[10px] sm:text-xs border border-rose-500/20 shadow-sm active:scale-95">AC</button>
          <button onClick={() => setDisplay(display.slice(0, -1) || '0')} className="p-2 sm:p-2.5 bg-slate-800/50 text-slate-400 rounded-lg font-black hover:bg-slate-800 transition-all flex items-center justify-center border border-slate-700/50 shadow-sm active:scale-95">
            <Delete className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
          <button onClick={() => handleOperator('%')} className="p-2 sm:p-2.5 bg-slate-800/50 text-emerald-500 rounded-lg font-black hover:bg-slate-800 transition-all text-[10px] sm:text-xs border border-slate-700/50 shadow-sm active:scale-95">%</button>
          <button onClick={() => handleOperator('÷')} className="p-2 sm:p-2.5 bg-emerald-500/10 text-emerald-500 rounded-lg font-black hover:bg-emerald-500/20 transition-all flex items-center justify-center border border-emerald-500/20 shadow-sm active:scale-95">
            <Divide className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {[7, 8, 9].map(n => (
            <button key={n} onClick={() => handleNumber(n.toString())} className="p-2 sm:p-2.5 bg-slate-800/30 text-white rounded-lg font-black hover:bg-slate-800 transition-all text-sm sm:text-base border border-slate-700/30 shadow-sm active:scale-95">{n}</button>
          ))}
          <button onClick={() => handleOperator('×')} className="p-2 sm:p-2.5 bg-emerald-500/10 text-emerald-500 rounded-lg font-black hover:bg-emerald-500/20 transition-all flex items-center justify-center border border-emerald-500/20 shadow-sm active:scale-95">
            <Multiply className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {[4, 5, 6].map(n => (
            <button key={n} onClick={() => handleNumber(n.toString())} className="p-2 sm:p-2.5 bg-slate-800/30 text-white rounded-lg font-black hover:bg-slate-800 transition-all text-sm sm:text-base border border-slate-700/30 shadow-sm active:scale-95">{n}</button>
          ))}
          <button onClick={() => handleOperator('-')} className="p-2 sm:p-2.5 bg-emerald-500/10 text-emerald-500 rounded-lg font-black hover:bg-emerald-500/20 transition-all flex items-center justify-center border border-emerald-500/20 shadow-sm active:scale-95">
            <Minus className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {[1, 2, 3].map(n => (
            <button key={n} onClick={() => handleNumber(n.toString())} className="p-2 sm:p-2.5 bg-slate-800/30 text-white rounded-lg font-black hover:bg-slate-800 transition-all text-sm sm:text-base border border-slate-700/30 shadow-sm active:scale-95">{n}</button>
          ))}
          <button onClick={() => handleOperator('+')} className="p-2 sm:p-2.5 bg-emerald-500/10 text-emerald-500 rounded-lg font-black hover:bg-emerald-500/20 transition-all flex items-center justify-center border border-emerald-500/20 shadow-sm active:scale-95">
            <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          <button onClick={() => handleNumber('0')} className="col-span-2 p-2 sm:p-2.5 bg-slate-800/30 text-white rounded-lg font-black hover:bg-slate-800 transition-all text-sm sm:text-base border border-slate-700/30 shadow-sm active:scale-95">0</button>
          <button onClick={() => !display.includes('.') && setDisplay(display + '.')} className="p-2 sm:p-2.5 bg-slate-800/30 text-white rounded-lg font-black hover:bg-slate-800 transition-all text-sm sm:text-base border border-slate-700/30 shadow-sm active:scale-95">.</button>
          <button onClick={calculate} className="p-2 sm:p-2.5 bg-emerald-600 text-white rounded-lg font-black hover:bg-emerald-700 transition-all flex items-center justify-center shadow-lg shadow-emerald-900/40 border border-emerald-500 active:scale-95">
            <Equal className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Footer - Fixed Height */}
        <div className="flex-shrink-0 p-2 sm:p-3 bg-[#1e293b] border-t border-slate-800/50 space-y-1.5 sm:space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold">মোট সিলেক্টেড:</p>
            <p className="text-base sm:text-lg font-black text-white">{totalSelected} ৳</p>
          </div>
          <button
            onClick={handleSave}
            className="w-full py-2 sm:py-2.5 bg-emerald-600 text-white rounded-lg font-black text-xs sm:text-sm shadow-lg shadow-emerald-900/20 hover:bg-emerald-700 transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            সেভ করুন
          </button>
        </div>
      </motion.div>
    </div>
  );
};
