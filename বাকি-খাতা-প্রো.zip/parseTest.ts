const content = `চা x 5 = 50 ৳
সিগারেট - 15 ৳
কিছু কথা
পান = 5 ৳`;

const lines = content.split('\n');
lines.forEach(line => {
    const trimmed = line.trim();
    if (!trimmed) return;
    
    const qtyMatch = trimmed.match(/^(.*?) x (\d+) = (\d+)\s*৳$/);
    if (qtyMatch) {
      console.log('QTY MATCH', qtyMatch.slice(1, 4));
      return;
    }

    const simpleMatch = trimmed.match(/^(.*?)(?: \- | = )(\d+)\s*৳$/);
    if (simpleMatch) {
      console.log('SIMPLE MATCH', simpleMatch.slice(1, 3));
      return;
    }

    const simpleMatch2 = trimmed.match(/^(.*?)\s*=\s*(\d+)\s*৳$/);
    if (simpleMatch2) {
      console.log('SIMPLE MATCH 2', simpleMatch2.slice(1, 3));
      return;
    }

    console.log('NO MATCH', line);
});
