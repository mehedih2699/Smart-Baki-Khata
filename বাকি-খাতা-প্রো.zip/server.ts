import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import admin from "firebase-admin";
import firebaseConfig from "./firebase-applet-config.json" assert { type: "json" };

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
// In the AI Studio environment, we can often initialize with default credentials
// but we specify the projectId from the config.
if (!admin.apps.length) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId,
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API route to delete a user from Firebase Auth
  app.post("/api/admin/delete-user", async (req, res) => {
    const { uid, idToken } = req.body;

    if (!uid || !idToken) {
      return res.status(400).json({ error: "Missing uid or idToken" });
    }

    try {
      // 1. Verify the ID token of the requester
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      const requesterUid = decodedToken.uid;

      // 2. Check if the requester is an admin
      // We check the hardcoded email or the 'role' field in Firestore
      const adminEmail = "mehedih0127@gmail.com";
      let isAdmin = decodedToken.email?.toLowerCase() === adminEmail.toLowerCase();

      if (!isAdmin) {
        const userDoc = await admin.firestore()
          .doc(`users/${requesterUid}`)
          .get();
        if (userDoc.exists && userDoc.data()?.role === 'admin') {
          isAdmin = true;
        }
      }

      if (!isAdmin) {
        return res.status(403).json({ error: "Unauthorized: Admin access required" });
      }

      // 3. Delete the user from Firebase Auth
      console.log(`Admin: Deleting auth user ${uid}`);
      await admin.auth().deleteUser(uid);

      // 4. Delete the user document from Firestore (optional, but good practice)
      // We also do this on the client, but doing it here ensures it's gone.
      await admin.firestore().doc(`users/${uid}`).delete();

      res.json({ success: true, message: `User ${uid} deleted successfully from Auth and Firestore` });
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
