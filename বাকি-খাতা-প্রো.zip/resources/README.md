# This folder is for your app icons and splash screens.
# Place 'icon.png' and 'splash.png' here.
